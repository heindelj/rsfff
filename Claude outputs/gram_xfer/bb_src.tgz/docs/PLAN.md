# bb — consolidation plan

bb ("Black Box") is a library of **equivariant features and neural-network building blocks for
MLIPs and NN-parameterized physical models**. It owns everything that turns geometry, plus
whatever extra per-atom or per-system inputs a caller supplies, into learned representations and
generic equivariant outputs. Physical models, losses, training loops, data formats and checkpoint
layouts stay in the consuming projects (rsfff, pauli_fierz_pinn, hbq_qed).

---

## 1. What exists today

The three repos share one lineage of code, copied and then allowed to drift.

| Component | rsfff | pauli_fierz_pinn (pf) | hbq_qed (hbq) | State |
|---|---|---|---|---|
| `equivariant_backend.py` (e3nn / cue O3 primitives) | `src/features/` | `src/` | `src/hbq_qed/ml/` | Same code; only the docstrings differ |
| `weighted_bispectrum.py` (nu=3, MACE-style sym. contraction) | `src/features/` | `src/` | `ml/` | **Identical** in all three |
| Featurizer (`DensityExpansion`, power spectrum, `FlatLambdaSOAPFeaturizer`) | `features/features.py` (1183 lines) | `features_native.py` (767) | `ml/features_native.py` (767) | pf == hbq. rsfff is a superset: public `edge_expansion` / `scatter_species` / `scatter_weighted`, cross spectrum, grouped/cross/soft-partition modes, `FlatStateSOAPFeaturizer` |
| Neighbor list | `src/neighbors.py` (cap check, strict mode, MPS/CUDA fallback) | inline in `features_native.py` | inline | Two implementations of the same idea |
| Message passing (CG conv, 0e+2e hidden, residual, zero-init) | — | `models/message_passing.py` | `ml/message_passing.py` | pf == hbq. Doesn't refine l=1, so hbq's dipole heads read *unrefined* vector features |
| Heads (`mlp`, alpha / vector / scalar / ratio / response) | `mlip/heads.py`, `mlip/response_heads.py` | `models/heads.py` | `ml/heads.py` | **Drifted** in all three (e.g. `AtomicAlphaHead` rsfff vs pf: 83 changed lines, `AtomicVectorHead`: three variants) |
| External-input coupling | `ff/state_invariants.py` (state × features → invariants), field invariants in `ff/environment.py`, FiLM in `ff/film/conditioning.py` | `lambda_2e`, `vec_lambda_0e/2e`, `augment_inv/equiv` in `heads.py` | none | The same idea three times: couple an external irrep to the features |
| Init / weight-decay tagging | `zero_init_readout`, `exempt_from_weight_decay`, `mark_env_slot`, `TwoSlotLinear` in `mlip/heads.py` | ad hoc | ad hoc | Only rsfff has these |
| Voigt ↔ irrep, `min_eig_sym3x3` | `response_heads.py` | `heads.py` and `data.py` | — | Duplicated |
| Configs | `FeaturesConfig(cutoff, n_max, l_max, max_num_neighbors)` | dict parsing (`cutoff_radius, max_angular, max_radial, max_neighbors`) | `FeaturizerConfig`/`BispectrumConfig`/`MessagePassingConfig` dataclasses, pf naming | Two naming schemes |
| `torch_compat.py` (e3nn safe globals) | — | `src/` | `ml/` | Identical |

None of the three supports periodic cells.

## 2. Scope: what goes where

**Rule:** if it would make sense in an MLIP that knows nothing about force fields or cavities, it
belongs in bb. If it encodes a physical model, units, a label, a data format or a training
procedure, it stays in the project.

**Goes into bb**
- Neighbor lists and graph utilities.
- O3 backends (e3nn and cuequivariance) and Cartesian ↔ spherical helpers.
- **Feature calculation**: radial bases, density expansion, power spectrum / bispectrum / cross
  spectra, learned channel compression, partitioned (fragment/environment) densities, featurizers.
- NN building blocks: MLPs, embeddings, FiLM conditioning, init and parameter tagging, message
  passing.
- External-input coupling: fields, cavity polarization, electronic state, any caller-supplied irrep.
- Generic readouts specified by output irreps (`"1x0e + 1x1o + 1x2e"`), with no physical
  meaning attached, plus generic output transforms (pooling, a sum constraint, irreps → Cartesian
  tensor, PSD projection).
- Configs for all of the above, plus testing utilities (equivariance and backend-parity checks).
- An ensemble wrapper (stacked parameters, vmapped forward), and a reference `EnergyModel`.

**Stays in the projects**
- rsfff: everything under `ff/` except the generic pieces listed in §6.1, plus the EEM/SQE solves,
  diabats and mixtures, `qcgen`, `md`, `train`, the `v1` snapshot, and torchff.
- pf: model compositions (`stage0`, `fluctuation`, `cavity_drude`, `cavity_mbd`), the Drude/MBD
  solvers, interaction tensors, damping, the `pf_evaluator`, losses, training, calculators,
  MACE compat, uncertainty and normality analysis, and dimer sampling.
- hbq: `DipoleModel` composition (including how charges and atomic dipoles combine into
  `Σ q r + Σ p`), data, loss, training, the ASE calculator, committee checkpoint discovery, and
  the NWChem / Pauli-Fierz / surface code.

**Not in bb (by design):** trainers, loss functions, dataset formats and extxyz key maps,
committee directory layouts, physical units.

## 3. Package layout

```
bb/
  pyproject.toml          # src layout, automatic package discovery (avoids rsfff's hand-kept list)
  src/bb/
    graph/
      neighbors.py        # radius_graph (torch-cluster when present, pure-torch fallback), cap check,
                          # strict mode, MPS/CUDA fallbacks; one place, as rsfff.neighbors is today
      stats.py            # count_neighbors, dataset_average_num_neighbors
      batch.py            # GraphBatch Protocol (positions, atomic_numbers, batch_idx) + helpers
    o3/
      backend.py          # EquivariantBackend, E3nnBackend, CueBackend, get_backend
      irreps.py           # IrrepFeatures container (see 4.2)
      cartesian.py        # voigt <-> irrep6, spherical <-> cartesian quadrupole, min_eig_sym3x3
    features/
      radial.py           # BesselBasis, cosine_cutoff, polynomial envelope
      density.py          # DensityExpansion: edge_expansion, scatter_species, scatter_weighted
      spectra.py          # power_spectrum, equivariant_power_spectrum, cross spectrum, spec builders (public)
      bispectrum.py       # weighted bispectrum (e3nn + cue)
      compress.py         # learned channel projection; learned per-atom channel weights (AtomWeightNet)
      featurizers.py      # SOAPFeaturizer (= FlatLambdaSOAP), StateSOAPFeaturizer, PartitionedFeaturizer
    nn/
      mlp.py, embedding.py
      init.py             # zero_init_readout, exempt_from_weight_decay, exempt_parameter, param_groups()
      tags.py             # mark_slot / slot_parameters (generalized mark_env_slot)
      conditioning.py     # FiLMGenerator, FiLMLayer, ConditionedTrunk (modes: none/concat/film)
      two_slot.py         # TwoSlotLinear, two_slot_mlp
      message_passing.py  # EquivariantMessagePassing, generalized to any irreps (see 4.4)
    inputs/
      coupling.py         # external irrep x feature irrep -> invariants / equivariants (see 4.3)
    heads/
      readout.py          # IrrepsReadout: features -> any output irreps (gated, per-l channel reduction)
      transforms.py       # pool (sum/mean per system), constrain_sum, to_cartesian, psd_project
    config/               # dataclass configs + from_dict/to_dict + legacy key aliases
    ensemble.py           # Ensemble: stacked parameters via torch.func, one vmapped forward
    models/energy.py      # reference EnergyModel (featurizer -> head -> sum, forces by autograd)
    testing/              # assert_equivariant, assert_backend_parity, random rotations
    compat/               # state-dict remap helpers, torch_compat (e3nn safe globals)
  tests/
```

Dependencies: `torch`, `e3nn`, `numpy`. Extras: `cue` / `cue-cu12` / `cue-cu13` (copied from
rsfff), `neighbors` (torch-cluster, keeping rsfff's documented `--no-build-isolation` recipe),
`test`. Neither ASE nor pyyaml is required, since the configs are plain dicts.

## 4. Core design decisions

### 4.1 Featurization as composable stages

rsfff's `FlatLambdaSOAPFeaturizer.forward` has accumulated modes (`group_idx`,
`also_ungrouped`, `also_cross`, `edge_weight`), and `film/projector.py` already reaches into
private helpers (`_build_cross_power_spectrum_specs`) to get at the stages. bb makes the stages
the public API:

```
graph      edge_index = radius_graph(positions, cutoff, group)               # bb.graph
expand     RY = density.edge_expansion(positions, edge_index)                # shared, computed once
scatter    A  = density.scatter_species(RY, ..., edge_mask | edge_weight)    # or scatter_weighted(atom_weights)
compress   A  = compress(A)                                                  # optional channel projection
contract   feats = spectra(A, lambdas) [+ bispectrum(A)] [+ cross(A_in, A_env)]
```

The featurizers become thin compositions:

- **`SOAPFeaturizer`** is today's `FlatLambdaSOAPFeaturizer` default path, used by pf, hbq and
  the rsfff MLIP.
- **`StateSOAPFeaturizer`** takes the channel axis from caller-supplied `atom_weights`
  (rsfff's monomer stack).
- **`PartitionedFeaturizer`** takes one graph, a per-edge membership `s ∈ [0,1]` (or a
  callable on the edge list), and returns `(P(A(s)), P(A(1−s)), cross)`. This is the generic
  form of rsfff's grouped/cross/soft-partition modes and of the FiLM projector's three blocks,
  and it keeps the exact-zero environment guarantee for isolated groups. rsfff's
  `FragmentProjector` then only builds `s` from its `StateDescriptor`.

The featurizer stays a `torch.compiler.disable` boundary, as it is now.

### 4.2 `IrrepFeatures` instead of fixed `inv / equiv / vec` fields

`LambdaFeatures` hard-codes λ ∈ {0, 1, 2}. bb stores `{l: (N, 2l+1, C_l)}` with parity, plus
`species_idx`, `batch_idx`, `edge_index`, and keeps `inv_feats` / `vec_feats` / `equiv_feats`
as read-only properties, so existing head code ports unchanged. This allows l = 3 outputs
(octupoles) and odd/even parity mixes without new fields.

### 4.3 External inputs are first-class (no restriction on where inputs come from)

Every bb module takes plain tensors. No module requires a project `Batch`; the `GraphBatch`
Protocol is only a convenience. Extra inputs enter in three generic ways:

| Mechanism | Generalizes | Example |
|---|---|---|
| **Concatenate invariants** to l=0 features or to the MLP input | `augment_inv`, rsfff field/pair invariants | `|E|`, total charge, `λ·λ` |
| **Append channels** at a given l | `augment_equiv`, `lambda_2e` | the λ⊗λ 2e block appended to `equiv_feats` |
| **Couple** an external irrep with learned channel reductions of the features via CG, giving l_out ∈ {0, 1, 2, …} | pf `vec_lambda_0e`, `vec_lambda_2e`; rsfff `state_invariants` (μ·v_k, Θ:G_k) | an electric field `E_i` (1o) coupled to the λ=1 features |
| **FiLM / concatenate conditioning** from an invariant vector | rsfff `ConditionedTrunk` | fragment charge/spin embedding |

External quantities can be per-atom, per-system (broadcast through `batch_idx`) or per-edge.
Computing them (fields from converged multipoles, cavity λ, state descriptors) is the project's
job. bb only guarantees that the coupling is equivariant. `bb.testing.assert_equivariant`
rotates the external inputs together with the positions.

**Watch out:** rsfff's `state_invariants` does its λ=2 contractions in Cartesian form on
purpose (the normalization-independence argument in its docstring). The bb coupler must keep
that behaviour, or prove it is equivalent, before rsfff switches to it.

### 4.4 Message passing, generalized

Start from the pf/hbq `EquivariantMessagePassing` (CG convolution, Bessel radial MLP with a
polynomial envelope, gate, fixed `avg_num_neighbors`, residual with zero-init output).
Generalize the hidden and output irreps from a hard-coded `0e + 2e` to any set derived from the
input `IrrepFeatures`, so l=1 is refined too. Add an optional per-node conditioning input.
The **default construction must reproduce the current module bit for bit and keep its parameter
names**, so existing pf/hbq checkpoints load. Refining l=1 is opt-in.

The e3nn and cue paths both go through `backend.wigner_3j` / `spherical_harmonics` today, so
parity holds by construction. Later, optionally, add a cue fused tensor-product path behind the
same interface.

### 4.5 Readouts: specified by irreps, not by physical meaning

There is one readout, `IrrepsReadout(in=IrrepFeatures, out="Kx0e + Mx1o + Px2e + …")`. It
applies the trick every existing head shares:
- An invariant MLP (on l=0 features, the embedding and any external invariants) produces
  per-channel gates.
- A learned channel reduction contracts each l block without mixing m, so the output is
  equivariant at any l.
- Options: hidden width and depth, zero-init output, per-species bias on the scalars, and a
  shared or per-l channel reduction.

Physical meaning is assigned by the caller. A "charge" is a `1x0e` output, a "dipole" a `1x1o`,
and a "polarizability" a `1x0e+1x2e`. Output transforms are separate, generic functions:
- `pool(x, batch_idx, "sum" | "mean")`.
- `constrain_sum(x, batch_idx, target)`: shifts per-atom scalars so they sum exactly to a
  per-system target. hbq uses this for charges.
- `to_cartesian(x, "ij=ji")`: irreps → Voigt or a symmetric matrix.
- `psd_project`: the `min_eig` floor used for polarizabilities.

Each drifted head (pf `AtomicAlpha/Response/Vector/Scalar/RatioHead`, hbq
`AtomicVector/ScalarHead`, rsfff `AtomicEnergyHead`, `AtomicAlphaHead`, `AtomicQuadrupoleHead`)
must be reproducible as an `IrrepsReadout` configuration plus transforms. That equivalence is
what the golden tests check, and where it fails the readout gains an option rather than a
special-case head. Projects keep thin named wrappers (e.g. pf's `AtomicAlphaHead` = readout
`0e+2e` → `to_cartesian` → `psd_project`) so their checkpoints keep their key paths.

Compositions with physical meaning stay in the projects:
- hbq's `Σ q_i r_i + Σ p_i` dipole.
- pf's ratio head.
- The rsfff parameter families: bonded, Pauli, dispersion, FiLM response, EEM.

### 4.6 Ensembles

`bb.ensemble.Ensemble(members)` stacks member parameters with `torch.func.stack_module_state`
and runs one `vmap`ped forward, returning a leading member axis. It offers mean/std helpers and
forces via autograd through the stacked call. The current loops (hbq `BatchedCommittee`, pf
`CommitteeCalculator`) evaluate members one at a time; this does them all at once.

**Constraint:** members must share an architecture. The featurizer runs eager (a compile
boundary), and it holds no learned weights unless channel compression or the bispectrum is on,
so the plan is:
- Compute the neighbor graph and edge expansion once, outside the vmap.
- vmap the learned stages.

How a committee is found on disk stays per-project. rsfff's `committee_members` has the
staged-checkpoint ordering trap, so it should not be generalized.

### 4.7 Configs

- Use dataclasses with `from_dict` / `to_dict` and reject unknown keys.
- **Canonical names:** `cutoff`, `n_max`, `l_max`, `max_num_neighbors`, `density_channels`,
  `bispectrum: {...}`, `message_passing: {...}`, `backend`. These match the constructor
  arguments and rsfff.
- A permanent alias table maps pf/hbq names (`cutoff_radius`, `max_radial`, `max_angular`,
  `max_neighbors`) to the canonical ones, with a one-time warning, because checkpoint-embedded
  configs will always contain the old names.
- Project configs embed the bb configs (`FeaturizerConfig`, `BispectrumConfig`,
  `MessagePassingConfig`, `HeadConfig`). Each also gets a `build()` helper, so a model is
  "config → modules" in a few lines.

### 4.8 Numerical-stability contract

Checkpoints depend on exact numerics, so any change to the default numerical path of an
existing module is a breaking change. New behaviour goes behind a flag that defaults to the
old behaviour, and is recorded in a CHANGELOG. Environment variables are renamed `RSFFF_*` → `BB_*`,
and the old names are still read.

## 5. Building bb (phases)

0. **Freeze golden references (each repo, before touching anything).**
   - Write a script per repo that, for fixed geometries and seeds, saves in float64 and on both
     backends: the features (λ=0/1/2 and bispectrum), the MP outputs, the head outputs, and the
     full-model outputs.
   - Do this for the committed checkpoints: rsfff (`checkpoints/`, the v1 checkpoint,
     committees), pf (the QED committee members), and hbq (the dipole/energy committee).
   - These files are the acceptance test for every later step.
1. **Skeleton:** pyproject, src layout, pytest, ruff, CI on CPU (e3nn, plus cue-CPU for l ≤ 2),
   and a GPU marker for the fused cue kernels.
2. **Lift the shared core:**
   - Start from rsfff's versions, since they are the superset: `backend`, `bispectrum`, radial,
     density, spectra, neighbors, and `torch_compat`.
   - Port the tests: rsfff `test_neighbors`, `test_invariance`, backend parity; pf
     `test_features_fallback`.
   - Fold in pf's `_warn_if_neighbor_cap_binds` behaviour wherever it differs from rsfff's
     cap check.
3. **Featurizers as compositions:** `IrrepFeatures`, `SOAPFeaturizer`,
   `StateSOAPFeaturizer`, `PartitionedFeaturizer`. Golden tests against all three repos.
4. **`nn`:** mlp, init/tagging, FiLM, two-slot, embeddings; message passing (default path
   bit-identical, then the generalized irreps). Port pf `test_message_passing`.
5. **Inputs and heads:** reconcile the drifted heads (diff each one, build a superset with
   flags, run a golden test per original variant); write the coupling module; build
   `bb.testing`.
6. **Configs + `build()` helpers**, the reference `EnergyModel`, and `Ensemble`. Test that the
   vmapped forward matches a loop over the members.
7. **Tag `v0.1.0`**, then port the projects (§6) in the order hbq → pf → rsfff:
   - hbq first: it is the smallest pure consumer and its copies are identical to pf's.
   - pf next.
   - rsfff last: it is the largest and exercises the partition/state APIs.

   rsfff's needs still shape the API from phase 2 on. It is only *switched over* last.

## 6. Porting each project

General recipe per project:
1. Add `bb` to dependencies.
2. Replace imports.
3. Delete the copies.
4. Keep thin re-export shims for one release so notebooks and scripts don't break.
5. Run the golden tests and the full test suite.
6. Load every committed checkpoint and compare against the golden outputs.

### 6.1 rsfff

| From | To | Notes |
|---|---|---|
| `features/equivariant_backend.py`, `weighted_bispectrum.py` | `bb.o3.backend`, `bb.features.bispectrum` | Delete. `rsfff.features` becomes a re-export shim |
| `features/features.py` | `bb.features.*` | Split by stage (4.1). The `also_*` / `edge_weight` modes become `PartitionedFeaturizer` |
| `neighbors.py` | `bb.graph.neighbors` | `ff/pairs.py` also imports it |
| `mlip/heads.py`: `mlp`, `zero_init_readout`, `exempt_*`, `mark_env_slot` / `env_parameters` / `core_parameters`, `TwoSlotLinear`, `two_slot_mlp`, `slot_reduce` | `bb.nn.*` | `AtomicEnergyHead` → a `1x0e` `IrrepsReadout` |
| `mlip/response_heads.py` | `bb.heads` (readout + transforms), `bb.o3.cartesian` | Alpha / vector / quadrupole heads become readout configurations; rsfff keeps named wrappers |
| `ff/film/conditioning.py` | `bb.nn.conditioning` | Generic as written |
| `ff/state_invariants.py` | `bb.inputs.coupling` | Keep the Cartesian l=2 contraction (see 4.3) |
| `mlip/reference_states.AtomWeightNet` | `bb.features.compress` | `ReferenceEmbedding` and `AtomicStateReference` stay (SQE baseline and QC anchors are physics) |
| `mlip/model.py` (`EnergyModel`) | `bb.models.energy` | Reference composition |
| *Decide during port:* `mlip/pair_heads.PairEnergyHead`, `mlip/unified_head`, `mlip/switch.py` (smoothstep), `ff/environment.environment_pair_invariants` | maybe `bb.heads.pair`, `bb.nn.functional`, `bb.inputs` | Generic in form; keep in rsfff unless a second consumer appears |

What stays and gets rewired:
- `ff/film/projector.py` keeps only the construction of `s`/`P_edge` from `StateDescriptor`.
- `film/network.py`, `film/heads.py`, `bonded.py`, `permanent.py`, `decoder.py` and the
  `dispersion` / `pauli` / `electrostatics` heads use `bb.nn` / `bb.heads`.
- The `train/build_*` functions build from bb configs.
- `ff/v1/` imports from the live tree (`mlip.heads`), so it will follow the moved functions
  through the shim. `tests/test_v1_checkpoint.py` is the canary and must stay green. Do not edit
  v1 itself.

Also:
- `rsfff_active_learning`, `qchem_roundtrip` and `md/similarity.py` only need import updates.
- Configs already use the canonical names, so the YAMLs need no change.
- Effort: largest. The API risk sits in the projector / partition split and the
  `state_invariants` coupling.

### 6.2 pauli_fierz_pinn

| From | To | Notes |
|---|---|---|
| `equivariant_backend.py`, `weighted_bispectrum.py`, `features_native.py`, `torch_compat.py` | bb | Delete (a subset of rsfff's) |
| `models/message_passing.py` | `bb.nn.message_passing` | Default path bit-identical; `count_neighbors` / `dataset_average_num_neighbors` → `bb.graph.stats` |
| `models/heads.py`: `mlp`, `min_eig_sym3x3`, Voigt matrices, `AtomicAlpha/Response/Vector/Scalar/RatioHead` | `bb.heads` (readout + transforms), `bb.o3.cartesian` | Thin named wrappers stay in pf (ratio logic is pf's) |
| `models/heads.py`: `lambda_2e`, `lambda_invariant`, `vec_lambda_0e/2e`, `augment_inv/equiv` | `bb.inputs.coupling` (+ thin pf wrappers named after λ) | Cavity polarization is just an external 1o input |
| `data.py` Voigt helpers | `bb.o3.cartesian` | `Batch` / `InMemoryDataset` / extxyz stay unless decided otherwise (§8) |

What stays:
- `models/{stage0,fluctuation,cavity_drude,cavity_mbd}.py`, rewired to import from bb.
- `drude_solver`, `interaction_tensors`, `damping`, `lambda_correction`, `pf_evaluator`,
  `loss`, `train_pf`, `calculator`, `mace_compat`, `uncertainty_analysis`, `mol_normality`,
  `dimer_sampling`.

Also:
- `train_pf.py` config parsing switches to the bb configs plus the alias table, so the ~60
  generated configs under `qed_roundtrip/training/generated_configs` keep loading unchanged.
- The pf repo still uses the `try: from .x / except ImportError: from x` dual-import pattern.
  The port is a good moment to drop it in favour of the installed package.
- Effort: medium. Checkpoint keys (`featurizer.*`, `mp.*`, `species_emb`, heads) must be
  preserved or remapped.

### 6.3 hbq_qed

| From | To | Notes |
|---|---|---|
| `ml/equivariant_backend.py`, `weighted_bispectrum.py`, `features_native.py`, `torch_compat.py`, `message_passing.py` | bb | Byte-identical to pf: delete |
| `ml/heads.py`: `mlp`, `AtomicVectorHead`, `AtomicScalarHead`, `constrain_charges` | `bb.heads` (`IrrepsReadout`, `constrain_sum`) | The hbq variants differ from pf's; reconcile as readout options |
| `ml/heads.py`: `MolecularDipoleHead`, `MolecularEnergyHead` | stay in hbq | Rebuilt as compositions of `1x0e` / `1x1o` readouts + `constrain_sum` + `pool` |
| `ml/model.py`: `BispectrumConfig`, `MessagePassingConfig`, `FeaturizerConfig` | `bb.config` | These are the template for bb's configs. `DipoleModelConfig` stays and embeds them |

What stays: `DipoleModel` composition, `data`, `loss`, `train`, `ase_calculator`, and
everything outside `ml/`. `batched_committee` keeps its checkpoint discovery but evaluates
through `bb.ensemble`.

New capability, opt-in and a separate change: MP refinement of the l=1 channels that the dipole
heads read.

Effort: smallest. Do it first to validate the packaging and the shims.

## 7. Compatibility strategy

- **State dicts:** keep submodule attribute names in the ported modules (`channel_proj`,
  `density`, `bispectrum`, `mp.lin_in0`, `mp.convs.*`, …). The CG and lookup buffers are
  non-persistent, but `BesselBasis.freqs` is a persistent buffer, so its key path must survive too. Wherever a rename is unavoidable, use
  `bb.compat.remap_state_dict(sd, rules)`; each project ships its own rule table. If necessary,
  use a `_load_from_state_dict` hook on the bb module.
- **Configs:** keep the permanent alias table (4.7).
- **Acceptance:** every checkpoint in each repo loads and matches the phase-0 golden outputs.
  The tolerance is ~1e-12 in float64 (bitwise where the code path is unchanged) on both
  backends.
- **Installation:**
  - Development: `pip install -e ~/dev/bb` in each environment.
  - Clusters (NERSC, raven): pin a git tag, e.g. `pip install "bb @ git+…@v0.1.0"`, or an
    editable clone with `--no-deps` next to the site torch, mirroring rsfff's current
    instructions.

## 8. Decisions (agreed 2026-10-12)

1. **Data containers:** bb defines only the `GraphBatch` Protocol and the ragged-batching
   helpers. Dataset parsing (extxyz key maps, caches) stays in the projects.
2. **Config names:** rsfff's are canonical (`cutoff`, `n_max`, `l_max`,
   `max_num_neighbors`), with a permanent alias table for the pf/hbq names.
3. **Checkpoints:** strict compatibility. Old checkpoints load into bb modules, by kept key
   paths or by remap rules.
4. **Readouts:** generic and specified by irreps (4.5). bb has no charge or dipole heads;
   physical meaning and compositions live in the projects.
5. **Periodic boundary conditions:** the `radius_graph` signature accepts `cell` / `pbc` /
   shifts now; the implementation comes later.
6. **Ensembles:** `bb.ensemble.Ensemble` is in scope (4.6).
7. **Message passing:** generalized to arbitrary irreps (4.4), with the current 0e+2e default
   path bit-identical.

## 9. Status (2026-10-13)

Phases 0–6 are done in this repo. All three projects are ported: hbq_qed and pauli_fierz_pinn
on branch `bb-port`, rsfff on branch `bb-port` off `nonreactive`.

- **Phase 0.** Golden references were captured from rsfff `b7b24c4`, pauli_fierz_pinn
  `0d0dbc6` and hbq_qed `09ac834` by `tools/golden/capture.py`, into `tests/golden/data`.
- **Phases 1–6.** `bb.graph`, `bb.o3`, `bb.features`, `bb.nn` (including generalized message
  passing), `bb.inputs`, `bb.heads`, `bb.config`, `bb.models`, `bb.ensemble`, `bb.testing`
  and `bb.compat` are all in place.
- **Golden parity.** Every featurizer mode, message passing, every head, the pf λ couplings,
  and the featurizer + message passing of six real pf/hbq checkpoints reproduce the original
  outputs to 1e-10 in float64, on e3nn and cue.

Departures from the plan above:

- **Heads.** There are no named heads in bb. Each old head is an `IrrepsReadout`
  configuration plus transforms, and `docs/porting.md` has the wrapper template and key rules.
- **Coupling.** `bb.inputs.couple` uses isometric normalization. pf's `vec · λ` and `|λ|²`
  are `sqrt(3) ×` the bb `0e` coupling; the `2e` couplings match exactly.
- **Ensemble.** `Ensemble` vmaps the forward and the forces of whole models: the parameter-free
  stages run once because their inputs are unbatched. It falls back to a loop when a member
  is not vmap-compatible.

- **Ports.** hbq_qed (`bb-port`, −2075/+167 lines) and pauli_fierz_pinn (`bb-port`, −2915/+593)
  depend on `bb-black-box`. Every checkpoint, every YAML config, pf stage0, the pf calculator
  and the hbq committee reproduce their pre-port outputs to 1e-9 in float64 on e3nn and cue
  (whole-model goldens). Test suites match their pre-port baselines.
- **Neighbor truncation.** The old pf/hbq torch fallback kept the first `max_num_neighbors`
  neighbors by index, not the nearest. bb defaults to nearest; both projects pass
  `neighbor_truncation="index"` so existing checkpoints (cap 32 at 6 Å) rebuild identically.
- **Package name.** PyPI `bb` is an unrelated project, so the distribution is `bb-black-box`
  (import name `bb`).
- **rsfff** (`bb-port` off `nonreactive`, −3267/+482 lines): features, neighbor lists, head
  utilities, FiLM conditioning, the fragment projector and `AtomWeightNet` come from bb; the
  response heads are `IrrepsReadout`s. Whole-model goldens (8 loadable checkpoints, 13 configs)
  match to 1e-9; tests match the pre-port baseline. bb gained `IrrepFeatures.replace` with the
  old field names and `bb.compat.upgrade_state_dict` (for warm starts that match keys by name).

Next: merge the `bb-port` branches once you have run them on real workloads; then drop the
one-release aliases (`rsfff.features`, `rsfff.neighbors`, the re-exports in `rsfff.mlip.heads`).
