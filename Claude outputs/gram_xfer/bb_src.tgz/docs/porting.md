# Porting rsfff, pauli_fierz_pinn and hbq_qed onto bb

Every replacement below has a golden test: the original module's state dict loads into the bb
module and reproduces the original outputs to 1e-10 in float64, on both backends
(`tests/golden/test_golden.py`). That test file is also the most precise reference for how
each old call maps to bb.

## General recipe (per project)

1. Add bb to the project's dependencies as `"bb-black-box"` -- the *distribution* name; the
   import name is `bb`. ("bb" on PyPI is an unrelated Bitbucket CLI, which `pip install .`
   of a dependent project would otherwise fetch.) bb is not on PyPI, so install it first:
   - In development: `pip install -e ~/dev/bb`.
   - On a cluster: pin a tag, `pip install "bb-black-box @ git+…@v0.1.0"`.
2. Replace imports per the tables below. For one release, keep the old module paths as
   one-line shims (`from bb.features import *`) so scripts and notebooks keep working.
3. Delete the copied files.
4. Run the project's own test suite.
5. Load every committed checkpoint and compare a forward pass with the output from before
   the port. Capture that reference *before* step 2.

## Things that are identical by construction

- **Featurizer.** `bb.features.SOAPFeaturizer` *is* the old `FlatLambdaSOAPFeaturizer`, and
  that name remains as an alias. It has the same constructor arguments, plus
  `max_neighbors=` as an alias of `max_num_neighbors=`, and the same state-dict keys
  (`density.radial.freqs`, `channel_proj`, `bispectrum.*`).
  - `forward(batch, group_idx, also_cross=..., also_ungrouped=..., edge_weight=...)` keeps
    rsfff's modes.
  - The private stage methods rsfff's projector called (`_build_edges`, `_compress`,
    `_features_from_density`, `_run_bispectrum`) still exist. They are now public as
    `build_edges`, `compress`, `contract` and `run_bispectrum`.
- **Feature container.** The featurizer returns `IrrepFeatures`. `inv_feats`, `equiv_feats`,
  `vec_feats`, `species_idx`, `batch_idx` and `edge_index` still work, so heads written
  against `LambdaFeatures` need no change. `bb.features.LambdaFeatures` constructs one from
  the old keywords.
- **Message passing.** `bb.nn.EquivariantMessagePassing(p0=, p2=, emb_dim=, cutoff=,
  backend=, layers=, channels=, lmax=, num_basis=, radial_hidden=, avg_num_neighbors=)` and
  `mp(inv, equiv, positions, edge_index, emb)` behave exactly as before, with the same
  parameter names.
  - The new form, `irreps_in=..., hidden_irreps="0e+1o+2e"` called as `mp(feats, positions,
    emb=...)`, also refines `1o` (opt in: it changes the model).
  - `count_neighbors` and `dataset_average_num_neighbors` become `bb.graph.count_neighbors`
    and `bb.graph.average_num_neighbors(batches, cutoff)`.
- **Neighbor lists.** `rsfff.neighbors` becomes `bb.graph`.
  - The environment variables are now `BB_STRICT_NEIGHBORS` / `BB_NEIGHBOR_CAP_CHECK`; the
    `RSFFF_*` names are still read.
  - pf/hbq's inline fallback lists the same edges in a different order, which changes
    features only in the last bits.

## Heads become readouts + transforms

A named head is now a few lines in the project: an `IrrepsReadout`, a transform, and a key map
so old checkpoints load. Template (pf `AtomicAlphaHead`):

```python
from bb.compat import register_legacy_keys
from bb.heads import IrrepsReadout, psd_symmetric, to_voigt

class AtomicAlphaHead(torch.nn.Module):
    def __init__(self, p0, p2, emb_dim, *, hidden=64, depth=2, equiv_channels=32,
                 positive_isotropic=False, psd_floor=1e-4, own_reduce=True, irrep6_to_voigt=None):
        super().__init__()
        self.r = IrrepsReadout({"0e": p0, "2e": p2}, "1x0e + 1x2e", scalar_dim=emb_dim,
                               hidden=hidden, depth=depth, reduce_channels=equiv_channels,
                               reduce=own_reduce, zero_init=False)
        # old checkpoints: heads.alpha.base_mlp.* -> heads.alpha.r.mlp.*, etc.
        register_legacy_keys(self, [("base_mlp.", "r.mlp."), ("equiv_reduce", "r.reduce.2e")])
        ...

    def forward(self, inv, emb, equiv):
        y = self.r({"0e": inv.unsqueeze(1), "2e": equiv}, emb)
        y0, y2 = y["0e"][:, 0, :], y["2e"][..., 0]
        if self.positive_isotropic:
            return psd_symmetric(y0, y2, floor=self.psd_floor, smooth=0.05)  # rsfff: smooth=None
        return to_voigt(y0, y2)
```

The `register_legacy_keys` hook renames old keys on load, wherever the head sits in the model.
A checkpoint key such as `heads.alpha.base_mlp.0.weight` therefore lands in
`heads.alpha.r.mlp.0.weight`. Keys already in the new form pass through untouched. The rules
below are written relative to the readout itself, so prefix each target with `r.` when the
readout is held as `self.r`, as in the template.

| Old head | Readout | Transform | Key rules |
|---|---|---|---|
| pf/rsfff `AtomicAlphaHead` | `{0e,2e} → 1x0e+1x2e`, `zero_init=False` | `to_voigt` or `psd_symmetric` (pf: `smooth=0.05`; rsfff: `smooth=None`) | `base_mlp.→mlp.`, `equiv_reduce_env→reduce_env.2e`, `equiv_reduce→reduce.2e` |
| pf `AtomicResponseHead` | `{0e,2e} → Cx0e+Cx2e`, `reduce=False`, `gate_layout="interleaved"`, `zero_init=False` | `to_voigt(y0.transpose(1,2), y2.transpose(1,2))` | `base_mlp.→mlp.` |
| pf/hbq/rsfff `AtomicVectorHead` | `{0e,1o} → 1x1o` | none | `gate_mlp.→mlp.`, `equiv_reduce(_env)→reduce(_env).1o` |
| rsfff `AtomicQuadrupoleHead` | `{0e,2e} → 1x2e` | `@ irrep2_to_spherical` | as the vector head, with `2e` |
| pf `AtomicScalarHead` | `{0e} → 1x0e`; `set_scalar_bias(inverse_softplus_floor(init, floor))` | `softplus_floor` (positive) or none | none |
| pf `AtomicRatioHead` | `{0e} → 1x0e`; `set_scalar_bias(logit_bounded(v_init, lo, hi))` | `bounded` | none |
| hbq `MolecularDipoleHead` | `1x0e` (charges) + `1x1o` (atomic) | `constrain_sum`, `first_moment` | `charge_head.mlp.→…`, `vector_head.gate_mlp.→…` |
| hbq `MolecularEnergyHead` | `1x0e`, `species_bias=n_species` | `pool(...) + reference` | `bias→species_bias` (reshape `(S,)→(S,1)`) |
| rsfff `AtomicEnergyHead` | `{0e} → 1x0e`, `scalar_dim=emb_dim` | none (embedding stays outside) | none |

Two-slot (environment) heads pass `env_widths={"0e": p_env, "2e": p2_env}` and give the readout
the *joined* widths. The `TwoSlotLinear` keys (`w_frag`, `w_env`, `w_tail`, `bias`) are
unchanged. A block without the environment channels is evaluated as isolated, exactly as
before.

## External inputs

| pf helper | bb |
|---|---|
| `lambda_invariant(lam)` | `sqrt(3) * bb.inputs.self_couple(lam, 0)` (or just `(lam**2).sum(-1)`) |
| `lambda_2e(lam, v2i)` | `self_couple(lam, 2)` |
| `vec_lambda_0e(vec_k, lam)` | `sqrt(3) * couple(vec_k, lam, 0)[:, 0]` |
| `vec_lambda_2e(vec_k, lam, v2i)` | `couple(vec_k, lam, 2)` |
| `augment_inv` / `augment_equiv` | `feats.cat({"0e": ..., "2e": ...})` |
| `irrep6_to_voigt_matrix()` / `voigt_to_irrep6_matrix()` | `bb.o3.irrep6_to_voigt()` / `bb.o3.voigt_to_irrep6()` |
| `voigt_vector_to_symmetric_matrix` / reverse | `bb.o3.voigt_to_matrix` / `bb.o3.matrix_to_voigt` |

`rsfff.ff.state_invariants` stays in rsfff for now: it contracts rank-2 quantities in
rsfff's own spherical convention, in Cartesian form on purpose. The bb equivalent, for new
models, is `IrrepCoupling` on inputs converted to the backend basis.

## Per project

### hbq_qed -- done (branch `bb-port`)

- Deleted `ml/{equivariant_backend,weighted_bispectrum,features_native,torch_compat,message_passing}.py`.
- `ml/heads.py`: `AtomicVectorHead`, `AtomicScalarHead`, `MolecularEnergyHead` are
  `IrrepsReadout` subclasses with legacy-key hooks; `MolecularDipoleHead` composes them with
  `constrain_sum` + `first_moment`. Old attribute names (`gate_mlp`, `bias`) are read-only aliases.
- `ml/model.py`: `FeaturizerConfig` / `MessagePassingConfig` / `BispectrumConfig` are bb's.
  Old keys still parse; hbq's historical defaults (`n_max=5`, index-order neighbor
  truncation) are passed as `from_dict(..., defaults=...)`. The top-level `backend` stays the
  model's single source of truth.
- Message passing refines `0e + 2e` (as before) unless `message_passing.hidden_irreps` says
  otherwise -- `"0e + 1o + 2e"` refines the 1o features the dipole heads read (a new model).
- `batched_committee.BatchedCommittee` keeps its checkpoint discovery and evaluates the
  committee through `bb.Ensemble.energy_and_forces(..., call=..., return_outputs=True)`: one
  vmapped forward + gradient for all members.
- Verified: the real `checkpoints/dipole_e3nn`, every YAML config (randomized weights), and
  a two-member committee saved in the *old* checkpoint format through `BatchedCommittee`
  reproduce the pre-port outputs (energies, forces, dipoles, charges) to 1e-9; the ML test
  suite passes as before (on synthetic data where the real data is not in the checkout).

### pauli_fierz_pinn -- done (branch `bb-port`)

- Deleted `equivariant_backend.py`, `weighted_bispectrum.py`, `features_native.py`,
  `torch_compat.py`, `models/message_passing.py`, and `tests/test_features_fallback.py`
  (the fallback neighbor list is bb's, tested there).
- `models/heads.py`: every head is an `IrrepsReadout` subclass with legacy-key hooks and the
  old attribute names (`base_mlp`, `gate_mlp`, `equiv_reduce`) as aliases; the lambda helpers
  are thin wrappers over `bb.inputs`.
- Model configs (`Fluctuation`, `CavityDrude`, `CavityMBD`) carry a nested
  `featurizer: FeaturizerConfig` instead of eight flat fields. Checkpoints in either schema
  load (flat pre-port dicts, including the pre-knob neighbor cap of 32); the YAML `featurizer`
  block accepts both key spellings. `backend` and `use_lambda1` stay model-level settings and
  are applied to the featurizer at build (`resolved_featurizer`).
- The `try: from .x / except ImportError: from x` dual imports stay: the tests and scripts
  import the modules top-level.
- Verified: 11 real fluctuation checkpoints (e3nn/cue, MP, bispectrum, lambda=1), every YAML
  config including cavity_drude and cavity_mbd (randomized weights loaded through the
  legacy-key hooks), stage0, and `PauliFierzCalculator` energy/forces reproduce the pre-port
  outputs (all output tensors + forces) to 1e-9. Test suite: same results as before the port
  (three pre-existing failures unrelated to it); the model-level message-passing tests that
  used to skip without torch_cluster now run.

### rsfff -- done (branch `bb-port`, off `nonreactive`)

- Deleted `features/{features,equivariant_backend,weighted_bispectrum}.py` and
  `ff/film/conditioning.py`. `rsfff.features` remains a re-export of `bb.features` / `bb.o3`
  backends, and `rsfff.neighbors` *is* `bb.graph.neighbors` (a module alias, so `set_strict`,
  `CAP_EVENTS` and monkeypatching act on the real module). Code in `src/` and the tests imports
  from bb directly.
- `mlip/heads.py` keeps `AtomicEnergyHead` and re-exports the bb.nn utilities under their old
  names (`from rsfff.mlip.heads import env_parameters` still works); its docstring keeps the
  measured weight-decay history behind `zero_init_readout`. `term_loop.parameter_groups` and
  `reference_states.AtomWeightNet` are bb's, re-exported.
- `mlip/response_heads.py`: `AtomicAlphaHead`, `AtomicVectorHead`, `AtomicQuadrupoleHead` are
  `IrrepsReadout` subclasses (two-slot via `env_widths`), with legacy-key hooks and the old
  attribute names (`base_mlp`, `gate_mlp`, `equiv_reduce`, `equiv_reduce_env`) as aliases.
  `AxialQuadrupolePolarizabilityHead` is unchanged around them.
- `ff/film/projector.FragmentProjector` is a thin `PartitionedFeaturizer` subclass (membership =
  the state's `edge_comembership`; still refuses `cross_lambdas` without 0);
  `ProjectedFeatures` is `PartitionedFeatures`.
- `dataclasses.replace(feats, inv_feats=...)` on the feature container became
  `feats.replace(inv_feats=...)` (`IrrepFeatures` is not a dataclass; its `replace` takes the
  old field names).
- `term_loop.warm_start` matches checkpoint keys by name, so it now runs
  `bb.compat.upgrade_state_dict` first -- otherwise an old checkpoint's heads would read as "not
  in this model" and be dropped silently. Its dead-reduction guard recognizes both
  `equiv_reduce` and `reduce.<irrep>`; so does `scripts/staged_diagnostics.py`.
- `pyproject.toml` depends on `bb-black-box` (cue extras defer to bb's); `scripts/make_env.sh`
  installs the bb checkout (`BB_DIR`, default `../bb`) before rsfff.
- Verified (whole-model goldens, float64, tolerance 1e-9 relative): the 8 committed
  checkpoints that load on `nonreactive` (water film x3, nonvariational x2, `water_staged`,
  ion mediator v4 x2 including `mixture_forward` with and without induction) and all 13 YAML
  configs (film, nonvariational, expert, mediator, unified; perturbed weights loaded through
  the legacy-key hooks), every output tensor + forces; a fresh seeded model initializes
  identically to the pre-port one. The other 11 checkpoints (older expert/mediator layouts)
  already fail to load on `nonreactive`. Test suite: 739 passed, the same 35 failures / 24
  errors as before the port (missing Q-Chem fixtures, stale pinned values), plus two new tests
  for old-key loading and `warm_start`.
