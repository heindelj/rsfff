# Edge cluster expansion (ECE) in bb

`bb.features.EdgeClusterExpansion` computes invariant features for each bond of a caller-supplied
topology, in that bond's own frame. It is the bonded-region model of the bonded/nonbonded split
(see the "bb — Edge Cluster Expansion (ECE) implementation plan" doc). This note records what is
implemented, how it relates to the two published edge cluster expansions, and what is still open.

## What is implemented

| Module | Contents |
|---|---|
| `bb.graph.bonded` | `bond_graph(bonds, n_atoms)`: directed edges, reverse index, near/far neighbour-edge pairs. `line_graph`: bond pairs that share an atom, with orientation signs σ. `covalent_bonds`: topology perception from one reference geometry. `COVALENT_RADII` (Cordero 2008). |
| `bb.o3.frames` | `edge_frames` (two-chart R_e, never singular), `calibrate` / `frame_convention` (polar axis and ±m pairing, checked per backend), `wigner_d_recursive` (CG recursion on `backend.wigner_3j`), `MIndex`. |
| `bb.features.radial.MorseBasis` | `y**n`, `y = exp(-a (r/r0 - 1))`, r0 per species pair (covalent sums, tabulated, or learned). |
| `bb.features.edge` | `EdgeClusterExpansion` → `EdgeFeatures` (`inv0e`, `inv0o`, `bond_radial`, species, frames, graph). |
| `bb.heads.edge` | `EdgeScalarReadout`: invariant MLP per directed edge, summed (`sym`) or subtracted (`antisym`) over the two directions, pooled per system; `bond_basis=q` makes the r_ij dependence an explicit Morse expansion. `EdgeReadout`: equivariant outputs of any irreps per bond (parity rule below), rotated back with Wigner-D. `bond_to_atoms`, `flow_to_charges`. |
| `bb.features.edge_basis` | `EdgeBodyOrderBasis`: the explicit, linear, body-ordered bond basis (below). |
| `bb.linear` | Rows of linear models for energies, forces and Hessians at any geometry; streaming ridge normal equations; nested (order-by-order) solves. |
| `bb.config` | `EdgeFeaturizerConfig`, `EdgeReadoutConfig`, `EdgeBasisConfig` with `build()`. |

Features for the directed bond i→j, with near = bonded neighbours of i except j and far = bonded
neighbours of j except i, both in the frame R_e that puts r̂_ij on the polar axis:

- ν = 0: Morse basis of r_ij (species of i and j enter in the readout).
- ν = 1: the m = 0 channels of near and far (bond angles).
- ν = 2: Re and Im of z^near_m · conj(z^far_m) (torsions: cos mω and sin mω), the same between two
  projections of one end (impropers, angle–angle), and m = 0 × m = 0 products.

Re parts are 0e and Im parts are 0o. At ν = 2 this is the complete set of O(2) invariants of the
two densities (per channel pair; bb uses channel-wise "uu" products). Everything is exact: O(3)
invariance, gauge (azimuth) invariance and backend parity hold to ~1e-12 in float64.

## Relation to the published ECEs

Two papers use the name:

- **TACE / TECE**: Xu, Xie & Hu, *Edge Cluster Expansion with Radial Rotary Attention for
  Interatomic Potentials*, arXiv:2607.10664; code github.com/xvzemin/tace (MIT).
- **ECENet**: LaCour & Head-Gordon, *ECENet: An Edge Cluster Expansion Line-Graph Neural Network*,
  arXiv:2609.23134; code github.com/THGLab/ECEnet (UC Regents license: use, copy, modify and
  distribute with the notice retained).

Both build the edge feature the same way: compute each atom's ACE density
A_i = Σ_k R(r_ik) Y(r̂_ik) over all neighbours within a cutoff, concatenate A_i and A_j, and rotate
the pair into the edge frame with Wigner-D. On a bond graph that is exactly bb's near/far
densities plus one on-axis self term per end (the partner atom). On the axis Y_lm is pure m = 0,
so the self term is a function of r_ij and the two species only, which is a ν = 0 bond feature.
`tests/test_edge.py::test_dense_route_matches_direct_route` checks this identity numerically. **At
the level of the edge-frame basis, bb's ECE and both published ones are the same object.** They
differ in four ways:

| | bb | TACE (TECE) | ECENet |
|---|---|---|---|
| Graph | Fixed bond topology, no cutoff | Radius graph | Radius graph (5 Å for edges and densities) |
| Density route | Direct: SH of neighbour bonds already in the edge frame | Dense: rotate node features with Wigner-D | Dense: rotate A_i, A_j with Wigner-D |
| Raising the body order | Explicit products, ν ≤ 2, m-matched only | Explicit O(2) CG products m₁⊗m₂ → \|m₁±m₂\| up to a chosen ν ("generalized asymmetric contraction") | SO(2)-linear layers + pointwise SiLU on an azimuthal θ-grid, residual; all orders, set by depth |
| Exactness | Exact | Exact | The grid nonlinearity commutes with rotations about the bond only for band-limited inputs, so invariance holds up to aliasing (see below) |
| Parity | 0e and 0o tracked | O(2) parity tracked (moving from SO(2) to O(2)) | Real weights shared by ±m and a symmetric grid keep O(2); energies read m = 0 only, so no 0o channel |
| Message passing | None | Edge → node (back-rotate, aggregate), attention with radial rotary phases | Edge → node → edge, optional |
| Readout | Per-edge MLP, both directions summed | Node readout | Per-edge MLP × cutoff envelope, both directions summed |
| Species | Radial ⊗ learned neighbour embedding | Node embeddings | Joint (type, n) → channel contraction with weights per central type; element-pair FiLM gate on the edge features |

So bb = the ECE of both papers, specialised to a topology graph and truncated at ν = 2. At ν = 2
nothing is lost: for invariant outputs the only O(2)-coupling paths of two inputs are the m-matched
ones bb computes. The two papers diverge from bb at ν ≥ 3, where products such as
z₁ z₁ conj(z₂) (m = 1 + 1 − 2) appear. TACE enumerates those paths explicitly. ECENet gets them
implicitly from the grid nonlinearity: SiLU(f(θ)) contains every power of f, so its m = 0 Fourier
coefficient contains every m-balanced product.

On exactness: SiLU of a band-limited f(θ) is not band-limited, so the m = 0 output of a
pointwise nonlinearity sampled at N = 4·m_max + 1 points depends on the frame's azimuth through
the aliased Fourier coefficients at multiples of N. A stand-alone replica of ECENet's
`RealSpaceNonlinearity` (m_max = 3, N = 13, random coefficients) gives a gauge error of 6e-5
relative at coefficient amplitude 0.1, 3e-3 at 0.3 and 6e-2 at 1.0. ECENet's own SO(3) test passes
at 1e-9, but at initialization, where the readout is near zero; their trained models were not run here.
For a bonded force-field model, where smooth exact symmetry matters more than raw capacity, this is
a reason to raise the order with explicit products (TACE's route) rather than a grid nonlinearity,
or to use a much finer grid.

Class II force fields need ν ≤ 2 within one bond (bond–angle, angle–angle, angle–torsion,
torsion), so ν = 2 should be enough for the Phase 3 gate. Couplings between torsions on two
different bonds (CMAP-like φ/ψ) span two edges and need ν ≥ 3 on the edge or message passing on
the line graph.

## Readout and the 0o block

A pseudoscalar can only enter an invariant energy through an even function. `EdgeScalarReadout`
offers `odd="symmetrize"` (default: average the MLP at +o and −o, which keeps every even function,
products of different pseudoscalars included, at twice the MLP cost), `"square"` (feed o², the
draft's choice; cheaper but loses cross products) and `"drop"`.

## Equivariant outputs (`EdgeReadout`)

In the frame of a directed bond the residual symmetry is O(2): rotations about the bond, and a
mirror containing it, which acts on every channel z_m = c[+m] + i c[−m] as complex conjugation.
An output irrep (l, p) splits into an m = 0 part, which is a scalar if the parity is natural
(p = (−1)^l: 1o, 2e, 3o) and a pseudoscalar otherwise (1e, 2o, 3e), and one 2-vector per
m = 1..l. With h_e and h_o the parts of an invariant MLP that are even and odd in the 0o features:

- natural: y_0 = h_e, y_m = Σ_c h_e,c z_m,c + h_o,c (i z_m,c)
- unnatural: y_0 = h_o, y_m = Σ_c h_e,c (i z_m,c) + h_o,c z_m,c

over the 4C m-channels of the ECE (two projections of each end); y is placed in the real-SH
layout and rotated back with D^l(R_e)ᵀ. Directions are added (`sym`) or subtracted (`antisym`:
bond dipoles along the canonical orientation; a `1x0e` antisymmetric output is a split-charge
flow, and `flow_to_charges` conserves the total charge exactly). Tested with rotations and
rotoinversions for 0e, 0o, 1o, 1e, 2e, 2o, 3o on both backends, plus gauge invariance and the
orientation sign. Output l is limited to the ECE's l_max.

## The explicit basis (`EdgeBodyOrderBasis`)

A basis function of bond i→j is b_q(r_ij) · Re Π_k z^{X_k}_{s_k n_k l_k m_k}, with the factors
species-resolved (one-hot) neighbour densities of the near or far end, some conjugated, and the
m's balanced. ν factors give (ν + 2)-body terms: ν = 1 angles and bond–angle/bond–bond couplings,
ν = 2 torsions, angle–angle, impropers, angle–torsion. A linear model on it is a force field whose
couplings are full functions of their internal coordinates. The space is truncated by total
polynomial degree q + Σ(n + l) per order. Construction rules that keep the columns distinct:

- bond types are unordered species pairs; heteronuclear bonds use their canonical direction,
  homonuclear bonds both directions summed, with near ↔ far equivalent spellings merged;
- a star (all neighbours on one end) is seen by every bond to its centre; it belongs only to the
  lowest bond type, and where an arm has the bond's own type the radial powers are ordered;
- a star function with q = 0 and only l = 0 factors does not involve the far atom and is left to
  the arm bonds; neighbour-count factors (n = 0, l = 0) are off by default (`count_factors`).

What can remain linearly dependent is the self-products inside one density (k = k′), which reduce
to lower orders when an end has one neighbour of that species. `bb.linear.nested_solve` fits the
orders in sequence, so each order is credited only with what lower orders cannot represent.

## Open items

- Bond-pair invariants on the line graph (split-charge kernel K).
- `EdgeReadout` uses m-channels linearly with invariant gates; covariant products
  (z_m1 z_m2 → m1 + m2) would make it smooth where single channels vanish.
- The fit on Q-Chem data (monomer-pilot): see `cl/python/scripts/ece_linear_fit.py`.
