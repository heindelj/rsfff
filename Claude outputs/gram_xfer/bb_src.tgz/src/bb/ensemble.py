"""Ensembles (committees) of identically-shaped models, evaluated together.

A committee of ``M`` members evaluated one at a time pays the Python and kernel-launch overhead
``M`` times per call -- for small systems (MD, path-integral beads) that overhead *is* the cost.
:class:`Ensemble` stacks the members' parameters and buffers along a new leading axis and runs one
``torch.func.vmap``-ed forward, returning every output with a leading member axis::

    ens = Ensemble([load(p) for p in member_paths])
    out = ens(positions=pos, atomic_numbers=z, batch_idx=b)       # out["energy"]: (M, B)
    mean, std = ens.mean_std(out["energy"])
    e, f = ens.energy_and_forces(pos, atomic_numbers=z, batch_idx=b)  # (M, B), (M, N, 3)

Inputs are shared by all members (not batched). Parts of a model that do not depend on the
parameters -- the neighbor search, the edge harmonics -- run once per call even under vmap,
because their inputs are unbatched.

Members must share an architecture (identical parameter names and shapes). If a member's forward
is not vmap-compatible (a data-dependent branch on a parameter-dependent value, an op without a
batching rule, a custom kernel), the ensemble falls back to a plain loop with one warning; pass
``mode="loop"`` to choose that up front. Where to find a committee's members on disk is the
project's business.
"""

from __future__ import annotations

import warnings
from typing import Any, Callable, Sequence

import torch
import torch.nn as nn
from torch.func import functional_call, stack_module_state

__all__ = ["Ensemble"]


def _stack_outputs(outs: list):
    first = outs[0]
    if isinstance(first, torch.Tensor):
        return torch.stack(outs)
    if isinstance(first, dict):
        return {k: _stack_outputs([o[k] for o in outs]) for k in first}
    if isinstance(first, (tuple, list)):
        return type(first)(_stack_outputs(list(z)) for z in zip(*outs))
    if first is None:
        return None
    raise TypeError(f"cannot stack outputs of type {type(first).__name__}")


class Ensemble(nn.Module):
    def __init__(self, members: Sequence[nn.Module], *, mode: str = "auto") -> None:
        super().__init__()
        if len(members) == 0:
            raise ValueError("an ensemble needs at least one member")
        if mode not in ("auto", "vmap", "loop"):
            raise ValueError(f"mode must be 'auto', 'vmap' or 'loop', got {mode!r}")
        ref = {k: tuple(v.shape) for k, v in members[0].state_dict().items()}
        for i, m in enumerate(members[1:], 1):
            shapes = {k: tuple(v.shape) for k, v in m.state_dict().items()}
            if shapes != ref:
                diff = sorted(set(shapes.items()) ^ set(ref.items()))[:5]
                raise ValueError(f"member {i} has a different architecture than member 0: {diff}")
        self.mode = mode
        self.members = nn.ModuleList(members)
        self._stacked: tuple[dict, dict] | None = None
        self._base = None

    def __len__(self) -> int:
        return len(self.members)

    # ------------------------------------------------------------------ stacking
    def _stack(self):
        # Re-stacked on every call so the ensemble always sees the members' current weights
        # (cheap next to a forward; members can be trained, moved or swapped in place).
        params, buffers = stack_module_state(list(self.members))
        # functional_call swaps the stacked tensors into member 0 for the duration of the call
        self._base = self.members[0]
        return params, buffers

    def _vmapped(self, fn: Callable[[nn.Module, tuple, dict], Any], args, kwargs):
        params, buffers = self._stack()
        base = self._base

        def call(p, b):
            return fn(lambda *a, **k: functional_call(base, (p, b), a, k), args, kwargs)

        return torch.func.vmap(call, in_dims=(0, 0), randomness="different")(params, buffers)

    def _looped(self, fn, args, kwargs):
        return _stack_outputs([fn(m, args, kwargs) for m in self.members])

    def _run(self, fn, args, kwargs):
        if self.mode == "loop":
            return self._looped(fn, args, kwargs)
        try:
            return self._vmapped(fn, args, kwargs)
        except Exception as exc:  # noqa: BLE001 -- any vmap incompatibility
            if self.mode == "vmap":
                raise
            warnings.warn(
                f"Ensemble: the members' forward is not vmap-compatible ({type(exc).__name__}: "
                f"{str(exc)[:200]}); evaluating them in a loop from now on.",
                RuntimeWarning, stacklevel=3,
            )
            self.mode = "loop"
            return self._looped(fn, args, kwargs)

    # ------------------------------------------------------------------ API
    def forward(self, *args, **kwargs):
        """Every member's output, stacked on a new leading axis."""
        return self._run(lambda model, a, k: model(*a, **k), args, kwargs)

    def energy_and_forces(
        self,
        positions: torch.Tensor,
        *args,
        energy_key: str = "energy",
        call: Callable[[Callable, torch.Tensor], Any] | None = None,
        return_outputs: bool = False,
        **kwargs,
    ):
        """Per-member energies ``(M, B)`` and forces ``-dE/dR`` ``(M, N, 3)``.

        By default each member is called as ``member(*args, positions=positions, **kwargs)``.
        For any other signature pass ``call(model, positions)``, where ``model`` is a callable
        standing in for one member (call it as you would the module). The result -- of the member
        or of ``call`` -- is a tensor (the energy) or a dict holding ``energy_key``.

        ``return_outputs=True`` also returns that dict, every tensor stacked on the member axis
        (detached), from the same evaluation: ``(energy, forces, outputs)``. Its values must be
        tensors (convert dataclass outputs to a dict inside ``call``).
        """
        if call is None:
            def call(model, pos):
                return model(*args, positions=pos, **kwargs)

        def split(out):
            if isinstance(out, dict):
                return out[energy_key], out
            return out, {energy_key: out}

        if self.mode != "loop":
            try:
                params, buffers = self._stack()
                base = self._base

                def per_member(p, b):
                    def member(*a, **k):
                        return functional_call(base, (p, b), a, k)

                    def total(pos):
                        e, out = split(call(member, pos))
                        return e.sum(), (e, out)

                    g, (e, out) = torch.func.grad(total, has_aux=True)(positions)
                    return e, -g, out

                e, f, out = torch.func.vmap(per_member, in_dims=(0, 0), randomness="different")(params, buffers)
                if return_outputs:
                    return e, f, {k: v.detach() for k, v in out.items() if v is not None}
                return e, f
            except Exception as exc:  # noqa: BLE001
                if self.mode == "vmap":
                    raise
                warnings.warn(
                    f"Ensemble: forces are not vmap-compatible ({type(exc).__name__}: {str(exc)[:200]}); "
                    f"evaluating members in a loop from now on.", RuntimeWarning, stacklevel=2,
                )
                self.mode = "loop"
        energies, forces, outs = [], [], []
        for m in self.members:
            pos = positions.detach().requires_grad_(True)
            with torch.enable_grad():
                e, out = split(call(m, pos))
                (g,) = torch.autograd.grad(e.sum(), pos, create_graph=m.training)
            energies.append(e if m.training else e.detach())
            forces.append(-g)
            outs.append({k: v.detach() for k, v in out.items() if v is not None})
        e, f = torch.stack(energies), torch.stack(forces)
        if return_outputs:
            return e, f, _stack_outputs(outs)
        return e, f

    @staticmethod
    def mean_std(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Committee mean and (unbiased, for M > 1) standard deviation over the member axis."""
        if x.shape[0] == 1:
            return x[0], torch.zeros_like(x[0])
        return x.mean(0), x.std(0)
