"""bb ("Black Box"): equivariant features and neural-network building blocks for MLIPs and
NN-parameterized physical models.

Subpackages
-----------
``bb.graph``     neighbor lists (with cap detection, periodic), pair graphs, flat-batch helpers,
                 graph statistics
``bb.o3``        irreps, the per-atom ``IrrepFeatures`` container, e3nn / cuequivariance backends,
                 Cartesian <-> irrep helpers
``bb.features``  radial bases, the neighbor density, power spectra / bispectra, featurizers
``bb.nn``        MLPs, init and weight-decay bookkeeping, parameter slots, FiLM, message passing
``bb.inputs``    coupling caller-supplied equivariant inputs (fields, polarizations, spins)
``bb.heads``     readouts specified by irreps, and generic output transforms
``bb.config``    dataclass configs with ``build(...)``
``bb.models``    a reference energy model
``bb.ensemble``  vmapped committees
``bb.linear``    least squares for linear models on energies, forces and Hessians
``bb.tr``        time-reversal parity: T+ / T- features, layers and message passing
``bb.testing``   equivariance checks
``bb.compat``    loading pre-bb checkpoints
"""

__version__ = "0.1.0.dev0"

from . import compat, config, features, graph, heads, inputs, linear, models, nn, o3, testing, tr  # noqa: E402
from .ensemble import Ensemble  # noqa: E402
from .o3 import Irrep, IrrepFeatures, Irreps, get_backend  # noqa: E402

__all__ = [
    "compat", "config", "features", "graph", "heads", "inputs", "linear", "models", "nn", "o3", "testing", "tr",
    "Ensemble", "Irrep", "IrrepFeatures", "Irreps", "get_backend", "__version__",
]
