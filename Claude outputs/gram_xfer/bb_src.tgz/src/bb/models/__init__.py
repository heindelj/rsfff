"""Reference model compositions."""

from .energy import EnergyModel, EnergyModelConfig

__all__ = ["EnergyModel", "EnergyModelConfig"]
