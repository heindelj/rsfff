"""Edge cluster expansion (ECE): invariant bond-frame features up to correlation order 2.

For each directed bond ``e = (i -> j)`` of a caller-supplied topology, the bonded neighbours of
``i`` (except ``j``) form the *near* density and those of ``j`` (except ``i``) the *far* density,
both expressed in the bond frame ``R_e`` (bond along the backend's polar axis)::

    A^near_{e,f,lm} = sum_{k in N(i)\\j} R_n(r_ik) w_{s_k,d} Y_lm(R_e r_ik)
    A^far_{e,f,lm}  = sum_{k in N(j)\\i} R_n(r_jk) w_{s_k,d} Y_lm(R_e r_jk)

with ``f = (n, d)`` a radial x neighbour-species-embedding channel and ``R_n`` a
:class:`~bb.features.radial.MorseBasis`. The residual symmetry is rotation about the bond, under
which ``z_{l,m} = A[l,+m] + i A[l,-m]`` picks up a phase ``exp(i m gamma)``. Per ``m``, a
real-weighted SO(2)-linear map mixes ``(f, l)`` into ``C`` channels (real weights commute with a
mirror containing the bond, which acts as complex conjugation, so O(2), hence O(3), parity is
exact). Invariants:

    nu = 0 : the bond itself (Morse basis of r_ij; species of i and j enter in the readout)
    nu = 1 : m = 0 channels of near and far                 -> bond angles
    nu = 2 : Re / Im of near_m * conj(far_m)                -> torsions, cos / sin(m omega)
             Re / Im of near_m * conj(near'_m) (same end)   -> impropers, angle-angle

Re parts and m = 0 products are ``0e``. Im parts are ``0o``: they flip sign under any improper
operation. At nu = 2 this is the complete set of O(2) invariants of the two densities, per
channel pair (here channel-wise, "uu").

Relation to the literature. This is the edge cluster expansion of Xu, Xie & Hu (TACE,
arXiv:2607.10664) and of ECENet (LaCour & Head-Gordon, arXiv:2609.23134) specialised to a bonded
topology and truncated at nu = 2 with explicit products. Both papers rotate each endpoint's full
atomic density (all neighbours within a cutoff) into the edge frame; on a bond graph that is the
near / far density here plus an on-axis self term (the partner atom), which is pure m = 0 and a
function of r_ij only, i.e. a nu = 0 bond feature. TACE then raises the order with explicit O(2)
Clebsch-Gordan products (m1 x m2 -> |m1 +- m2|); ECENet with SO(2)-linear layers and a pointwise
nonlinearity on an azimuthal grid. See ``docs/ece.md``.

Symmetry under ``i <-> j`` is not built into the features; readouts sum or subtract the two
directions (:class:`bb.heads.EdgeScalarReadout`).
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from ..graph.bonded import BondGraph
from ..o3.backend import EquivariantBackend, resolve_backend
from ..o3.frames import MIndex, edge_frames, frame_convention
from .radial import MorseBasis

__all__ = ["EdgeClusterExpansion", "EdgeFeatures", "PairClusterExpansion"]


@dataclass
class EdgeFeatures:
    """Per-directed-edge ECE output. Rows follow ``graph.edge_index``."""

    inv0e: torch.Tensor        # (E, F_0e)  even invariants
    inv0o: torch.Tensor        # (E, F_0o)  pseudoscalars (flip under improper operations)
    bond_radial: torch.Tensor  # (E, n_max) Morse basis of r_ij
    species_src: torch.Tensor  # (E,)
    species_dst: torch.Tensor  # (E,)
    frames: torch.Tensor       # (E, 3, 3)  R_e, global -> edge frame
    graph: BondGraph
    mblocks: dict | None = None
    """SO(2)-covariant channels for equivariant readouts: ``{side: [(re, im), ...]}`` per m (im
    is None at m = 0), sides ``na, nb`` (near) and ``fa, fb`` (far), each ``(E, C)``."""
    envelope: torch.Tensor | None = None
    """(E,) smooth cutoff of r_ij for cutoff-based pair graphs (:class:`PairClusterExpansion`);
    ``None`` for bonded topologies, which have no cutoff."""


class EdgeClusterExpansion(nn.Module):
    """Invariant ECE features on a bond graph.

    Parameters
    ----------
    atomic_numbers : atomic number of each species index (``species`` in :meth:`forward` indexes
                     this list).
    n_max          : Morse radial functions per neighbour.
    l_max          : maximum l (and m) in the edge frame. Torsion order n needs ``l_max >= n``.
    channels       : C, channels per m after the SO(2)-linear projection.
    species_dim    : learned neighbour-species embedding width.
    morse_a, r0, learn_r0 : passed to :class:`~bb.features.radial.MorseBasis`.
    backend        : ``"e3nn"`` or ``"cue"`` (spherical harmonics; the frame convention is
                     calibrated from it).
    """

    SIDES = ("na", "nb", "fa", "fb")  # two projections each of near and far

    def __init__(
        self,
        atomic_numbers,
        n_max: int = 6,
        l_max: int = 4,
        channels: int = 16,
        species_dim: int = 4,
        morse_a: float = 2.0,
        r0: torch.Tensor | None = None,
        learn_r0: bool = False,
        backend: "EquivariantBackend | str" = "e3nn",
    ):
        super().__init__()
        self.atomic_numbers = [int(z) for z in atomic_numbers]
        self.n_species = len(self.atomic_numbers)
        self.n_max, self.l_max, self.channels = n_max, l_max, channels
        self.backend = resolve_backend(backend)
        self.convention = frame_convention(self.backend)
        self.radial = MorseBasis(self.atomic_numbers, n_max, a=morse_a, r0=r0, learn_r0=learn_r0)
        self.nbr_emb = nn.Embedding(self.n_species, species_dim)
        self.n_feat = n_max * species_dim

        mi = MIndex.build(l_max)
        self.register_buffer("_m_zero", mi.zero, persistent=False)
        for m in range(1, l_max + 1):
            self.register_buffer(f"_m_plus{m}", mi.plus[m], persistent=False)
            self.register_buffer(f"_m_minus{m}", mi.minus[m], persistent=False)

        self.proj = nn.ParameterDict()
        for side in self.SIDES:
            for m in range(l_max + 1):
                nl = l_max - m + 1
                w = torch.randn(self.n_feat, nl, channels) / (self.n_feat * nl) ** 0.5
                self.proj[f"{side}{m}"] = nn.Parameter(w)

    # ------------------------------------------------------------------ #
    @property
    def dim_0e(self) -> int:
        return self.channels * (2 + 3 * (self.l_max + 1))

    @property
    def dim_0o(self) -> int:
        return self.channels * 3 * self.l_max

    def _geometry(self, positions, g: BondGraph, twist=None):
        src, dst = g.edge_index
        vec = positions[dst] - positions[src]
        r = vec.norm(dim=-1)
        unit = vec / r[:, None]
        frames = edge_frames(unit, self.convention, twist)
        return r, unit, frames

    def _density(self, pairs, r, unit, frames, species, g: BondGraph, bond_weight=None):
        e, e2 = pairs
        src, dst = g.edge_index
        u = torch.einsum("pij,pj->pi", frames[e], unit[e2])
        y = self.backend.spherical_harmonics(u, self.l_max)                # (P, nY)
        rad = self.radial(r[e2], species[src[e2]], species[dst[e2]])        # (P, n)
        emb = self.nbr_emb(species[dst[e2]]).to(r.dtype)                    # (P, d)
        f = (rad[:, :, None] * emb[:, None, :]).reshape(len(e), self.n_feat)  # (P, F)
        if bond_weight is not None:
            f = f * bond_weight.to(r.dtype)[g.bond_id[e2]][:, None]
        a = r.new_zeros(g.n_edges, self.n_feat, y.shape[-1])
        return a.index_add(0, e, f[:, :, None] * y[:, None, :])

    def densities(self, positions, species, g: BondGraph, twist=None, bond_weight=None):
        """Raw edge-frame densities ``(A_near, A_far)``, each ``(E, F, (l_max+1)**2)``."""
        r, unit, frames = self._geometry(positions, g, twist)
        return (self._density(g.near, r, unit, frames, species, g, bond_weight),
                self._density(g.far, r, unit, frames, species, g, bond_weight))

    def project(self, a: torch.Tensor, side: str):
        """SO(2)-linear projection: ``[x_0, (re_1, im_1), ..., (re_L, im_L)]``, each ``(E, C)``."""
        out = [torch.einsum("efl,flc->ec", a[:, :, self._m_zero], self.proj[f"{side}0"])]
        for m in range(1, self.l_max + 1):
            w = self.proj[f"{side}{m}"]
            re = torch.einsum("efl,flc->ec", a[:, :, getattr(self, f"_m_plus{m}")], w)
            im = torch.einsum("efl,flc->ec", a[:, :, getattr(self, f"_m_minus{m}")], w)
            out.append((re, im))
        return out

    @staticmethod
    def _products(p, q):
        """m = 0 product plus Re / Im of ``p_m conj(q_m)`` for m >= 1."""
        even, odd = [p[0] * q[0]], []
        for (pr, pi), (qr, qi) in zip(p[1:], q[1:]):
            even.append(pr * qr + pi * qi)
            odd.append(pi * qr - pr * qi)
        return even, odd

    def forward(self, positions, species, g: BondGraph, twist=None, bond_weight=None) -> EdgeFeatures:
        """``positions`` (N, 3); ``species`` (N,) indices into ``atomic_numbers``.

        ``twist`` (E,) rotates each edge frame about its bond; outputs do not depend on it.
        ``bond_weight`` (B,) scales each neighbour's contribution by the weight of the bond that
        reaches it (a fractional bond along a reactive state blend fades out of its neighbours'
        densities continuously); ``None`` is weight one everywhere.
        """
        r, unit, frames = self._geometry(positions, g, twist)
        a_near = self._density(g.near, r, unit, frames, species, g, bond_weight)
        a_far = self._density(g.far, r, unit, frames, species, g, bond_weight)
        na, nb = self.project(a_near, "na"), self.project(a_near, "nb")
        fa, fb = self.project(a_far, "fa"), self.project(a_far, "fb")

        cross_e, cross_o = self._products(na, fa)
        near_e, near_o = self._products(na, nb)
        far_e, far_o = self._products(fa, fb)
        inv0e = torch.cat([na[0], fa[0], *cross_e, *near_e, *far_e], dim=-1)
        odd = [*cross_o, *near_o, *far_o]
        inv0o = torch.cat(odd, dim=-1) if odd else r.new_zeros(len(r), 0)

        src, dst = g.edge_index
        bond_radial = self.radial(r, species[src], species[dst])
        mb = {k: [(p[0], None)] + list(p[1:]) for k, p in (("na", na), ("nb", nb), ("fa", fa), ("fb", fb))}
        return EdgeFeatures(inv0e, inv0o, bond_radial, species[src], species[dst], frames, g, mb)


class PairClusterExpansion(nn.Module):
    """The ECE of :class:`EdgeClusterExpansion` on a cutoff-based :class:`~bb.graph.PairGraph`.

    Same invariants, same SO(2) projections and products, two differences that come from the
    graph having cutoffs instead of a fixed topology:

    * the near / far densities run over every atom within ``env_cutoff`` of each end (periodic
      images included), with a Bessel radial basis times a polynomial envelope, so an atom
      entering the environment does so smoothly;
    * ``bond_radial`` is a Bessel-envelope basis of r_ij on ``[0, pair_cutoff]`` and
      ``envelope`` is the envelope itself, so a readout that multiplies by either (e.g.
      :class:`bb.heads.EdgeScalarReadout` with ``bond_basis > 0``) vanishes smoothly at the
      pair cutoff.

    For pairs of magnetic ions, a bridging ligand sits in both densities; its nu = 1 (m = 0)
    terms already fix the M-L-M angle.

    ``n_max`` is the number of pair radial functions (what readouts call ``n_radial``);
    ``n_env`` the env radial functions per neighbour.
    """

    SIDES = EdgeClusterExpansion.SIDES

    def __init__(
        self,
        atomic_numbers,
        env_cutoff: float,
        pair_cutoff: float,
        n_env: int = 6,
        n_max: int = 8,
        l_max: int = 4,
        channels: int = 16,
        species_dim: int = 4,
        envelope_p: float = 6.0,
        backend: "EquivariantBackend | str" = "e3nn",
    ):
        super().__init__()
        from .radial import bessel_envelope_basis, polynomial_envelope

        self._bessel, self._envelope = bessel_envelope_basis, polynomial_envelope
        self.atomic_numbers = [int(z) for z in atomic_numbers]
        self.n_species = len(self.atomic_numbers)
        self.env_cutoff, self.pair_cutoff = float(env_cutoff), float(pair_cutoff)
        self.n_env, self.n_max, self.l_max, self.channels = n_env, n_max, l_max, channels
        self.envelope_p = float(envelope_p)
        self.backend = resolve_backend(backend)
        self.convention = frame_convention(self.backend)
        self.nbr_emb = nn.Embedding(self.n_species, species_dim)
        self.n_feat = n_env * species_dim
        mi = MIndex.build(l_max)
        self.register_buffer("_m_zero", mi.zero, persistent=False)
        for m in range(1, l_max + 1):
            self.register_buffer(f"_m_plus{m}", mi.plus[m], persistent=False)
            self.register_buffer(f"_m_minus{m}", mi.minus[m], persistent=False)
        self.proj = nn.ParameterDict()
        for side in self.SIDES:
            for m in range(l_max + 1):
                nl = l_max - m + 1
                w = torch.randn(self.n_feat, nl, channels) / (self.n_feat * nl) ** 0.5
                self.proj[f"{side}{m}"] = nn.Parameter(w)

    dim_0e = EdgeClusterExpansion.dim_0e
    dim_0o = EdgeClusterExpansion.dim_0o
    project = EdgeClusterExpansion.project
    _products = staticmethod(EdgeClusterExpansion._products)

    def _density(self, pairs, frames, env_vec, species, g, n_edges):
        e, m = pairs
        r = env_vec.norm(dim=-1)
        unit = env_vec / r[:, None]
        u = torch.einsum("pij,pj->pi", frames[e], unit[m])
        y = self.backend.spherical_harmonics(u, self.l_max)                     # (P, nY)
        rad = self._bessel(r[m], self.env_cutoff, self.n_env, self.envelope_p)  # (P, n)
        emb = self.nbr_emb(species[g.env.edge_index[1, m]]).to(r.dtype)         # (P, d)
        f = (rad[:, :, None] * emb[:, None, :]).reshape(len(e), self.n_feat)
        a = r.new_zeros(n_edges, self.n_feat, y.shape[-1])
        return a.index_add(0, e, f[:, :, None] * y[:, None, :])

    def forward(self, positions, species, g, twist=None) -> EdgeFeatures:
        """``positions`` (N, 3); ``species`` (N,) indices into ``atomic_numbers``; ``g`` a
        :class:`~bb.graph.PairGraph`. ``twist`` (E,) rotates the edge frames (a gauge the
        outputs must not depend on)."""
        vec = g.vectors(positions)
        r = vec.norm(dim=-1)
        frames = edge_frames(vec / r[:, None], self.convention, twist)
        env_vec = g.env.vectors(positions)
        a_near = self._density(g.near, frames, env_vec, species, g, g.n_edges)
        a_far = self._density(g.far, frames, env_vec, species, g, g.n_edges)
        na, nb = self.project(a_near, "na"), self.project(a_near, "nb")
        fa, fb = self.project(a_far, "fa"), self.project(a_far, "fb")
        cross_e, cross_o = self._products(na, fa)
        near_e, near_o = self._products(na, nb)
        far_e, far_o = self._products(fa, fb)
        inv0e = torch.cat([na[0], fa[0], *cross_e, *near_e, *far_e], dim=-1)
        odd = [*cross_o, *near_o, *far_o]
        inv0o = torch.cat(odd, dim=-1) if odd else r.new_zeros(len(r), 0)
        src, dst = g.edge_index
        bond_radial = self._bessel(r, self.pair_cutoff, self.n_max, self.envelope_p)
        env = self._envelope((r / self.pair_cutoff).clamp(max=1.0), self.envelope_p)
        mb = {k: [(p[0], None)] + list(p[1:]) for k, p in (("na", na), ("nb", nb), ("fa", fa), ("fb", fb))}
        return EdgeFeatures(inv0e, inv0o, bond_radial, species[src], species[dst], frames, g, mb, env)
