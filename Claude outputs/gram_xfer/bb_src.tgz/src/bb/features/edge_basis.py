"""Explicit, body-ordered bond basis: a linear, interpretable bonded model in the bond frame.

Every basis function belongs to one bond and is a product of a bond factor and ``nu`` neighbour
factors, all in the bond frame of i -> j:

    phi = b_q(r_ij) * Re prod_k z^{X_k}_{s_k n_k l_k m_k}   (some factors conjugated),
    sum over the m's of plain factors = sum over the m's of conjugated ones

    b_q(r)              degree-q polynomial in the Morse variable y of the bond length (q = 0 is
                        the constant; Legendre in (y - 1) / width by default, see ``polynomial``)
    z^X_{s n l m}       sum over neighbours k of species s on side X (near: bonded to i, not j;
                        far: bonded to j, not i) of p_n(y_k) Y_lm(R_e r_k), with z = Y_{l,+m} + i Y_{l,-m}

The constraint makes each product an O(2) invariant; the real part makes it O(3)-even (the
imaginary parts are pseudoscalars and only enter through even products). By order:

    nu = 0   bond                                  2-body
    nu = 1   angle, bond-angle, bond-bond          3-body
    nu = 2   torsion, angle-angle, improper,       4-body (complete Class II)
             angle-torsion, bond-torsion
    nu = 3   5-body couplings, ...

Each basis function is an explicit function of the internal coordinates of the atoms it
involves (Morse powers x associated Legendre x cos / sin m*omega), so a linear model
``E = sum_f w_f sum_bonds phi_f`` is a force field with full coupling functions. The space is
truncated by a total polynomial degree per order, ``q + sum_k (n_k + w l_k) <= degree[nu]``, and
every factor has ``n_k + w l_k <= one_particle_degree`` (``w = l_weight``, default 1).

Species are one-hot, so the basis depends on the neighbour species each bond type actually has:
call :meth:`EdgeBodyOrderBasis.register` with the training systems first. Bond types are
unordered species pairs. A heteronuclear bond is evaluated in its canonical direction (lower
species index -> higher); a homonuclear bond in both directions, summed, with the list reduced
to one representative per near <-> far swap, so no two columns are copies of each other.
Each 3-body (and higher) star around one atom is seen by every bond to that atom; it is kept only
on the bond of lowest type (``_owned``), so the same cluster function never appears in two
columns. What remains linearly dependent is the neighbour self-products (k = k' inside a
density product, which reduce to lower orders when a side has one neighbour of that species) and
dependences that only hold on a given dataset; :func:`bb.linear.nested_solve` assigns each order
only what lower ones cannot represent.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from ..graph.bonded import BondGraph
from ..o3.backend import EquivariantBackend, resolve_backend
from ..o3.frames import edge_frames, frame_convention
from .radial import MorseBasis

__all__ = ["Factor", "BasisFunction", "EdgeBodyOrderBasis"]

NEAR, FAR = 0, 1


@dataclass(frozen=True, order=True)
class Factor:
    side: int       # 0 near, 1 far
    s: int          # neighbour species index
    n: int          # Morse power of the neighbour's bond
    l: int
    m: int          # >= 0
    conj: bool      # only for m > 0

    @property
    def degree(self) -> int:
        return self.n + self.l

    @property
    def signed_m(self) -> int:
        return -self.m if self.conj else self.m

    def flipped(self) -> "Factor":
        return Factor(self.side, self.s, self.n, self.l, self.m, self.conj if self.m == 0 else not self.conj)

    def swapped(self) -> "Factor":
        return Factor(1 - self.side, self.s, self.n, self.l, self.m, self.conj)


@dataclass(frozen=True)
class BasisFunction:
    bond_type: tuple[int, int]
    q: int
    factors: tuple[Factor, ...]

    @property
    def nu(self) -> int:
        return len(self.factors)

    @property
    def degree(self) -> int:
        return self.q + sum(f.degree for f in self.factors)

    def describe(self, symbols=None) -> str:
        sym = (lambda s: symbols[s]) if symbols else str
        a, b = self.bond_type
        parts = [f"{sym(a)}-{sym(b)} y^{self.q}"]
        for f in self.factors:
            parts.append(f"{'near' if f.side == NEAR else 'far'}[{sym(f.s)}](n{f.n} l{f.l} m{f.signed_m:+d})")
        return " * ".join(parts)


def _canonical(factors, homonuclear):
    """Smallest of the equivalent spellings (conjugation; near <-> far for a homonuclear bond)."""
    forms = [tuple(sorted(factors)), tuple(sorted(f.flipped() for f in factors))]
    if homonuclear:
        forms += [tuple(sorted(f.swapped() for f in fs)) for fs in list(forms)]
    return min(forms)


class EdgeBodyOrderBasis(nn.Module):
    """Body-ordered bond basis; ``forward`` returns per-system sums ``(n_systems, n_features)``.

    Parameters
    ----------
    atomic_numbers      : atomic number of each species index.
    n_max               : neighbour Morse powers 0..n_max-1.
    l_max               : maximum l (and m) of the neighbour factors.
    n_bond              : bond Morse powers 0..n_bond-1.
    max_nu              : highest number of neighbour factors.
    one_particle_degree : cap on n + l of every factor.
    degree              : cap on the total degree per order (sequence indexed by nu, or one int).
    element_counts      : add one column per species counting its atoms (absolute energies).
    l_weight            : weight of l in the degree of a factor, ``n + l_weight * l``. Below 1 it
                          admits higher harmonics at low radial order: a 3-fold torsion needs
                          two l = 3 factors, total degree 6 at weight 1 but 3 at weight 0.5.
    polynomial          : radial functions as Legendre polynomials in ``(y - 1) / morse_width``
                          (default; same space as the powers ``y^n``, well conditioned) or
                          ``"power"``.
    count_factors       : allow the factor n = 0, l = 0, which is a neighbour count (constant in
                          geometry). Off by default: products with counts are constant within a
                          molecule and only distinguish coordination numbers across molecules.
    """

    def __init__(
        self,
        atomic_numbers,
        n_max: int = 4,
        l_max: int = 3,
        n_bond: int = 4,
        max_nu: int = 2,
        one_particle_degree: int = 4,
        degree=(3, 6, 7, 8),
        morse_a: float = 2.0,
        r0: torch.Tensor | None = None,
        element_counts: bool = True,
        count_factors: bool = False,
        l_weight: float = 1.0,
        polynomial: str = "legendre",
        morse_width: float = 0.3,
        backend: "EquivariantBackend | str" = "e3nn",
    ):
        super().__init__()
        self.atomic_numbers = [int(z) for z in atomic_numbers]
        self.n_species = S = len(self.atomic_numbers)
        self.n_max, self.l_max, self.n_bond, self.max_nu = n_max, l_max, n_bond, max_nu
        self.one_particle_degree = one_particle_degree
        self.degree = [degree] * (max_nu + 1) if isinstance(degree, int) else list(degree)
        if len(self.degree) < max_nu + 1:
            raise ValueError("degree needs one entry per order 0..max_nu")
        self.element_counts = element_counts
        self.count_factors = count_factors
        self.l_weight = float(l_weight)
        self.backend = resolve_backend(backend)
        self.convention = frame_convention(self.backend)
        self.radial = MorseBasis(self.atomic_numbers, max(n_max, n_bond), a=morse_a, r0=r0,
                                 polynomial=polynomial, width=morse_width)
        self.functions: list[BasisFunction] = []
        self._plan: dict = {}
        self.register_buffer("_dummy", torch.zeros(0), persistent=False)
        self._S = S

    # ------------------------------------------------------------------ #
    # Registration and enumeration
    # ------------------------------------------------------------------ #
    @staticmethod
    def bond_type(si: int, sj: int) -> tuple[int, int]:
        return (si, sj) if si <= sj else (sj, si)

    def register(self, systems) -> "EdgeBodyOrderBasis":
        """Enumerate the basis from the neighbour species each bond type has in ``systems``.

        ``systems``: iterable of ``(species, BondGraph)`` (one per molecule; geometry not needed).
        """
        seen: dict[tuple[int, int], tuple[set, set]] = {}
        for species, g in systems:
            sp = [int(s) for s in species]
            nb = [[] for _ in range(g.n_atoms)]
            for a, b in g.bonds.tolist():
                nb[a].append(b)
                nb[b].append(a)
            for a, b in g.bonds.tolist():
                t = self.bond_type(sp[a], sp[b])
                i, j = (a, b) if (sp[a], sp[b]) == t else (b, a)
                near = {sp[k] for k in nb[i] if k != j}
                far = {sp[k] for k in nb[j] if k != i}
                cur = seen.setdefault(t, (set(), set()))
                if t[0] == t[1]:
                    near = far = near | far
                cur[0].update(near)
                cur[1].update(far)
        funcs = []
        for t in sorted(seen):
            funcs += self._enumerate(t, *seen[t])
        self.functions = funcs
        self._build_plan()
        return self

    def _factors(self, side, species):
        out = []
        for s in sorted(species):
            for n in range(self.n_max):
                for l in range(self.l_max + 1):
                    if n + self.l_weight * l > self.one_particle_degree + 1e-9 or (
                            n == 0 and l == 0 and not self.count_factors):
                        continue
                    for m in range(l + 1):
                        out.append(Factor(side, s, n, l, m, False))
                        if m > 0:
                            out.append(Factor(side, s, n, l, m, True))
        return sorted(out)

    def _enumerate(self, t, near, far):
        homo = t[0] == t[1]
        facs = self._factors(NEAR, near) + self._factors(FAR, far)
        fdeg = lambda f: f.n + self.l_weight * f.l  # noqa: E731
        facs.sort(key=lambda f: (fdeg(f), f))
        funcs = [BasisFunction(t, q, ()) for q in range(self.n_bond) if q <= self.degree[0]]
        for nu in range(1, self.max_nu + 1):
            cap = self.degree[nu]
            seen = set()

            def rec(start, chosen, deg, msum):
                if len(chosen) == nu:
                    if msum != 0:
                        return
                    key = _canonical(chosen, homo)
                    if key in seen:
                        return
                    seen.add(key)
                    for q in range(self.n_bond):
                        if deg + q <= cap + 1e-9 and self._owned(t, q, key):
                            funcs.append(BasisFunction(t, q, key))
                    return
                for idx in range(start, len(facs)):
                    f = facs[idx]
                    if deg + fdeg(f) > cap + 1e-9:
                        break   # sorted by degree
                    rec(idx, chosen + [f], deg + fdeg(f), msum + f.signed_m)

            rec(0, [], 0, 0)
        return funcs

    @staticmethod
    def _owned(t, q, factors) -> bool:
        """Is this bond the owner of the cluster (so no other bond carries the same function)?

        A cluster with neighbours on both ends is seen only by its central bond. A star (all
        neighbours on one end, centre c) is also seen by each arm bond (c, k); it belongs to the
        lowest bond type among the bond and its arms. Where an arm has the bond's own type, carries
        no azimuth and every other factor is angle-free, the function is symmetric under swapping
        that arm with the bond, so only q >= n of that arm is kept. A
        star function with q = 0 and only l = 0 factors does not involve the bond's other atom at
        all; it is a function of the arm bonds, carried by their own (lower-order) terms.
        """
        sides = {f.side for f in factors}
        if len(sides) != 1:
            return True
        if q == 0 and all(f.l == 0 for f in factors):
            return False   # does not depend on the bond's far atom: a function of the arms only
        side = sides.pop()
        centre = t[0] if side == NEAR else t[1]
        arms = [EdgeBodyOrderBasis.bond_type(centre, f.s) for f in factors]
        if t > min(arms):
            return False
        for k, (f, a) in enumerate(zip(factors, arms)):
            # an arm of the bond's own type whose factor has no azimuth, with every other factor
            # angle-free: the function is symmetric under swapping that arm with the bond itself
            if a == t and f.m == 0 and all(g.l == 0 for kk, g in enumerate(factors) if kk != k):
                if q < f.n:
                    return False
        return True

    def _build_plan(self):
        """Group basis functions by (bond type, pattern of (side, m, conj)) for batched gathers."""
        N, L = self.n_max, self.l_max
        plan: dict = {}
        for col, bf in enumerate(self.functions):
            key = (bf.bond_type, tuple((f.side, f.m, f.conj) for f in bf.factors))
            idx = [(f.s * N + f.n) * (L - f.m + 1) + (f.l - f.m) for f in bf.factors]
            plan.setdefault(key, ([], [], []))
            plan[key][0].append(col)
            plan[key][1].append(idx)
            plan[key][2].append(bf.q)
        self._plan = {k: (torch.tensor(c), torch.tensor(i, dtype=torch.long).reshape(len(c), -1),
                          torch.tensor(q)) for k, (c, i, q) in plan.items()}
        self.bond_types = sorted({bf.bond_type for bf in self.functions})

    @property
    def n_features(self) -> int:
        return len(self.functions) + (self.n_species if self.element_counts else 0)

    def labels(self) -> torch.Tensor:
        """Order ``nu`` of every column (element-count columns: -1)."""
        lab = [bf.nu for bf in self.functions]
        if self.element_counts:
            lab += [-1] * self.n_species
        return torch.tensor(lab)

    # ------------------------------------------------------------------ #
    # Evaluation
    # ------------------------------------------------------------------ #
    def _directed(self, species, g: BondGraph):
        """Directed edges to evaluate, with their bond type."""
        nb = g.n_bonds
        src, dst = g.edge_index
        si, sj = species[src[:nb]], species[dst[:nb]]
        canon = si <= sj                          # input orientation already canonical
        e_fwd = torch.arange(nb, device=src.device)
        e_main = torch.where(canon, e_fwd, e_fwd + nb)
        homo = si == sj
        edges = torch.cat([e_main, (e_fwd + nb)[homo]])
        return edges

    def _densities(self, positions, species, g: BondGraph, edges):
        S, N, L = self.n_species, self.n_max, self.l_max
        src, dst = g.edge_index
        vec = positions[dst] - positions[src]
        r = vec.norm(dim=-1)
        unit = vec / r[:, None]
        frames = edge_frames(unit[edges], self.convention)
        pos_in = torch.full((g.n_edges,), -1, dtype=torch.long, device=src.device)
        pos_in[edges] = torch.arange(len(edges), device=src.device)
        out = []
        for pairs in (g.near, g.far):
            e, e2 = pairs
            keep = pos_in[e] >= 0
            e, e2 = e[keep], e2[keep]
            row = pos_in[e]
            u = torch.einsum("pij,pj->pi", frames[row], unit[e2])
            y = self.backend.spherical_harmonics(u, L)                            # (P, nY)
            rad = self.radial(r[e2], species[src[e2]], species[dst[e2]])[:, :N]   # (P, N)
            slot = species[dst[e2]] * N                                           # (P,)
            a = r.new_zeros(len(edges), S * N, y.shape[-1])
            idx = (slot[:, None] + torch.arange(N, device=slot.device)[None, :])  # (P, N)
            contrib = rad[:, :, None] * y[:, None, :]                             # (P, N, nY)
            a = a.index_put((row[:, None].expand_as(idx), idx), contrib, accumulate=True)
            out.append(a)
        b = self.radial(r[edges], species[src[edges]], species[dst[edges]])[:, :self.n_bond]
        return out, b

    def _split_m(self, a):
        """``a`` (E, S*N, nY) -> per m: (re, im) of shape (E, S*N*(L-m+1)), im None for m = 0."""
        L = self.l_max
        E = a.shape[0]
        out = []
        for m in range(L + 1):
            ls = list(range(m, L + 1))
            re = a[:, :, [l * l + l + m for l in ls]].reshape(E, -1)
            im = None if m == 0 else a[:, :, [l * l + l - m for l in ls]].reshape(E, -1)
            out.append((re, im))
        return out

    def edge_features(self, positions, species, g: BondGraph):
        """``(edges, bond_of_edge, values)``: values ``(n_eval_edges, n_functions)``."""
        if not self.functions:
            raise RuntimeError("EdgeBodyOrderBasis: call register(...) first")
        edges = self._directed(species, g)
        (a_near, a_far), b = self._densities(positions, species, g, edges)
        z = (self._split_m(a_near), self._split_m(a_far))
        src, dst = g.edge_index
        ts = torch.stack([torch.minimum(species[src[edges]], species[dst[edges]]),
                          torch.maximum(species[src[edges]], species[dst[edges]])], 1)
        vals = positions.new_zeros(len(edges), len(self.functions))
        for (t, pattern), (cols, idx, q) in self._plan.items():
            sel = ((ts[:, 0] == t[0]) & (ts[:, 1] == t[1])).nonzero().squeeze(-1)
            if sel.numel() == 0:
                continue
            re = b[sel][:, q]                                   # (E_t, F_g)
            im = None
            for k, (side, m, cj) in enumerate(pattern):
                zr, zi = z[side][m]
                fr = zr[sel][:, idx[:, k]]
                fi = None if zi is None else zi[sel][:, idx[:, k]] * (-1.0 if cj else 1.0)
                if fi is None:
                    re = re * fr
                    im = None if im is None else im * fr
                elif im is None:
                    re, im = re * fr, re * fi
                else:
                    re, im = re * fr - im * fi, re * fi + im * fr
            vals = vals.index_put((sel[:, None].expand(-1, len(cols)), cols[None, :].expand(len(sel), -1)),
                                  re, accumulate=True)
        return edges, g.bond_id[edges], vals

    def forward(self, positions, species, g: BondGraph, batch_idx=None, n_systems=None):
        """Per-system sums ``(n_systems, n_features)`` (one row without ``batch_idx``)."""
        edges, bond, vals = self.edge_features(positions, species, g)
        src = g.edge_index[0]
        if batch_idx is None:
            sys_e = torch.zeros(len(edges), dtype=torch.long, device=vals.device)
            n = 1
            sys_a = torch.zeros(len(species), dtype=torch.long, device=vals.device)
        else:
            n = int(batch_idx.max()) + 1 if n_systems is None else int(n_systems)
            sys_e = batch_idx[src[edges]]
            sys_a = batch_idx
        out = vals.new_zeros(n, len(self.functions)).index_add(0, sys_e, vals)
        if self.element_counts:
            cnt = vals.new_zeros(n, self.n_species).index_put(
                (sys_a, species), vals.new_ones(len(species)), accumulate=True)
            out = torch.cat([out, cnt], 1)
        return out
