"""Feature calculation: radial bases, the neighbor density, spectra and featurizers."""

from .bispectrum import E3nnWeightedBispectrum, LearnableBispectrum, LearnableSymContraction
from .compress import AtomWeightNet
from .density import DensityExpansion
from .edge import EdgeClusterExpansion, EdgeFeatures, PairClusterExpansion
from .edge_basis import BasisFunction, EdgeBodyOrderBasis, Factor
from .featurizers import (
    FlatLambdaSOAPFeaturizer,
    FlatStateSOAPFeaturizer,
    PartitionedFeaturizer,
    PartitionedFeatures,
    SOAPFeaturizer,
    StateSOAPFeaturizer,
    species_lookup,
)
from .radial import BesselBasis, MorseBasis, bessel_envelope_basis, cosine_cutoff, polynomial_envelope
from .spectra import (
    PairSpec,
    bispectrum,
    build_cross_spectrum_specs,
    build_power_spectrum_specs,
    cross_power_spectrum,
    equivariant_power_spectrum,
    power_spectrum,
)

#: Old container name; :class:`bb.o3.IrrepFeatures` accepts its constructor keywords.
from ..o3.irreps import IrrepFeatures as LambdaFeatures  # noqa: E402

__all__ = [
    "E3nnWeightedBispectrum", "LearnableBispectrum", "LearnableSymContraction",
    "AtomWeightNet", "DensityExpansion", "EdgeClusterExpansion", "EdgeFeatures", "PairClusterExpansion",
    "BasisFunction", "EdgeBodyOrderBasis", "Factor",
    "FlatLambdaSOAPFeaturizer", "FlatStateSOAPFeaturizer", "PartitionedFeaturizer",
    "PartitionedFeatures", "SOAPFeaturizer", "StateSOAPFeaturizer", "species_lookup",
    "BesselBasis", "MorseBasis", "bessel_envelope_basis", "cosine_cutoff", "polynomial_envelope",
    "PairSpec", "bispectrum", "build_cross_spectrum_specs", "build_power_spectrum_specs",
    "cross_power_spectrum", "equivariant_power_spectrum", "power_spectrum",
    "LambdaFeatures",
]
