"""Featurizers: compositions of the density and spectrum stages.

Every featurizer here is the same pipeline, exposed stage by stage so a model can stop, branch or
re-weight anywhere along it::

    edge_index = build_edges(positions, group)               # one neighbor search
    RY         = expand(positions, edge_index)                # geometry only, computed once
    A          = scatter(RY, edge_index, species, ...)        # species / mask / soft weight
    A          = compress(A)                                  # optional learned channel mix
    feats      = contract(A, ...)                             # nu=2 spectrum (+ nu=3 bispectrum)

* :class:`SOAPFeaturizer` -- species-resolved lambda-SOAP (+ optional trainable bispectrum).
  The default ``forward`` is the plain per-structure descriptor.
* :class:`StateSOAPFeaturizer` -- the channel axis comes from caller-supplied per-atom weights
  (e.g. an embedding of element + charge + spin) instead of a species one-hot.
* :class:`PartitionedFeaturizer` -- wraps a :class:`SOAPFeaturizer` and splits each center's
  density by a per-edge membership ``s`` into an internal ``A(s)`` and an environment
  ``A(1 - s)``, returning both spectra plus their cross spectrum. For an isolated group every
  edge has ``s = 1``, so the environment blocks are exact zeros (an empty sum), not small numbers.

All outputs are :class:`bb.o3.IrrepFeatures` with natural-parity blocks ``0e, 1o, 2e, ...``.
The featurizers are ``torch.compile`` boundaries (they run eager): the neighbor search is an
opaque op dynamo cannot trace, and the e3nn harmonics / CG tables recompile badly; the dense
readouts downstream are where compilation helps.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence

import torch
import torch.nn as nn

from ..graph.neighbors import DEFAULT_MAX_NUM_NEIGHBORS, build_radius_graph
from ..o3.backend import EquivariantBackend, resolve_backend
from ..o3.irreps import IrrepFeatures, natural_irrep
from .density import DensityExpansion
from .radial import cosine_cutoff
from .spectra import (
    build_cross_spectrum_specs,
    build_power_spectrum_specs,
    cross_power_spectrum,
    equivariant_power_spectrum,
)

__all__ = [
    "SOAPFeaturizer",
    "FlatLambdaSOAPFeaturizer",
    "StateSOAPFeaturizer",
    "FlatStateSOAPFeaturizer",
    "PartitionedFeaturizer",
    "PartitionedFeatures",
    "species_lookup",
]


def species_lookup(neighbor_types: Sequence[int]) -> tuple[tuple[int, ...], torch.Tensor]:
    """Sorted unique atomic numbers and a ``Z -> species index`` lookup table (``-1`` = unknown)."""
    cleaned = tuple(sorted({int(z) for z in neighbor_types}))
    if not cleaned:
        raise ValueError("neighbor_types can not be empty")
    lut = torch.full((max(cleaned) + 1,), -1, dtype=torch.long)
    for index, z in enumerate(cleaned):
        lut[z] = index
    return cleaned, lut


def _unpack(batch, positions, atomic_numbers, batch_idx):
    if batch is not None:
        positions = batch.positions if positions is None else positions
        atomic_numbers = batch.atomic_numbers if atomic_numbers is None else atomic_numbers
        batch_idx = batch.batch_idx if batch_idx is None else batch_idx
    if positions is None or atomic_numbers is None:
        raise ValueError("pass a batch, or positions= and atomic_numbers= (and batch_idx=)")
    if batch_idx is None:
        batch_idx = torch.zeros(positions.shape[0], dtype=torch.long, device=positions.device)
    return positions, atomic_numbers, batch_idx


def _bispectrum_option(bispectrum, name, default):
    if isinstance(bispectrum, dict):
        return bispectrum.get(name, default)
    return getattr(bispectrum, name, default)


class _SpectrumStages(nn.Module):
    """Shared spectrum machinery: CG tables, the optional bispectrum, and ``contract``."""

    def _init_spectra(self, *, n_channels: int, bispectrum, bis_species: int, bis_nmax: int) -> None:
        self._equivariant_specs, cached_tensors = build_power_spectrum_specs(
            l_max=self.l_max,
            selected_lambdas=self.selected_lambdas,
            n_channels=n_channels,
            backend=self.backend,
        )
        for name, tensor in cached_tensors.items():
            self.register_buffer(name, tensor, persistent=False)
        #: ``{lam: width}`` of the output blocks (power spectrum + bispectrum).
        self.feature_dims = {
            lam: sum(spec.width for spec in specs)
            for lam, specs in self._equivariant_specs.items()
        }

        # Optional trainable nu=3 bispectrum, concatenated per lambda onto the nu=2 spectrum.
        # Presence of the config enables it; it is built through the backend so it follows the
        # e3nn / cue split.
        self.bispectrum = None
        self._bispectrum_on_cpu = False
        if bispectrum is not None:
            num_elements = (
                self.n_species if _bispectrum_option(bispectrum, "per_species_weights", False) else 1
            )
            self.bispectrum = self.backend.make_weighted_bispectrum(
                n_species=bis_species,
                n_max=bis_nmax,
                l_max=self.l_max,
                selected_lambdas=self.selected_lambdas,
                out_mul=_bispectrum_option(bispectrum, "out_mul", None),
                num_elements=num_elements,
                implementation=_bispectrum_option(bispectrum, "implementation", "sym_contraction"),
                contraction_degree=_bispectrum_option(bispectrum, "contraction_degree", 3),
                degrees=tuple(_bispectrum_option(bispectrum, "degrees", (3,))),
                method=_bispectrum_option(bispectrum, "method", "auto"),
            )
            # cuequivariance has no MPS kernel: off CUDA the cue bispectrum runs on CPU.
            self._bispectrum_on_cpu = self.backend.name == "cue" and not torch.cuda.is_available()
            for lam, width in self.bispectrum.feature_dims.items():
                self.feature_dims[lam] = self.feature_dims.get(lam, 0) + width

    @property
    def irreps_out(self):
        from ..o3.irreps import Irreps

        return Irreps([(self.feature_dims[lam], natural_irrep(lam)) for lam in sorted(self.feature_dims)])

    def species_index(self, atomic_numbers: torch.Tensor) -> torch.Tensor:
        """Map atomic numbers to this featurizer's species indices: ``(N,) -> (N,)``."""
        return self._species_lut[atomic_numbers]

    def build_periodic_edges(self, positions, group_idx, cell, pbc=None):
        """The periodic neighbor list (:class:`bb.graph.PeriodicEdges`); ``group_idx`` must be
        the frame index, one ``cell`` per frame."""
        from ..graph.periodic import build_periodic_graph

        return build_periodic_graph(
            positions, self.cutoff, cell, pbc, group_idx,
            max_num_neighbors=self.max_num_neighbors, context=type(self).__name__,
        )

    def build_edges(self, positions: torch.Tensor, group_idx: torch.Tensor) -> torch.Tensor:
        """The neighbor list: no edge crosses a ``group_idx`` boundary."""
        return build_radius_graph(
            positions, self.cutoff, group_idx,
            max_num_neighbors=self.max_num_neighbors,
            context=type(self).__name__,
            truncation=getattr(self, "neighbor_truncation", "nearest"),
        )

    def run_bispectrum(self, A: torch.Tensor, species_idx: torch.Tensor) -> dict:
        if self._bispectrum_on_cpu and A.device.type != "cpu":
            dev = A.device
            bis = self.bispectrum(A.cpu(), species_idx.cpu())
            return {lam: t.to(dev) for lam, t in bis.items()}
        return self.bispectrum(A, species_idx)

    def spectrum(self, A: torch.Tensor) -> dict[int, torch.Tensor]:
        """The nu=2 lambda power spectrum of a (compressed) density: ``{lam: (N, 2lam+1, P)}``."""
        return equivariant_power_spectrum(
            A,
            self.l_max,
            self.selected_lambdas,
            specs_by_lam=self._equivariant_specs,
            triu_rows=self._equivariant_triu_rows,
            triu_cols=self._equivariant_triu_cols,
            cg_buffer_owner=self,
        )

    def contract(
        self,
        A: torch.Tensor,
        species_idx: torch.Tensor,
        batch_idx: torch.Tensor | None = None,
        edge_index: torch.Tensor | None = None,
    ) -> IrrepFeatures:
        """Power spectrum (+ optional bispectrum) of a prebuilt density."""
        per_lambda = self.spectrum(A)
        if self.bispectrum is not None:
            bis = self.run_bispectrum(A, species_idx)
            for lam, t in bis.items():
                if lam in per_lambda:
                    per_lambda[lam] = torch.cat((per_lambda[lam], t), dim=-1)
        return IrrepFeatures(
            {natural_irrep(lam): t for lam, t in per_lambda.items()},
            species_idx=species_idx,
            batch_idx=batch_idx,
            edge_index=edge_index,
        )

    # Legacy (rsfff / pf) spellings of the stage methods.
    def _build_edges(self, positions, group_idx):
        return self.build_edges(positions, group_idx)

    def _run_bispectrum(self, A, species_idx):
        return self.run_bispectrum(A, species_idx)

    def _features_from_density(self, A, species_idx, batch_idx, edge_index):
        return self.contract(A, species_idx, batch_idx, edge_index)


class SOAPFeaturizer(_SpectrumStages):
    """Species-resolved equivariant lambda-SOAP over a flat ragged batch.

    Parameters
    ----------
    cutoff, n_max, l_max : radial cutoff, number of Bessel functions, SH degree of the density.
    neighbor_types       : atomic numbers the model knows; the species channel axis.
    selected_lambdas     : output degrees (natural parity: 0 -> 0e, 1 -> 1o, 2 -> 2e, ...).
    backend              : ``"e3nn"`` / ``"cue"`` or an :class:`EquivariantBackend`.
    bispectrum           : ``None`` (nu=2 only) or a config (object or dict) with
                           ``implementation, out_mul, contraction_degree, degrees,
                           per_species_weights, method`` -- see :class:`bb.config.BispectrumConfig`.
    density_channels     : optional learned compression of the ``n_species * n_max`` density
                           channels to this many before the O(C^2) spectrum.
    max_num_neighbors    : neighbor-list cap (``max_neighbors`` is accepted as an alias).
    neighbor_truncation  : which neighbors the pure-torch neighbor list keeps when the cap binds
                           (``"nearest"`` or ``"index"``; see :func:`bb.graph.radius_graph_torch`).

    ``forward`` returns :class:`IrrepFeatures`. The rsfff partition modes of the old
    ``FlatLambdaSOAPFeaturizer.forward`` (``also_ungrouped``, ``also_cross``, ``edge_weight``)
    are kept for compatibility; new code should use :class:`PartitionedFeaturizer`.
    """

    def __init__(
        self,
        *,
        cutoff: float,
        n_max: int,
        l_max: int,
        neighbor_types: Sequence[int],
        selected_lambdas: Sequence[int] = (0, 2),
        backend: "EquivariantBackend | str" = "e3nn",
        bispectrum=None,
        density_channels: int | None = None,
        max_num_neighbors: int | None = None,
        max_neighbors: int | None = None,
        neighbor_truncation: str = "nearest",
    ) -> None:
        super().__init__()
        self.neighbor_truncation = str(neighbor_truncation)
        cleaned, lut = species_lookup(neighbor_types)
        self.neighbor_types = cleaned
        self.cutoff = float(cutoff)
        self.l_max = int(l_max)
        self.n_max = int(n_max)
        self.n_species = len(cleaned)
        self.selected_lambdas = tuple(sorted({int(v) for v in selected_lambdas}))
        self.backend = resolve_backend(backend)
        if max_num_neighbors is not None and max_neighbors is not None and int(max_num_neighbors) != int(max_neighbors):
            raise ValueError("max_num_neighbors and max_neighbors are aliases; pass one")
        cap = max_num_neighbors if max_num_neighbors is not None else max_neighbors
        self.max_num_neighbors = int(cap) if cap is not None else DEFAULT_MAX_NUM_NEIGHBORS
        self.register_buffer("_species_lut", lut, persistent=False)

        self.density = DensityExpansion(
            n_max=self.n_max, l_max=self.l_max, cutoff=self.cutoff,
            n_species=self.n_species, backend=self.backend,
        )

        # Optional learnable density-channel compression. The raw density has
        # C = n_species * n_max channels; the power spectrum is O(C^2). A single equivariant
        # linear map on the channel axis (mixing (Z, n) channels, leaving m untouched) projects
        # C -> Kc before the power spectrum / bispectrum.
        raw_channels = self.n_species * self.n_max
        self.density_channels = int(density_channels) if density_channels else None
        n_channels = self.density_channels or raw_channels
        if self.density_channels is not None:
            self.channel_proj = nn.Parameter(
                torch.randn(raw_channels, self.density_channels) / (raw_channels ** 0.5)
            )
        # The bispectrum consumes the same (optionally compressed) density; only the product
        # n_species * n_max matters, the center-element count is set independently.
        bis_species, bis_nmax = (
            (n_channels, 1) if self.density_channels is not None else (self.n_species, self.n_max)
        )
        self._init_spectra(
            n_channels=n_channels, bispectrum=bispectrum, bis_species=bis_species, bis_nmax=bis_nmax
        )

    @property
    def max_neighbors(self) -> int:
        return self.max_num_neighbors

    @property
    def n_channels(self) -> int:
        """Channel count of the density the spectrum sees (after compression)."""
        return self.density_channels or self.n_species * self.n_max

    # ------------------------------------------------------------------ stages
    def expand(self, positions: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        return self.density.edge_expansion(positions, edge_index)

    def compress(self, A: torch.Tensor) -> torch.Tensor:
        """Optional learnable channel compression before the O(Kc^2) power spectrum."""
        if self.density_channels is None:
            return A
        n_atoms, _, _, l2 = A.shape
        A = torch.einsum("ncl,ck->nkl", A.reshape(n_atoms, -1, l2), self.channel_proj)
        return A.unsqueeze(2)                                        # (N, Kc, 1, L2)

    _compress = compress

    def scatter(
        self,
        RY: torch.Tensor,
        edge_index: torch.Tensor,
        species_idx: torch.Tensor,
        num_atoms: int,
        *,
        edge_mask: torch.Tensor | None = None,
        edge_weight: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Species-resolved, compressed density from a prebuilt ``RY``."""
        return self.compress(
            self.density.scatter_species(
                RY, edge_index, species_idx, num_atoms, edge_mask=edge_mask, edge_weight=edge_weight
            )
        )

    # ------------------------------------------------------------------ forward
    @torch.compiler.disable
    def forward(
        self,
        batch=None,
        group_idx: torch.Tensor | None = None,
        *,
        positions: torch.Tensor | None = None,
        atomic_numbers: torch.Tensor | None = None,
        batch_idx: torch.Tensor | None = None,
        also_ungrouped: bool = False,
        also_cross: bool = False,
        edge_weight=None,
        cell: torch.Tensor | None = None,
        pbc: torch.Tensor | None = None,
    ):
        """Features of every atom. ``group_idx`` restricts which atoms may be neighbors
        (default: the structure, ``batch_idx``).

        ``cell`` ``(B, 3, 3)`` (rows are lattice vectors) and ``pbc`` ``(B, 3)`` make the
        neighbor list periodic; the returned features then carry ``edge_offsets`` so message
        passing uses the same images. Periodic graphs take the plain path only (no
        ``group_idx`` / ``also_*``).

        Passing a fragment index makes each atom's descriptor a function of its own fragment
        only. The ``also_*`` / ``edge_weight`` arguments return a pair of descriptors sharing one
        neighbor search (``(grouped, ungrouped)`` or ``(internal, environment)``); see
        :class:`PartitionedFeaturizer` for the same thing as a module.
        """
        positions, atomic_numbers, batch_idx = _unpack(batch, positions, atomic_numbers, batch_idx)
        species_idx = self._species_lut[atomic_numbers]
        n_atoms = int(positions.shape[0])

        if cell is not None:
            if group_idx is not None or also_ungrouped or also_cross:
                raise ValueError("periodic featurization supports the plain path only")
            pe = self.build_periodic_edges(positions, batch_idx, cell, pbc)
            A = self.compress(self.density(positions, species_idx, pe.edge_index, n_atoms, pe.offsets))
            return self.contract(A, species_idx, batch_idx, pe.edge_index).replace(edge_offsets=pe.offsets)

        if not (also_ungrouped or also_cross):
            edge_index = self.build_edges(positions, batch_idx if group_idx is None else group_idx)
            A = self.compress(self.density(positions, species_idx, edge_index, n_atoms))
            return self.contract(A, species_idx, batch_idx, edge_index)

        if also_ungrouped and also_cross:
            raise ValueError(
                "also_ungrouped and also_cross are alternative second descriptors; ask for one. "
                "The ungrouped one is the *union* of the two edge sets and the cross one their "
                "difference."
            )
        edge_index = self.build_edges(positions, batch_idx)
        RY = self.expand(positions, edge_index)
        full = None
        if also_ungrouped:
            full = self.contract(
                self.scatter(RY, edge_index, species_idx, n_atoms), species_idx, batch_idx, edge_index
            )
        if group_idx is None:
            if also_cross:
                raise ValueError(
                    "also_cross needs a group_idx to have edges to be cross *to*. Without one "
                    "every edge is intra-group and the environment slot would be identically "
                    "zero everywhere."
                )
            return full, full

        if edge_weight is not None:
            if not also_cross:
                raise ValueError(
                    "edge_weight softens the internal/environment split, which only exists when "
                    "also_cross=True"
                )
            w = _edge_weight(edge_weight, edge_index)
            return (
                self.contract(self.scatter(RY, edge_index, species_idx, n_atoms, edge_weight=w),
                              species_idx, batch_idx, edge_index),
                self.contract(self.scatter(RY, edge_index, species_idx, n_atoms, edge_weight=1.0 - w),
                              species_idx, batch_idx, edge_index),
            )

        mask = group_idx[edge_index[0]] == group_idx[edge_index[1]]

        def masked(edge_mask):
            return self.contract(
                self.scatter(RY, edge_index, species_idx, n_atoms, edge_mask=edge_mask),
                species_idx, batch_idx, edge_index[:, edge_mask],
            )

        grouped = masked(mask)
        return (grouped, masked(~mask)) if also_cross else (grouped, full)


#: The pre-bb name (rsfff, pauli_fierz_pinn, hbq_qed).
FlatLambdaSOAPFeaturizer = SOAPFeaturizer


def _edge_weight(edge_weight, edge_index: torch.Tensor) -> torch.Tensor:
    # A callable is handed the edge list this call actually built, so the caller cannot compute
    # weights on a *different* neighbor search and have them silently line up by index.
    if callable(edge_weight):
        edge_weight = edge_weight(edge_index)
    w = edge_weight.reshape(-1)
    if w.shape[0] != edge_index.shape[1]:
        raise ValueError(
            f"edge_weight has {w.shape[0]} entries for {edge_index.shape[1]} edges; it is one "
            f"weight per edge of the structure graph"
        )
    return w


class StateSOAPFeaturizer(_SpectrumStages):
    """Lambda-SOAP whose density channels come from per-atom weights instead of species.

    Same pipeline as :class:`SOAPFeaturizer` with two changes:

    1. **The channel axis is learned.** Neighbors are weighted by ``atom_weights`` ``(N, Kw)``,
       supplied by the caller (e.g. :class:`bb.features.AtomWeightNet` of an embedding of
       element, charge and spin), so a neighbor enters through its full identity instead of its
       bare element. This subsumes ``density_channels``: the weight net *is* the compression.
    2. **Edges are confined to a group** (``group_idx``, e.g. a fragment) when one is passed.

    Feature width scales as ``(Kw * n_max)^2``, so ``Kw`` is the cost knob.
    """

    def __init__(
        self,
        *,
        cutoff: float,
        n_max: int,
        l_max: int,
        neighbor_types: Sequence[int],
        weight_channels: int,
        selected_lambdas: Sequence[int] = (0, 1, 2),
        backend: "EquivariantBackend | str" = "e3nn",
        bispectrum=None,
        max_num_neighbors: int = DEFAULT_MAX_NUM_NEIGHBORS,
        neighbor_truncation: str = "nearest",
    ) -> None:
        super().__init__()
        self.neighbor_truncation = str(neighbor_truncation)
        cleaned, lut = species_lookup(neighbor_types)
        self.neighbor_types = cleaned
        self.cutoff = float(cutoff)
        self.l_max = int(l_max)
        self.n_max = int(n_max)
        self.n_species = len(cleaned)
        self.weight_channels = int(weight_channels)
        self.selected_lambdas = tuple(sorted({int(v) for v in selected_lambdas}))
        self.backend = resolve_backend(backend)
        self.max_num_neighbors = int(max_num_neighbors)
        self.register_buffer("_species_lut", lut, persistent=False)

        # n_species is the *weight* channel count here: the scatter is over learned channels.
        self.density = DensityExpansion(
            n_max=self.n_max, l_max=self.l_max, cutoff=self.cutoff,
            n_species=self.weight_channels, backend=self.backend,
        )
        self._init_spectra(
            n_channels=self.weight_channels * self.n_max, bispectrum=bispectrum,
            bis_species=self.weight_channels, bis_nmax=self.n_max,
        )

    @torch.compiler.disable
    def forward(
        self,
        batch=None,
        atom_weights: torch.Tensor | None = None,   # (N, Kw)
        fragment_idx: torch.Tensor | None = None,
        *,
        positions: torch.Tensor | None = None,
        atomic_numbers: torch.Tensor | None = None,
        batch_idx: torch.Tensor | None = None,
    ) -> IrrepFeatures:
        positions, atomic_numbers, batch_idx = _unpack(batch, positions, atomic_numbers, batch_idx)
        if atom_weights is None:
            raise ValueError("StateSOAPFeaturizer needs atom_weights (N, weight_channels)")
        species_idx = self._species_lut[atomic_numbers]
        if atom_weights.shape[-1] != self.weight_channels:
            raise ValueError(
                f"atom_weights has {atom_weights.shape[-1]} channels, featurizer was built "
                f"for weight_channels={self.weight_channels}"
            )
        group = fragment_idx if fragment_idx is not None else batch_idx
        edge_index = self.build_edges(positions, group)
        RY = self.density.edge_expansion(positions, edge_index)
        A = self.density.scatter_weighted(RY, edge_index, atom_weights, int(positions.shape[0]))
        return self.contract(A, species_idx, batch_idx, edge_index)


#: The pre-bb name (rsfff).
FlatStateSOAPFeaturizer = StateSOAPFeaturizer


@dataclass
class PartitionedFeatures:
    """Internal / environment / cross feature blocks from one neighbor search.

    ``x_in``, ``x_env`` : :class:`IrrepFeatures` of ``A(s)`` and ``A(1 - s)``.
    ``x_cross``         : ``{lam: (N, 2lam+1, P)}`` cross spectra of ``A(s)`` with ``A(1-s)``.
    ``a_env``           : ``(N,)`` environment activity ``sum_j (1 - s_ij) f_cut(r_ij)``; exactly
                          zero for an isolated group.
    ``edge_index``      : the one neighbor list everything was built on.
    ``edge_weight``     : ``(E,)`` the membership ``s`` on those edges.
    """

    x_in: IrrepFeatures
    x_env: IrrepFeatures
    x_cross: dict[int, torch.Tensor]
    a_env: torch.Tensor
    edge_index: torch.Tensor
    edge_weight: torch.Tensor

    @property
    def P_edge(self) -> torch.Tensor:  # rsfff spelling
        return self.edge_weight

    @property
    def cross_inv(self) -> torch.Tensor:
        return self.x_cross[0][:, 0, :]


class PartitionedFeaturizer(nn.Module):
    """Split each center's density by a per-edge membership and featurize both halves.

    ``s_ij in [0, 1]`` says how much of edge ``i-j`` belongs to ``i``'s own group. Hard
    memberships (``s = [group_i == group_j]``) give a fragment-internal and an environment
    descriptor; soft ones interpolate the *partition* rather than the finished descriptors, which
    keeps both on the manifold of genuine densities (``A(s) + A(1-s) = A(1)`` exactly).

    Wraps a :class:`SOAPFeaturizer` (held as ``self.featurizer``) and reuses everything it owns --
    neighbor search, edge expansion, compression, spectrum, bispectrum -- so ``x_in`` / ``x_env``
    are bit-compatible with the featurizer's own masked descriptors. The only new computation is
    the cross spectrum (``cross_lambdas``) and ``a_env``.
    """

    def __init__(self, featurizer: SOAPFeaturizer, *, cross_lambdas: Sequence[int] = (0,)) -> None:
        super().__init__()
        self.featurizer = featurizer
        self.cross_lambdas = tuple(sorted({int(v) for v in cross_lambdas}))
        n_channels = featurizer.n_channels
        self._cross_specs, buffers = build_cross_spectrum_specs(
            l_max=featurizer.l_max,
            selected_lambdas=self.cross_lambdas,
            n_channels_a=n_channels,
            n_channels_b=n_channels,
            backend=featurizer.backend,
        )
        for name, tensor in buffers.items():
            self.register_buffer(name, tensor, persistent=False)
        #: per-lambda cross widths, for head sizing.
        self.cross_dims = {
            lam: sum(spec.width for spec in specs) for lam, specs in self._cross_specs.items()
        }

    @property
    def cutoff(self) -> float:
        return self.featurizer.cutoff

    @property
    def feature_dims(self) -> dict[int, int]:
        """Per-lambda widths of ``x_in`` (identical for ``x_env``)."""
        return self.featurizer.feature_dims

    def species_index(self, atomic_numbers: torch.Tensor) -> torch.Tensor:
        return self.featurizer.species_index(atomic_numbers)

    @torch.compiler.disable
    def forward(
        self,
        batch=None,
        *,
        edge_weight: "torch.Tensor | Callable[[torch.Tensor], torch.Tensor] | None" = None,
        group_idx: torch.Tensor | None = None,
        positions: torch.Tensor | None = None,
        atomic_numbers: torch.Tensor | None = None,
        batch_idx: torch.Tensor | None = None,
    ) -> PartitionedFeatures:
        """Pass either ``edge_weight`` (``(E,)`` or a callable on the edge list) or
        ``group_idx`` (hard membership ``s = [g_i == g_j]``)."""
        if (edge_weight is None) == (group_idx is None):
            raise ValueError("pass exactly one of edge_weight or group_idx")
        feat = self.featurizer
        positions, atomic_numbers, batch_idx = _unpack(batch, positions, atomic_numbers, batch_idx)
        species_idx = feat.species_index(atomic_numbers)
        n_atoms = int(positions.shape[0])

        edge_index = feat.build_edges(positions, batch_idx)
        RY = feat.expand(positions, edge_index)
        if group_idx is not None:
            s = (group_idx[edge_index[0]] == group_idx[edge_index[1]]).to(RY.dtype)
        else:
            s = _edge_weight(edge_weight, edge_index)

        A_in = feat.scatter(RY, edge_index, species_idx, n_atoms, edge_weight=s)
        A_env = feat.scatter(RY, edge_index, species_idx, n_atoms, edge_weight=1.0 - s)
        x_in = feat.contract(A_in, species_idx, batch_idx, edge_index)
        x_env = feat.contract(A_env, species_idx, batch_idx, edge_index)
        x_cross = cross_power_spectrum(
            A_in, A_env, feat.l_max, self.cross_lambdas,
            specs_by_lam=self._cross_specs, cg_buffer_owner=self,
        )

        # Smooth environment activity: how much environment density each center receives,
        # from the same cutoff as the density so it vanishes exactly where the environment does.
        i, j = edge_index[0], edge_index[1]
        r = (positions[j] - positions[i]).norm(dim=-1)
        w = (1.0 - s) * cosine_cutoff(r, feat.cutoff)
        a_env = torch.zeros(n_atoms, dtype=w.dtype, device=w.device).index_add_(0, i, w)

        return PartitionedFeatures(
            x_in=x_in, x_env=x_env, x_cross=x_cross, a_env=a_env,
            edge_index=edge_index, edge_weight=s,
        )
