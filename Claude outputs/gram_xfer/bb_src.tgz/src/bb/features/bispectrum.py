"""Trainable nu=3 lambda-bispectra.

Three implementations with one I/O contract,
``forward(A, species_idx) -> {lam: (N, 2 lam + 1, out_mul)}``, where ``A`` is the density
``(N, n_species, n_max, (l_max+1)^2)`` (or already ``(N, C, (l_max+1)^2)``):

* :class:`E3nnWeightedBispectrum` -- explicit CG einsums; portable, unfused (the e3nn backend's).
* :class:`LearnableBispectrum`    -- the pure nu=3 term as a cuequivariance segmented polynomial.
* :class:`LearnableSymContraction` -- ``cuet.SymmetricContraction`` (orders 1..degree, the MACE
  block); the default for the cue backend.

Each density channel ``c = (Z, n)`` is contracted with itself three times along every coupling
path; learnable weights (per center element, or shared) mix ``(path, channel)`` down to
``out_mul`` outputs without touching the ``m`` axis, so the output is equivariant with parity
``(-1)^lam``. Build them through ``backend.make_weighted_bispectrum(...)`` so a model follows the
e3nn / cue switch. Only these learnable weights differ between backends.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Sequence

import torch
import torch.nn as nn

from ..o3.irreps import split_by_l

if TYPE_CHECKING:
    from ..o3.backend import EquivariantBackend

__all__ = ["E3nnWeightedBispectrum", "LearnableBispectrum", "LearnableSymContraction"]


def _cue():
    try:
        import cuequivariance as cue
        import cuequivariance_torch as cuet
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "the cue bispectrum needs cuequivariance: pip install 'bb[cue]'"
        ) from exc
    return cue, cuet


# --------------------------------------------------------------------------
# e3nn: explicit CG analogue of the cue kernel
# --------------------------------------------------------------------------
def _bispectrum_paths(l_max: int, lam: int) -> list[tuple[int, int, int, int]]:
    """Valid degree-3 coupling paths ``(l1, l2, l3, k)`` for output ``lam``.

    ``l1 <= l2 <= l3`` (the three density factors are the same tensor, so only the
    unordered multiset matters); ``k`` is the intermediate ``l1 (x) l2 -> k``; parity
    is enforced by the two CG selection rules, giving ``l1+l2+l3 == lam (mod 2)``.
    """
    paths: list[tuple[int, int, int, int]] = []
    for l1 in range(l_max + 1):
        for l2 in range(l1, l_max + 1):
            for l3 in range(l2, l_max + 1):
                for k in range(abs(l1 - l2), l1 + l2 + 1):
                    if (l1 + l2 + k) % 2 != 0:
                        continue
                    if lam < abs(k - l3) or lam > k + l3:
                        continue
                    if (k + l3 + lam) % 2 != 0:
                        continue
                    paths.append((l1, l2, l3, k))
    return paths


class E3nnWeightedBispectrum(nn.Module):
    """Trainable, channel-wise nu=3 lambda-bispectrum built from explicit CG einsums.

    The e3nn-backend analogue of :class:`weighted_bispectrum.LearnableBispectrum`,
    with the same I/O contract: ``forward(A, species_idx) -> {lam: (N, 2lam+1, out_mul)}``
    (lam=0 as ``(N, 1, out_mul)``). Each input channel ``c`` (of ``C = n_species*n_max``)
    is contracted with itself three times along every coupling path; a learnable weight
    then mixes the ``(path, channel)`` axis down to ``out_mul`` output channels (per
    element when ``num_elements > 1``, shared when ``num_elements == 1``). Weights act
    only on the feature axis, never on the ``m`` components, so the output is equivariant.

    This is the explicit (unfused, more expensive) counterpart to the cuequivariance
    kernel -- correctness/portability, not speed; cue is the fast path on CUDA.
    """

    def __init__(
        self,
        *,
        backend: "EquivariantBackend",
        n_species: int,
        n_max: int,
        l_max: int,
        selected_lambdas: Sequence[int] = (0, 2),
        out_mul: int | None = None,
        num_elements: int | None = None,
        weight_init_std: float = 1.0,
        # accepted for signature parity with the cue path; unused here (pure nu=3):
        degrees: Sequence[int] = (3,),
        contraction_degree: int = 3,
        method: str | None = None,
        dtype: torch.dtype | None = None,
        **_ignored,
    ) -> None:
        super().__init__()
        self.n_channels = int(n_species) * int(n_max)
        self.l_max = int(l_max)
        self.lambdas = tuple(sorted({int(v) for v in selected_lambdas}))
        self.out_mul = int(out_mul) if out_mul is not None else self.n_channels
        self.num_elements = int(num_elements) if num_elements is not None else int(n_species)
        dtype = dtype or torch.get_default_dtype()

        # Per lam: combined CG buffers for every path and a weight over (path, channel).
        self._paths: dict[int, tuple[tuple[int, int, int, int], ...]] = {}
        self.weights = nn.ParameterDict()
        for lam in self.lambdas:
            paths = _bispectrum_paths(self.l_max, lam)
            if not paths:
                raise ValueError(
                    f"no nu=3 coupling paths reach lambda={lam} with l_max={self.l_max}; "
                    "increase l_max"
                )
            self._paths[lam] = tuple(paths)
            for idx, (l1, l2, l3, k) in enumerate(paths):
                cg = self._combined_cg(backend, l1, l2, l3, k, lam).to(dtype)
                self.register_buffer(f"_cg_{lam}_{idx}", cg, persistent=False)
            n_feat = len(paths) * self.n_channels
            w = torch.randn(self.num_elements, n_feat, self.out_mul, dtype=dtype)
            self.weights[str(lam)] = nn.Parameter(w * (weight_init_std / math.sqrt(n_feat)))

    @staticmethod
    def _combined_cg(backend, l1, l2, l3, k, lam) -> torch.Tensor:
        # C[m1,m2,m3,mu] = sum_mk w3j(l1,l2,k)[m1,m2,mk] * w3j(k,l3,lam)[mk,m3,mu]
        a = backend.wigner_3j(l1, l2, k).to(torch.float64)      # (2l1+1, 2l2+1, 2k+1)
        b = backend.wigner_3j(k, l3, lam).to(torch.float64)     # (2k+1, 2l3+1, 2lam+1)
        return torch.einsum("abk,kcd->abcd", a, b)              # (.., .., .., 2lam+1)

    @property
    def feature_dims(self) -> dict[int, int]:
        return {lam: self.out_mul for lam in self.lambdas}

    def forward(self, A: torch.Tensor, species_idx: torch.Tensor) -> dict[int, torch.Tensor]:
        if A.dim() == 4:
            A = A.reshape(A.shape[0], self.n_channels, A.shape[-1])  # (N, C, (l_max+1)^2)
        n = A.shape[0]
        A_by_l = split_by_l(A, self.l_max)                    # each (N, C, 2l+1)

        if self.num_elements == 1:
            elem = torch.zeros(n, dtype=torch.long, device=A.device)
        else:
            elem = species_idx.to(torch.long)

        out: dict[int, torch.Tensor] = {}
        for lam in self.lambdas:
            feats = []
            for idx, (l1, l2, l3, _k) in enumerate(self._paths[lam]):
                cg = getattr(self, f"_cg_{lam}_{idx}")
                if cg.device != A.device or cg.dtype != A.dtype:
                    cg = cg.to(device=A.device, dtype=A.dtype)
                # per-channel triple product coupled to mu (=s): (N, 2lam+1, C)
                t = torch.einsum(
                    "pqrs,ncp,ncq,ncr->nsc",
                    cg, A_by_l[l1], A_by_l[l2], A_by_l[l3],
                )
                feats.append(t)                                # (N, 2lam+1, C)
            f = torch.cat(feats, dim=-1)                       # (N, 2lam+1, n_paths*C)
            w = self.weights[str(lam)][elem]                   # (N, n_feat, out_mul)
            out[lam] = torch.einsum("nmf,nfu->nmu", f, w)      # (N, 2lam+1, out_mul)
        return out


# --------------------------------------------------------------------------
# irreps helpers
# --------------------------------------------------------------------------
def _irreps_str(mul: int, ells: Sequence[int]) -> str:
    """e.g. mul=4, ells=(0,1,2) -> '4x0e + 4x1o + 4x2e' (parity = (-1)**l)."""
    return " + ".join(f"{mul}x{l}{'e' if l % 2 == 0 else 'o'}" for l in ells)


def _density_to_ir_mul(A: torch.Tensor) -> torch.Tensor:
    """(N, C, (l_max+1)**2) density -> (N, C*(l_max+1)**2) in cue.ir_mul layout.

    `A`'s last axis is already component-major over irreps [0e | 1o | 2e | ...].
    ir_mul wants, per irrep, (2l+1, mul) i.e. component-major / mul-inner, so we
    just move the channel axis inside the component axis. Mirrors the preprocessing
    in the cuet.SymmetricContraction docs (`transpose(1, 2).flatten(1)`).
    """
    n = A.shape[0]
    return A.transpose(1, 2).reshape(n, -1)


def _split_ir_mul_output(
    y: torch.Tensor, lambdas: Sequence[int], mul: int
) -> dict[int, torch.Tensor]:
    """Flat ir_mul output (N, sum_lam mul*(2lam+1)) -> {lam: (N, 2lam+1, mul)}.

    Output irreps are laid out in the given `lambdas` order; each lam block is
    (2lam+1, mul) component-major, so a plain reshape recovers the component axis.
    """
    out: dict[int, torch.Tensor] = {}
    n, off = y.shape[0], 0
    for lam in lambdas:
        d = mul * (2 * lam + 1)
        out[lam] = y[:, off : off + d].reshape(n, 2 * lam + 1, mul)
        off += d
    return out


# --------------------------------------------------------------------------
# Pure nu = 3 bispectrum (descriptor + SegmentedPolynomial)
# --------------------------------------------------------------------------
class LearnableBispectrum(nn.Module):
    """Learnable equivariant lambda-bispectrum (body order nu = 3, channel-wise).

    p^{lam}_mu[i, u] = sum_{paths} W[species_i, path, u]
                       * (A (x) A (x) A)^{lam}_{mu}[i, u]

    where `u` runs over the `n_channels` input channels (treated in parallel, i.e.
    each channel is contracted with itself -- the standard channel-wise reduction;
    cross-channel mixing is left to the surrounding linear layers, exactly as in
    MACE). Weights are per-species via `num_elements = n_species`.

    Parameters
    ----------
    n_species, n_max, l_max : as in your featurizer (n_channels = n_species*n_max).
    selected_lambdas        : output lambdas, e.g. (0, 2) or (0, 1, 2).
    out_mul                 : output multiplicity P_lam. Defaults to n_channels
                              (channel-preserving, MACE-like). Set smaller to
                              compress, larger to widen.
    degrees                 : contraction degrees. (3,) = pure bispectrum. You can
                              pass (1, 2, 3) to fold in lower orders too.
    """

    def __init__(
        self,
        *,
        n_species: int,
        n_max: int,
        l_max: int,
        selected_lambdas: Sequence[int] = (0, 2),
        out_mul: int | None = None,
        num_elements: int | None = None,
        degrees: Sequence[int] = (3,),
        weight_init_std: float = 1.0,
        method: str = "",          # "" -> cue auto-picks; use "naive" on CPU
        math_dtype: torch.dtype | None = None,
        dtype: torch.dtype | None = None,
    ) -> None:
        super().__init__()
        cue, cuet = _cue()
        self.n_channels = n_species * n_max
        self.l_max = int(l_max)
        self.lambdas = tuple(sorted({int(v) for v in selected_lambdas}))
        self.out_mul = int(out_mul) if out_mul is not None else self.n_channels
        # Per-element weights are decoupled from the density channel count: pass
        # num_elements=1 for shared weights (all atoms use one weight set) while
        # n_channels stays n_species*n_max. Defaults to per-species (MACE-style).
        self.num_elements = int(num_elements) if num_elements is not None else int(n_species)
        dtype = dtype or torch.get_default_dtype()

        irreps_in = cue.Irreps("O3", _irreps_str(self.n_channels, range(l_max + 1)))
        irreps_out = cue.Irreps("O3", _irreps_str(self.out_mul, self.lambdas))

        desc = cue.descriptors.symmetric_contraction(
            irreps_in, irreps_out, tuple(int(d) for d in degrees)
        )
        # Sanity: descriptor operands are (weights, input, [input...], output);
        # after dedup of the repeated input, inputs == [weights, x].
        poly = desc.polynomial
        self._n_weights = poly.inputs[0].size
        self._in_dim = poly.inputs[1].size
        self.poly = cuet.SegmentedPolynomial(poly, method=method, math_dtype=math_dtype)

        # Per-element weights, gathered per atom in forward (avoids any
        # method-specific constraints on indexed operands). num_elements=1 => shared.
        w = torch.randn(self.num_elements, self._n_weights, dtype=dtype) * weight_init_std
        self.weight = nn.Parameter(w)

    @property
    def feature_dims(self) -> dict[int, int]:
        return {lam: self.out_mul for lam in self.lambdas}

    def _weight_index(self, species_idx, n, device):
        # Shared weights (num_elements=1) index a single row; else per-species.
        if self.num_elements == 1:
            return torch.zeros(n, dtype=torch.long, device=device)
        return species_idx.to(torch.long)

    def forward(
        self, A: torch.Tensor, species_idx: torch.Tensor
    ) -> dict[int, torch.Tensor]:
        # A: (N, n_species, n_max, (l_max+1)**2) or already (N, C, (l_max+1)**2)
        if A.dim() == 4:
            A = A.reshape(A.shape[0], self.n_channels, A.shape[-1])
        x = _density_to_ir_mul(A)                      # (N, C*(l_max+1)**2), ir_mul
        idx = self._weight_index(species_idx, x.shape[0], x.device)  # (N,)
        w = self.weight.to(x.dtype)[idx]               # (N, n_weights)
        y = self.poly([w, x])[0]                        # (N, irreps_out.dim), ir_mul
        return _split_ir_mul_output(y, self.lambdas, self.out_mul)


# --------------------------------------------------------------------------
# Convenience wrapper: body orders 1..degree (standard MACE block)
# --------------------------------------------------------------------------
class LearnableSymContraction(nn.Module):
    """Wrapper over `cuet.SymmetricContraction` (orders 1..contraction_degree).

    Use this if you want the whole low-order learnable polynomial fused into one
    documented kernel. The genuine bispectrum is the top (degree-3) term; orders
    1-2 overlap with your existing power spectrum but are cheap and the net can
    down-weight them. Same I/O contract as `LearnableBispectrum`.
    """

    def __init__(
        self,
        *,
        n_species: int,
        n_max: int,
        l_max: int,
        selected_lambdas: Sequence[int] = (0, 2),
        out_mul: int | None = None,
        num_elements: int | None = None,
        contraction_degree: int = 3,
        method: str | None = None,     # set "naive" on CPU
        dtype: torch.dtype | None = None,
        math_dtype: torch.dtype | None = None,
    ) -> None:
        super().__init__()
        cue, cuet = _cue()
        self.n_channels = n_species * n_max
        self.lambdas = tuple(sorted({int(v) for v in selected_lambdas}))
        self.out_mul = int(out_mul) if out_mul is not None else self.n_channels
        # Decoupled from the density channel count: num_elements=1 -> shared weights.
        self.num_elements = int(num_elements) if num_elements is not None else int(n_species)

        irreps_in = cue.Irreps("O3", _irreps_str(self.n_channels, range(l_max + 1)))
        irreps_out = cue.Irreps("O3", _irreps_str(self.out_mul, self.lambdas))
        self.sc = cuet.SymmetricContraction(
            irreps_in,
            irreps_out,
            contraction_degree=contraction_degree,
            num_elements=self.num_elements,
            layout_in=cue.ir_mul,
            layout_out=cue.ir_mul,
            dtype=dtype or torch.get_default_dtype(),
            math_dtype=math_dtype,
            method=method,
        )

    @property
    def feature_dims(self) -> dict[int, int]:
        return {lam: self.out_mul for lam in self.lambdas}

    def forward(
        self, A: torch.Tensor, species_idx: torch.Tensor
    ) -> dict[int, torch.Tensor]:
        if A.dim() == 4:
            A = A.reshape(A.shape[0], self.n_channels, A.shape[-1])
        x = _density_to_ir_mul(A)                         # (N, ...), ir_mul
        if self.num_elements == 1:
            idx = torch.zeros(x.shape[0], dtype=torch.int32, device=x.device)
        else:
            idx = species_idx.to(torch.int32)
        y = self.sc(x, idx)                                # (N, irreps_out.dim)
        return _split_ir_mul_output(y, self.lambdas, self.out_mul)
