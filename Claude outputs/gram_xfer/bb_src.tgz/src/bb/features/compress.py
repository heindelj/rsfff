"""Learned density-channel weights."""

from __future__ import annotations

import torch
import torch.nn as nn

from ..nn.mlp import mlp

__all__ = ["AtomWeightNet"]


class AtomWeightNet(nn.Module):
    """Map a per-atom embedding ``e`` to density-channel weights ``w(e)``: ``(N, Kw)``.

    ``w(e_j)`` weights neighbor ``j``'s contribution to the density
    ``A[i,k,n,lm] = sum_j w_k(e_j) R_n(r_ij) Y_lm f_cut`` (:class:`bb.features.StateSOAPFeaturizer`).
    When ``e_j`` carries more than the element -- a fragment charge, a spin -- the density can
    tell, say, an H of hydroxide from an H of hydronium, which a species one-hot cannot. The
    weights are invariant scalars, so everything built from the density stays equivariant.
    """

    def __init__(
        self, emb_dim: int, weight_channels: int, *, hidden: int = 32, depth: int = 1
    ) -> None:
        super().__init__()
        self.weight_channels = int(weight_channels)
        self.net = mlp(emb_dim, hidden, depth, weight_channels)

    def forward(self, embedding: torch.Tensor) -> torch.Tensor:
        return self.net(embedding)                                  # (N, Kw)
