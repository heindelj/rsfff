"""Body-order contractions of the density: power spectra (nu=2) and the fixed bispectrum.

    A  (N, C, n, (l_max+1)^2)  -->  {lam: (N, 2 lam + 1, P_lam)}

:func:`equivariant_power_spectrum` is the lambda-SOAP of one density with itself (symmetry
reduced: unordered ``(l1, l2)`` pairs and the channel upper triangle). :func:`cross_power_spectrum`
couples two *different* densities (e.g. a fragment-internal and an environment density of the same
center) and keeps the full ordered enumeration. Both return natural-parity blocks:
``lam`` has parity ``(-1)^lam`` (``0e, 1o, 2e, 3o, ...``).

The spec builders are public so a module can build the CG tables once, register them as
(non-persistent) buffers, and call the contraction with ``specs_by_lam=..., cg_buffer_owner=self``.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Sequence

import torch
import torch.nn as nn

from ..o3.backend import resolve_backend
from ..o3.irreps import split_by_l

if TYPE_CHECKING:
    from ..o3.backend import EquivariantBackend

__all__ = [
    "PairSpec",
    "power_spectrum",
    "bispectrum",
    "build_power_spectrum_specs",
    "equivariant_power_spectrum",
    "build_cross_spectrum_specs",
    "cross_power_spectrum",
]


def power_spectrum(A: torch.Tensor, l_max: int) -> torch.Tensor:
    """
    nu = 2 invariants (SOAP power spectrum):
        p[i, Z, n, Z', n', l] = (1/sqrt(2l+1)) * sum_m A[i,Z,n,l,m] * A[i,Z',n',l,m]

    A: (N, Z, n, (l_max+1)**2)
    Returns: (N, n_features)
    """
    N = A.shape[0]
    feats = []
    for l, A_l in enumerate(split_by_l(A, l_max)):
        # (N, Z, n, 2l+1) x (N, Z', n', 2l+1) -> (N, Z, n, Z', n')
        p = torch.einsum("nzim,nyjm->nzyij", A_l, A_l) / math.sqrt(2 * l + 1)
        feats.append(p.reshape(N, -1))
    return torch.cat(feats, dim=-1)


def bispectrum(A: torch.Tensor, l_max: int) -> torch.Tensor:
    """
    nu = 3 invariants (SOAP bispectrum):
        B[i, ..., l1, l2, l3] = sum_{m1 m2 m3} CG^{l1 l2 l3}_{m1 m2 m3}
                                * A[i,Z1,n1,l1,m1] * A[i,Z2,n2,l2,m2] * A[i,Z3,n3,l3,m3]

    Only (l1, l2, l3) with valid triangle and l1+l2+l3 even contribute.

    A: (N, Z, n, (l_max+1)**2)
    Returns: (N, n_features)
    """
    from e3nn import o3  # lazy: legacy invariant helper
    N, Z, n, _ = A.shape
    A_by_l = split_by_l(A, l_max)  # each (N, Z, n, 2l+1)
    feats = []
    for l1 in range(l_max + 1):
        for l2 in range(l1, l_max + 1):
            for l3 in range(l2, l_max + 1):
                if (l1 + l2 + l3) % 2 != 0:
                    continue                       # parity selection rule
                if l3 > l1 + l2 or l3 < abs(l1 - l2):
                    continue                       # triangle inequality
                cg = o3.wigner_3j(l1, l2, l3).to(A)   # (2l1+1, 2l2+1, 2l3+1)
                # b[i, Z1,n1, Z2,n2, Z3,n3] = sum_{m1,m2,m3} cg[m1,m2,m3]
                #                              * A_l1[i,Z1,n1,m1]
                #                              * A_l2[i,Z2,n2,m2]
                #                              * A_l3[i,Z3,n3,m3]
                b = torch.einsum(
                    "abc,nzia,nyjb,nxkc->nzyxijk",
                    cg, A_by_l[l1], A_by_l[l2], A_by_l[l3],
                )
                feats.append(b.reshape(N, -1))
    return torch.cat(feats, dim=-1)


# --------------------------------------------------------------------------
# Equivariant lambda-power-spectrum (lambda-SOAP, body order nu = 2)
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class PairSpec:
    """One ``(l1, l2) -> lam`` coupling of two density factors, and its output width."""

    lam: int
    l1: int
    l2: int
    width: int
    cg_buffer_name: str


def build_power_spectrum_specs(
    *,
    l_max: int,
    selected_lambdas: Sequence[int],
    n_channels: int,
    backend: "EquivariantBackend | str" = "e3nn",
) -> tuple[dict[int, tuple[PairSpec, ...]], dict[str, torch.Tensor]]:
    """Build reusable metadata and constant tensors for lambda-SOAP."""
    backend = resolve_backend(backend)
    specs: dict[int, list[PairSpec]] = {}
    buffers: dict[str, torch.Tensor] = {}
    cg_index = 0
    for lam in sorted({int(v) for v in selected_lambdas}):
        lam_specs: list[PairSpec] = []
        for l1 in range(l_max + 1):
            for l2 in range(l1, l_max + 1):
                if l2 < abs(l1 - lam) or l2 > l1 + lam:
                    continue
                if (l1 + l2 + lam) % 2 != 0:
                    continue
                cg_name = f"_equivariant_cg_{cg_index}"
                buffers[cg_name] = backend.wigner_3j(l1, l2, lam).to(torch.get_default_dtype())
                cg_index += 1
                width = (
                    n_channels * (n_channels + 1) // 2
                    if l1 == l2 else n_channels * n_channels
                )
                lam_specs.append(
                    PairSpec(
                        lam=lam,
                        l1=l1,
                        l2=l2,
                        width=width,
                        cg_buffer_name=cg_name,
                    )
                )
        if not lam_specs:
            raise ValueError(
                f"no (l1, l2) density pairs couple to lambda={lam} with l_max={l_max}; "
                "increase l_max"
            )
        specs[lam] = lam_specs
    rows, cols = torch.triu_indices(n_channels, n_channels, offset=0)
    buffers["_equivariant_triu_rows"] = rows
    buffers["_equivariant_triu_cols"] = cols
    return {lam: tuple(v) for lam, v in specs.items()}, buffers


def equivariant_power_spectrum(
    A: torch.Tensor,
    l_max: int,
    selected_lambdas: Sequence[int],
    specs_by_lam: dict[int, tuple[PairSpec, ...]] | None = None,
    triu_rows: torch.Tensor | None = None,
    triu_cols: torch.Tensor | None = None,
    cg_lookup: dict[str, torch.Tensor] | None = None,
    cg_buffer_owner: nn.Module | None = None,
    backend: "EquivariantBackend | str" = "e3nn",
) -> dict[int, torch.Tensor]:
    """Equivariant SOAP power spectrum (symmetry-reduced).

        p^{lam}_mu[i, a, b] = sum_{m1,m2} W^{l1 l2 lam}_{m1 m2 mu}
                              * A[i, a, m1] * A[i, b, m2]

    where `a = (Z, n, l1)` and `b = (Z', n', l2)` are composite density channels
    ((Z, n) flattened into a single channel axis of size `C = n_species * n_max`).

    The two density factors are interchangeable: for the parity-selected even
    couplings used here (`l1 + l2` even, `lam` in {0, 2}) the 3j column-swap
    symmetry gives `p[a, b] == p[b, a]` exactly. We therefore enumerate only
    unordered pairs (`l1 <= l2`, and `c1 <= c2` when `l1 == l2`), which removes the
    redundant half-to-three-quarters of the channels with no loss of information.

    `A`: `(N, Z, n, (l_max+1)**2)` density coefficients from `DensityExpansion`.

    Returns a dict mapping each requested `lam` to a tensor of shape
    `(N, 2*lam + 1, P_lam)`, with the component axis in the middle to mirror the
    featomic block layout consumed by the network heads. `P_lam` is fixed by
    `n_species`/`n_max`/`l_max`, independent of which neighbor species actually
    appear in a given structure.
    """
    n_atoms, n_species, n_max, _ = A.shape
    n_channels = n_species * n_max
    # per-l composite channels: (N, C, 2l+1), C = n_species * n_max
    A_by_l = [
        a.reshape(n_atoms, n_channels, a.shape[-1]) for a in split_by_l(A, l_max)
    ]
    if specs_by_lam is None:
        specs_by_lam, buffers = build_power_spectrum_specs(
            l_max=l_max, selected_lambdas=selected_lambdas, n_channels=n_channels,
            backend=backend,
        )
        triu_rows = buffers["_equivariant_triu_rows"].to(device=A.device)
        triu_cols = buffers["_equivariant_triu_cols"].to(device=A.device)
        cg_lookup = {
            name: tensor.to(device=A.device, dtype=A.dtype)
            for name, tensor in buffers.items()
            if name.startswith("_equivariant_cg_")
        }
    elif triu_rows is None or triu_cols is None or (cg_lookup is None and cg_buffer_owner is None):
        raise ValueError(
            "specs_by_lam requires matching triu_rows, triu_cols, and cached Wigner tensors"
        )

    out: dict[int, torch.Tensor] = {}
    for lam in selected_lambdas:
        lam = int(lam)
        lam_specs = specs_by_lam[lam]
        lam_out = A.new_empty(n_atoms, 2 * lam + 1, sum(spec.width for spec in lam_specs))
        offset = 0
        for spec in lam_specs:
            cg = (
                cg_lookup[spec.cg_buffer_name]
                if cg_lookup is not None else getattr(cg_buffer_owner, spec.cg_buffer_name)
            )
            if cg.device != A.device or cg.dtype != A.dtype:
                cg = cg.to(device=A.device, dtype=A.dtype)
            # -> (N, 2lam+1, C, C)
            p = torch.einsum("abc,nia,njb->ncij", cg, A_by_l[spec.l1], A_by_l[spec.l2])
            next_offset = offset + spec.width
            if spec.l1 == spec.l2:
                lam_out[:, :, offset:next_offset] = p[:, :, triu_rows, triu_cols]
            else:
                lam_out[:, :, offset:next_offset] = p.reshape(n_atoms, p.shape[1], spec.width)
            offset = next_offset
        out[lam] = lam_out
    return out


def build_cross_spectrum_specs(
    *,
    l_max: int,
    selected_lambdas: Sequence[int],
    n_channels_a: int,
    n_channels_b: int,
    backend: "EquivariantBackend | str" = "e3nn",
    buffer_prefix: str = "_cross_cg_",
) -> tuple[dict[int, tuple[PairSpec, ...]], dict[str, torch.Tensor]]:
    """Spec table for :func:`cross_power_spectrum`.

    Unlike :func:`build_power_spectrum_specs` this enumerates **ordered**
    ``(l1, l2)`` pairs over the full square and never reduces to the upper triangle: the two
    density factors are *different* tensors, so ``p[a, b] != p[b, a]`` and both orderings carry
    information. Widths are always ``n_channels_a * n_channels_b``.
    """
    backend = resolve_backend(backend)
    specs: dict[int, list[PairSpec]] = {}
    buffers: dict[str, torch.Tensor] = {}
    cg_index = 0
    for lam in sorted({int(v) for v in selected_lambdas}):
        lam_specs: list[PairSpec] = []
        for l1 in range(l_max + 1):
            for l2 in range(l_max + 1):
                if l2 < abs(l1 - lam) or l2 > l1 + lam:
                    continue
                if (l1 + l2 + lam) % 2 != 0:
                    continue
                cg_name = f"{buffer_prefix}{cg_index}"
                buffers[cg_name] = backend.wigner_3j(l1, l2, lam).to(
                    torch.get_default_dtype()
                )
                cg_index += 1
                lam_specs.append(
                    PairSpec(
                        lam=lam,
                        l1=l1,
                        l2=l2,
                        width=n_channels_a * n_channels_b,
                        cg_buffer_name=cg_name,
                    )
                )
        if not lam_specs:
            raise ValueError(
                f"no (l1, l2) density pairs couple to lambda={lam} with l_max={l_max}; "
                "increase l_max"
            )
        specs[lam] = lam_specs
    return {lam: tuple(v) for lam, v in specs.items()}, buffers


def cross_power_spectrum(
    A: torch.Tensor,
    B: torch.Tensor,
    l_max: int,
    selected_lambdas: Sequence[int],
    specs_by_lam: dict[int, tuple[PairSpec, ...]] | None = None,
    cg_lookup: dict[str, torch.Tensor] | None = None,
    cg_buffer_owner: nn.Module | None = None,
    backend: "EquivariantBackend | str" = "e3nn",
) -> dict[int, torch.Tensor]:
    """Equivariant power spectrum of **two different** densities (the cross block).

        p^{lam}_mu[i, a, b] = sum_{m1,m2} W^{l1 l2 lam}_{m1 m2 mu}
                              * A[i, a, m1] * B[i, b, m2]

    The ``rho_in (x) rho_env`` block: it correlates, e.g., a fragment-internal density against
    the environment density of the *same* center, which a concatenation of the two finished
    spectra cannot express (the spectra are each quadratic in one density; this is the bilinear
    term between them).

    Because ``A != B`` the swap symmetry that lets :func:`equivariant_power_spectrum` keep only
    unordered ``(l1, l2)`` pairs and the channel upper-triangle does not hold; the full ordered
    enumeration and the full ``Ca x Cb`` channel matrix are kept.

    The vertex guarantee is inherited, not enforced: if ``B`` is an exact zero (an isolated
    fragment's environment density is an empty sum) every output block is an exact zero.

    ``A``: ``(N, Za, na, (l_max+1)**2)``, ``B``: ``(N, Zb, nb, (l_max+1)**2)`` -- channel axes
    may differ. Returns ``{lam: (N, 2*lam+1, P_lam)}``.
    """
    n_atoms = A.shape[0]
    n_channels_a = A.shape[1] * A.shape[2]
    n_channels_b = B.shape[1] * B.shape[2]
    A_by_l = [
        a.reshape(n_atoms, n_channels_a, a.shape[-1]) for a in split_by_l(A, l_max)
    ]
    B_by_l = [
        b.reshape(n_atoms, n_channels_b, b.shape[-1]) for b in split_by_l(B, l_max)
    ]
    if specs_by_lam is None:
        specs_by_lam, buffers = build_cross_spectrum_specs(
            l_max=l_max,
            selected_lambdas=selected_lambdas,
            n_channels_a=n_channels_a,
            n_channels_b=n_channels_b,
            backend=backend,
        )
        cg_lookup = {
            name: tensor.to(device=A.device, dtype=A.dtype)
            for name, tensor in buffers.items()
        }
    elif cg_lookup is None and cg_buffer_owner is None:
        raise ValueError("specs_by_lam requires cached Wigner tensors")

    out: dict[int, torch.Tensor] = {}
    for lam in selected_lambdas:
        lam = int(lam)
        lam_specs = specs_by_lam[lam]
        lam_out = A.new_empty(n_atoms, 2 * lam + 1, sum(spec.width for spec in lam_specs))
        offset = 0
        for spec in lam_specs:
            cg = (
                cg_lookup[spec.cg_buffer_name]
                if cg_lookup is not None else getattr(cg_buffer_owner, spec.cg_buffer_name)
            )
            if cg.device != A.device or cg.dtype != A.dtype:
                cg = cg.to(device=A.device, dtype=A.dtype)
            # -> (N, 2lam+1, Ca, Cb)
            p = torch.einsum("abc,nia,njb->ncij", cg, A_by_l[spec.l1], B_by_l[spec.l2])
            next_offset = offset + spec.width
            lam_out[:, :, offset:next_offset] = p.reshape(n_atoms, p.shape[1], spec.width)
            offset = next_offset
        out[lam] = lam_out
    return out
