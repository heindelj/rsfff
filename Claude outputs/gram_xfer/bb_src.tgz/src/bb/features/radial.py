"""Radial bases and cutoff envelopes."""

from __future__ import annotations

import math

import torch
import torch.nn as nn

__all__ = [
    "BesselBasis",
    "MorseBasis",
    "cosine_cutoff",
    "polynomial_envelope",
    "bessel_envelope_basis",
]


class BesselBasis(nn.Module):
    """Smooth Bessel radial basis (DimeNet-style), orthonormal on ``[0, r_cut]``.

    ``R_n(r) = sqrt(2/r_c) sin(n pi r / r_c) / r``. ``freqs`` is a *persistent* buffer, so it is
    part of every checkpoint that contains a featurizer; its key path
    (``...density.radial.freqs``) must not change.
    """

    def __init__(self, n_max: int, cutoff: float):
        super().__init__()
        self.n_max = n_max
        self.cutoff = cutoff
        freqs = torch.arange(1, n_max + 1, dtype=torch.float32) * math.pi
        self.register_buffer("freqs", freqs)
        self.norm = math.sqrt(2.0 / cutoff)

    def forward(self, r: torch.Tensor) -> torch.Tensor:
        # r: (E,)  ->  (E, n_max)
        r_safe = r.clamp(min=1e-8).unsqueeze(-1)
        return self.norm * torch.sin(self.freqs * r_safe / self.cutoff) / r_safe


def cosine_cutoff(r: torch.Tensor, cutoff: float) -> torch.Tensor:
    """Smooth cosine cutoff that goes to 0 at ``r = cutoff`` with zero derivative."""
    return 0.5 * (torch.cos(math.pi * r / cutoff) + 1.0) * (r < cutoff).to(r.dtype)


def polynomial_envelope(u: torch.Tensor, p: float = 6.0) -> torch.Tensor:
    """DimeNet polynomial envelope on ``u = r / r_c`` in ``[0, 1]``.

    Vanishes together with its first two derivatives at ``u = 1``, which keeps forces continuous
    when a neighbor enters or leaves the graph.
    """
    return (
        1.0
        - (p + 1.0) * (p + 2.0) / 2.0 * u.pow(p)
        + p * (p + 2.0) * u.pow(p + 1.0)
        - p * (p + 1.0) / 2.0 * u.pow(p + 2.0)
    )


def bessel_envelope_basis(r: torch.Tensor, cutoff: float, num_basis: int, p: float = 6.0) -> torch.Tensor:
    """Bessel ``j0`` radial basis times :func:`polynomial_envelope`: ``(E,) -> (E, B)``.

    ``sin(n pi u)/u`` (via ``sinc``, finite at ``u = 0``), scaled by ``sqrt(2/r_c)``. This is the
    edge embedding message passing feeds its radial MLP.
    """
    u = (r / cutoff).clamp(min=0.0, max=1.0).unsqueeze(-1)          # (E, 1)
    n = torch.arange(1, num_basis + 1, dtype=r.dtype, device=r.device)  # (B,)
    # sin(n pi u) / u = n * pi * sinc(n * u)   (torch.sinc(x) = sin(pi x)/(pi x))
    radial = n * math.pi * torch.sinc(n * u)                        # (E, B)
    return radial * polynomial_envelope(u, p) * math.sqrt(2.0 / cutoff)


class MorseBasis(nn.Module):
    """Morse-variable radial basis for bonded distances.

    ``phi_n(r) = y**n`` for ``n = 0..n_basis-1``, with ``y = exp(-a (r / r0 - 1))`` and ``r0`` per
    species pair (default: sum of covalent radii, :data:`bb.graph.bonded.COVALENT_RADII`). Unlike a
    Bessel basis with a cutoff envelope it has no cutoff, stays bounded as ``r`` grows, and
    contains the standard bond-stretch forms (Morse = ``y**2 - 2y``).

    ``r0`` is a buffer ``log_r0`` (a parameter with ``learn_r0=True``) of shape
    ``(n_species, n_species)``; pass ``r0`` to use tabulated or measured reference lengths.

    ``polynomial="legendre"`` returns ``P_n((y - 1) / width)`` instead of ``y**n``: the same
    space of functions (polynomials in y of degree < n_basis), far better conditioned for least
    squares (powers of y over a narrow range are nearly collinear, and normal equations square
    that). The default ``"power"`` keeps the existing numerics.
    """

    def __init__(
        self,
        atomic_numbers,
        n_basis: int = 6,
        a: float = 2.0,
        r0: torch.Tensor | None = None,
        learn_r0: bool = False,
        polynomial: str = "power",
        width: float = 0.3,
    ):
        super().__init__()
        if polynomial not in ("power", "legendre"):
            raise ValueError(f"polynomial must be 'power' or 'legendre', got {polynomial!r}")
        self.n_basis = n_basis
        self.a = a
        self.polynomial, self.width = polynomial, float(width)
        if r0 is None:
            from ..graph.bonded import COVALENT_RADII

            missing = sorted({int(z) for z in atomic_numbers} - COVALENT_RADII.keys())
            if missing:
                raise KeyError(f"MorseBasis: no covalent radius for Z={missing}; pass r0")
            rad = torch.tensor([COVALENT_RADII[int(z)] for z in atomic_numbers], dtype=torch.float64)
            r0 = rad[:, None] + rad[None, :]
        r0 = torch.as_tensor(r0, dtype=torch.get_default_dtype())
        if learn_r0:
            self.log_r0 = nn.Parameter(r0.log())
        else:
            self.register_buffer("log_r0", r0.log())
        self.register_buffer("powers", torch.arange(n_basis, dtype=torch.get_default_dtype()),
                             persistent=False)

    def forward(self, r: torch.Tensor, si: torch.Tensor, sj: torch.Tensor) -> torch.Tensor:
        """``r``: (P,), species indices ``si``, ``sj``: (P,). Returns (P, n_basis)."""
        log_r0 = 0.5 * (self.log_r0 + self.log_r0.T)   # r0 stays symmetric if it is learned
        r0 = log_r0.exp()[si, sj].to(r.dtype)
        y = torch.exp(-self.a * (r / r0 - 1.0))
        if self.polynomial == "power":
            return y[:, None] ** self.powers.to(r.dtype)
        u = (y - 1.0) / self.width
        out = [torch.ones_like(u)]
        if self.n_basis > 1:
            out.append(u)
        for k in range(2, self.n_basis):
            out.append(((2 * k - 1) * u * out[-1] - (k - 1) * out[-2]) / k)
        return torch.stack(out[: self.n_basis], -1)
