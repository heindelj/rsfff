"""Time-reversal parity: features that are even (T+) or odd (T-) under a global sign flip of a
caller-supplied per-atom input.

bb does not know what the odd input is. For a collinear magnet it is the signed moment of each
site; it could be any per-atom quantity whose global sign is a gauge. The rule is the one e3nn
applies to spatial parity, on a separate tag:

* products multiply tags: (+)(+) -> +, (+)(-) -> -, (-)(-) -> +;
* a map applied to odd features must be odd: linear without bias, or an odd function times an
  even gate (``v * sigmoid(g)``), never an additive bias or an even activation;
* anything read out as an energy must be even.

Odd channels are ``(N, C)`` scalars (collinear) or ``(N, C, 3)`` vectors in spin space
(non-collinear, no spin-orbit coupling). Every operation on them is linear in the channel index,
an even gate, a dot product or a squared norm, so the same weights serve both: on collinear
vectors (all along one axis) the vector form gives the scalar form's even features exactly, and the
even features are invariant under a global rotation of spin space (spin space and real space are
separate: the ``1e`` here is a spin-space vector, never mixed with spatial irreps).

Everything is exact by construction; :func:`check_time_reversal` tests a module numerically.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from .nn.init import zero_init_readout
from .nn.mlp import mlp

__all__ = [
    "TRFeatures",
    "OddLinear",
    "TREmbedding",
    "TRMessagePassing",
    "TRReadout",
    "check_time_reversal",
    "odd_lin",
    "odd_dot",
    "odd_sq",
    "odd_gate",
]


def _vec(v: torch.Tensor) -> bool:
    return v.dim() == 3


def odd_lin(layer: nn.Linear, v: torch.Tensor) -> torch.Tensor:
    """A bias-free linear map on the channel index of scalar ``(N, C)`` or vector ``(N, C, 3)`` odd channels."""
    return layer(v.transpose(1, 2)).transpose(1, 2) if _vec(v) else layer(v)


def odd_dot(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """T+ product of two odd channel sets, per channel: ``x y`` or ``x . y``."""
    return (x * y).sum(-1) if _vec(x) else x * y


def odd_sq(v: torch.Tensor) -> torch.Tensor:
    """Per-channel squared size: ``v^2`` or ``|v|^2``."""
    return odd_dot(v, v)


def odd_gate(v: torch.Tensor, g: torch.Tensor) -> torch.Tensor:
    """An odd channel set times a per-channel T+ gate ``g`` ``(N, C)``."""
    return v * g[..., None] if _vec(v) else v * g


@dataclass
class TRFeatures:
    """Per-atom T+ (``even``) and T- (``odd``) channels; ``odd`` is ``(N, Co)`` or ``(N, Co, 3)``."""

    even: torch.Tensor  # (N, Ce)
    odd: torch.Tensor   # (N, Co) or (N, Co, 3)

    def flip(self) -> "TRFeatures":
        """Apply time reversal."""
        return TRFeatures(self.even, -self.odd)


class OddLinear(nn.Linear):
    """``nn.Linear`` without bias: maps odd channels to odd channels."""

    def __init__(self, in_features: int, out_features: int):
        super().__init__(in_features, out_features, bias=False)


class TREmbedding(nn.Module):
    """Initial T-parity features from species and per-atom inputs.

    ``even = Emb(species) + Linear(even_inputs)``;
    ``odd[c] = sum_k odd_inputs[k] * W[species, k, c]`` (linear in the odd inputs, so odd).
    The odd channels of an atom whose odd inputs are zero are zero. With ``vector=True`` the odd
    inputs are spin-space vectors, ``(N, 3)`` or ``(N, K, 3)``, and so are the odd channels.
    """

    def __init__(self, n_species: int, even_dim: int, odd_dim: int, n_odd_inputs: int = 1,
                 n_even_inputs: int = 0):
        super().__init__()
        self.emb = nn.Embedding(n_species, even_dim)
        self.even_in = nn.Linear(n_even_inputs, even_dim) if n_even_inputs else None
        self.odd_w = nn.Parameter(torch.randn(n_species, n_odd_inputs, odd_dim) / n_odd_inputs ** 0.5)

    def forward(self, species: torch.Tensor, odd_inputs: torch.Tensor,
                even_inputs: torch.Tensor | None = None, vector: bool = False) -> TRFeatures:
        if odd_inputs.dim() == (2 if vector else 1):
            odd_inputs = odd_inputs[:, None]
        even = self.emb(species).to(odd_inputs.dtype)
        if self.even_in is not None:
            even = even + self.even_in(even_inputs)
        w = self.odd_w[species].to(odd_inputs.dtype)
        odd = torch.einsum("nkd,nkc->ncd", odd_inputs, w) if vector else torch.einsum("nk,nkc->nc", odd_inputs, w)
        return TRFeatures(even, odd)


class _TRLayer(nn.Module):
    def __init__(self, even_dim, odd_dim, edge_dim, hidden, norm):
        super().__init__()
        c = odd_dim
        self.norm = norm
        # edge gates, all functions of T+ edge features
        self.edge_mlp = mlp(edge_dim, hidden, 2, 2 * even_dim + odd_dim)
        self.w_even = nn.Linear(even_dim, even_dim)
        self.w_oi, self.w_oj = OddLinear(c, even_dim), OddLinear(c, even_dim)
        self.w_odd = OddLinear(c, c)
        self.w_gate_j = nn.Linear(even_dim, c)
        self.update_even = mlp(3 * even_dim, hidden, 2, even_dim)
        self.w_sq = OddLinear(c, even_dim)
        self.gate_odd = nn.Linear(even_dim, c)
        self.mix_odd = OddLinear(c, c)
        zero_init_readout(self.update_even)
        nn.init.zeros_(self.mix_odd.weight)

    def forward(self, x: TRFeatures, edge_index, edge_feat) -> TRFeatures:
        h, v = x.even, x.odd
        a, b = edge_index  # message b -> a
        ce = h.shape[1]
        phi = self.edge_mlp(edge_feat)
        pa, pb, pc = phi[:, :ce], phi[:, ce:2 * ce], phi[:, 2 * ce:]
        m_even = pa * self.w_even(h)[b] + pb * odd_dot(odd_lin(self.w_oi, v)[a], odd_lin(self.w_oj, v)[b])  # T+
        m_odd = odd_gate(odd_lin(self.w_odd, v)[b], pc * torch.sigmoid(self.w_gate_j(h))[b])                # T-
        n = h.shape[0]
        agg_e = h.new_zeros(n, ce).index_add(0, a, m_even) * self.norm
        agg_o = v.new_zeros((n,) + v.shape[1:]).index_add(0, a, m_odd) * self.norm
        h_new = h + self.update_even(torch.cat([h, agg_e, odd_sq(odd_lin(self.w_sq, v))], dim=-1))
        v_new = odd_gate(v, torch.sigmoid(self.gate_odd(h_new)) * 2.0) + odd_lin(self.mix_odd, agg_o)
        return TRFeatures(h_new, v_new)


class TRMessagePassing(nn.Module):
    """Invariant message passing on T-parity scalar features over a directed graph.

    Messages run ``edge_index[1] -> edge_index[0]``; ``edge_feat`` ``(E, D)`` must be T+ (e.g.
    geometry invariants such as :class:`bb.features.PairClusterExpansion` outputs or a radial
    basis). Per layer::

        m+_ab = f1(e_ab) W h_b + f2(e_ab) (A v_a)(B v_b)          (T+)
        m-_ab = f3(e_ab) (C v_b) sigmoid(G h_b)                    (T-)
        h_a  <- h_a + MLP(h_a, sum_b m+_ab, (D v_a)^2)
        v_a  <- 2 v_a sigmoid(H h_a) + M sum_b m-_ab

    Starts close to the identity (the even update and the odd mixing are zero-initialised, the
    odd gate is 1 at zero input).
    """

    def __init__(self, even_dim: int, odd_dim: int, edge_dim: int, layers: int = 2,
                 hidden: int = 64, avg_num_neighbors: float = 8.0):
        super().__init__()
        norm = 1.0 / float(avg_num_neighbors) ** 0.5
        self.layers = nn.ModuleList(_TRLayer(even_dim, odd_dim, edge_dim, hidden, norm) for _ in range(layers))

    def forward(self, x: TRFeatures, edge_index: torch.Tensor, edge_feat: torch.Tensor) -> TRFeatures:
        for layer in self.layers:
            x = layer(x, edge_index, edge_feat)
        return x


class TRReadout(nn.Module):
    """T+ outputs from even features (any MLP) and T- outputs from odd ones (gated, no bias).

    ``forward`` returns ``(even_out (N, n_even), odd_out (N, n_odd))``.
    """

    def __init__(self, even_dim: int, odd_dim: int, n_even: int = 1, n_odd: int = 0,
                 hidden: int = 64, depth: int = 2, zero_init: bool = True):
        super().__init__()
        self.even = mlp(even_dim, hidden, depth, n_even) if n_even else None
        self.odd = OddLinear(odd_dim, n_odd) if n_odd else None
        self.odd_gate = nn.Linear(even_dim, n_odd) if n_odd else None
        if zero_init and self.even is not None:
            zero_init_readout(self.even)

    def forward(self, x: TRFeatures):
        e = self.even(x.even) if self.even is not None else None
        o = odd_gate(odd_lin(self.odd, x.odd), torch.sigmoid(self.odd_gate(x.even))) if self.odd is not None else None
        return e, o


def check_time_reversal(fn, odd_inputs: torch.Tensor, atol: float = 1e-10):
    """Evaluate ``fn(odd_inputs)`` and ``fn(-odd_inputs)``; ``fn`` returns ``(even, odd)`` tensors
    (either may be ``None``). Raises if the even part changes or the odd part does not flip."""
    e1, o1 = fn(odd_inputs)
    e2, o2 = fn(-odd_inputs)
    if e1 is not None and not torch.allclose(e1, e2, atol=atol):
        raise AssertionError(f"T+ output changed under time reversal: {float((e1 - e2).abs().max()):.3e}")
    if o1 is not None and not torch.allclose(o1, -o2, atol=atol):
        raise AssertionError(f"T- output did not flip: {float((o1 + o2).abs().max()):.3e}")
    return e1, o1
