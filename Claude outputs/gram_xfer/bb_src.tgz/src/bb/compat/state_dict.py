"""Loading pre-bb checkpoints into bb modules.

Most ported modules keep their parameter names, so an old state dict loads as-is. Where a module
was replaced by a generic one with different names (e.g. a named head by
:class:`bb.heads.IrrepsReadout`), a project describes the renaming once::

    RULES = [("base_mlp.", "mlp."), ("equiv_reduce_env", "reduce_env.2e"), ("equiv_reduce", "reduce.2e")]
    state = remap_state_dict(old_state, RULES)

and installs it as a load hook so ``model.load_state_dict(old_checkpoint)`` just works::

    register_legacy_keys(head, RULES)
"""

from __future__ import annotations

from typing import Callable, Iterable, Mapping, Sequence

import torch
import torch.nn as nn

__all__ = [
    "remap_state_dict",
    "register_legacy_keys",
    "upgrade_state_dict",
    "load_state_dict_lenient",
    "CUE_REBUILT_KEYS",
]

#: Substrings of state-dict keys that cuequivariance rebuilds at construction and that are safe
#: to be missing from (or absent in) a checkpoint: the fx-graph constants of SymmetricContraction.
CUE_REBUILT_KEYS = (".graphs.",)

Rule = tuple[str, str]


def remap_state_dict(
    state: Mapping[str, torch.Tensor],
    rules: Sequence[Rule],
    *,
    transforms: Mapping[str, Callable[[torch.Tensor], torch.Tensor]] | None = None,
    prefix: str = "",
) -> dict[str, torch.Tensor]:
    """Rename keys by the first matching ``(old_prefix, new_prefix)`` rule (applied after
    ``prefix``); ``transforms[new_key]`` reshapes a value (e.g. a bias ``(S,) -> (S, 1)``)."""
    out: dict[str, torch.Tensor] = {}
    for key, value in state.items():
        new = key
        if key.startswith(prefix):
            rest = key[len(prefix):]
            for old, repl in rules:
                if rest.startswith(old):
                    new = prefix + repl + rest[len(old):]
                    break
        if transforms and new in transforms:
            value = transforms[new](value)
        out[new] = value
    return out


def register_legacy_keys(
    module: nn.Module,
    rules: Sequence[Rule],
    transforms: Mapping[str, Callable[[torch.Tensor], torch.Tensor]] | None = None,
) -> nn.Module:
    """Install a load-state-dict pre-hook on ``module`` that applies ``rules`` to its keys.

    Works when ``module`` is loaded on its own or as a submodule of a larger model (the hook sees
    the full prefix). Keys already in the new form pass through untouched.
    """

    def hook(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
        sub = {k: state_dict.pop(k) for k in [k for k in state_dict if k.startswith(prefix)]}
        local_transforms = {prefix + k: f for k, f in (transforms or {}).items()}
        state_dict.update(remap_state_dict(sub, rules, transforms=local_transforms, prefix=prefix))

    module._register_load_state_dict_pre_hook(hook)
    module._bb_legacy_keys = getattr(module, "_bb_legacy_keys", ()) + ((tuple(rules), dict(transforms or {})),)
    return module


def upgrade_state_dict(model: nn.Module, state: Mapping[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    """Rename a raw state dict's old keys the way ``model.load_state_dict`` would, without loading.

    Applies every rule registered with :func:`register_legacy_keys` anywhere under ``model``.
    For code that matches checkpoint keys against ``model.state_dict()`` by name itself -- a
    warm start that pads, drops or filters entries -- and would otherwise see an old key as
    absent from the model. Keys already in the new form pass through untouched.
    """
    out = dict(state)
    for name, module in model.named_modules():
        for rules, transforms in getattr(module, "_bb_legacy_keys", ()):
            prefix = f"{name}." if name else ""
            sub = {k: out.pop(k) for k in [k for k in out if k.startswith(prefix)]}
            local = {prefix + k: f for k, f in transforms.items()}
            out.update(remap_state_dict(sub, rules, transforms=local, prefix=prefix))
    return out


def load_state_dict_lenient(
    module: nn.Module,
    state: Mapping[str, torch.Tensor],
    *,
    allow_missing: Iterable[str] = CUE_REBUILT_KEYS,
    allow_unexpected: Iterable[str] = CUE_REBUILT_KEYS,
):
    """``load_state_dict(strict=False)`` that still raises on anything not explicitly allowed.

    The default allowances are cuequivariance's rebuilt graph constants. Returns the
    ``IncompatibleKeys`` of the underlying call.
    """
    allow_missing = tuple(allow_missing)
    allow_unexpected = tuple(allow_unexpected)
    res = module.load_state_dict(dict(state), strict=False)
    bad_missing = [k for k in res.missing_keys if not any(s in k for s in allow_missing)]
    bad_unexpected = [k for k in res.unexpected_keys if not any(s in k for s in allow_unexpected)]
    if bad_missing or bad_unexpected:
        raise RuntimeError(
            f"incompatible state dict: missing={bad_missing[:8]} unexpected={bad_unexpected[:8]}"
        )
    return res
