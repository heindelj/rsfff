"""torch / e3nn interoperability shims."""

from __future__ import annotations

import warnings

__all__ = ["enable_e3nn_safe_globals", "suppress_known_torchscript_warnings"]


def enable_e3nn_safe_globals() -> None:
    """Allowlist globals older e3nn releases need under ``torch.load(weights_only=True)``."""
    import torch

    add_safe_globals = getattr(torch.serialization, "add_safe_globals", None)
    if add_safe_globals is not None:
        add_safe_globals([slice])


def suppress_known_torchscript_warnings() -> None:
    """Hide the benign TorchScript warning e3nn's scripted helper modules emit repeatedly on
    newer PyTorch (instance-level annotations on empty non-base types)."""
    warnings.filterwarnings(
        "ignore",
        message=(
            r"The TorchScript type system doesn't support instance-level "
            r"annotations on empty non-base types in `__init__`\..*"
        ),
        category=UserWarning,
    )
