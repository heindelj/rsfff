"""Coupling caller-supplied equivariant inputs (fields, polarizations, multipoles, spins)."""

from .coupling import IrrepCoupling, couple, coupling_tensor, self_couple

__all__ = ["IrrepCoupling", "couple", "coupling_tensor", "self_couple"]
