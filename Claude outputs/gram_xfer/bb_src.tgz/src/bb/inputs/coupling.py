"""Coupling external equivariant inputs to the features.

bb modules take plain tensors, so anything a model wants to condition on -- an applied electric
field, a cavity polarization vector, a fragment's multipoles, a spin direction -- arrives from the
caller. Invariant inputs need nothing special: concatenate them onto the scalars a readout or
message-passing layer already reads (``scalar_dim`` / ``emb_dim``), or use them as a FiLM
conditioning vector (:class:`bb.nn.ConditionedTrunk`). Equivariant inputs must be coupled; this
module does that with Clebsch-Gordan contractions, so the result is exactly equivariant whatever
the input is.

Three operations cover what the source repos did by hand:

* :func:`couple` -- ``(x (x) y)_{l_out}`` for a per-channel feature block ``x`` and an external
  irrep ``y`` (per atom, broadcast over channels). pf's ``(vec (x) lambda)_2e`` is
  ``couple(vec_k, lam, 2)``; its ``vec . lambda`` is ``sqrt(3) * couple(vec_k, lam, 0)``.
* :func:`self_couple` -- ``(y (x) y)_{l_out}``: ``|lambda|^2`` and the ``2e`` part of
  ``lambda (x) lambda``.
* :class:`IrrepCoupling` -- a module: learned channel reduction of a feature block, then
  :func:`couple` with an external input into any set of output irreps, ready to be concatenated
  onto the features (``IrrepFeatures.cat``) or fed to a readout.

Normalization. ``normalization="unit"`` (default) scales the unit-Frobenius CG tensor by
``sqrt(2 l_out + 1)``, which makes the coupling an isometry from the product space onto each
output irrep (every output component is a unit-norm contraction). For two vectors,
``couple(x, y, 2)`` is then exactly the ``2e`` coefficients of the symmetric traceless part of
``x (x) y`` in the :func:`bb.o3.irrep6_to_voigt` basis, and ``couple(x, y, 0)`` is
``x . y / sqrt(3)`` (in general ``x . y / sqrt(2l+1)``). ``"cg"`` uses the raw CG tensor.

Parity. The output irrep of coupling ``x`` (parity ``p_x``) with ``y`` (``p_y``) has parity
``p_x p_y``: a polar field ``1o`` coupled to ``1o`` features gives ``0e + 2e``; a pseudovector
``1e`` (a magnetic field, a spin) coupled to ``1o`` features gives ``0o + 1o + 2o`` -- a
pseudoscalar, not an invariant. :class:`IrrepCoupling` tracks this.

Basis. Inputs must be in the backend's real-spherical-harmonic basis: a ``1o`` block is
Cartesian ``(x, y, z)``; a symmetric rank-2 tensor converts with :func:`bb.o3.voigt_to_irreps`.
A project-specific spherical convention (e.g. ``q20, q21c, ...``) must be converted first.
"""

from __future__ import annotations

import math
from typing import Sequence

import torch
import torch.nn as nn

from ..o3.backend import resolve_backend
from ..o3.irreps import Irrep, IrrepFeatures, IrrepLike

__all__ = ["couple", "self_couple", "coupling_tensor", "IrrepCoupling"]

_CACHE: dict[tuple, torch.Tensor] = {}


def coupling_tensor(l1: int, l2: int, l_out: int, *, normalization: str = "unit", backend=None) -> torch.Tensor:
    """``(2l1+1, 2l2+1, 2l_out+1)`` coupling tensor, float64."""
    if not abs(l1 - l2) <= l_out <= l1 + l2:
        raise ValueError(f"l_out={l_out} cannot couple from {l1} (x) {l2}")
    key = (l1, l2, l_out, normalization, None if backend is None else getattr(backend, "name", backend))
    t = _CACHE.get(key)
    if t is None:
        b = resolve_backend(backend)
        prev = torch.get_default_dtype()
        try:
            torch.set_default_dtype(torch.float64)
            t = b.wigner_3j(l1, l2, l_out).to(torch.float64)
        finally:
            torch.set_default_dtype(prev)
        if normalization == "unit":
            t = t * math.sqrt(2 * l_out + 1)
        elif normalization != "cg":
            raise ValueError(f"normalization must be 'unit' or 'cg', got {normalization!r}")
        _CACHE[key] = t
    return t


def couple(
    x: torch.Tensor,
    y: torch.Tensor,
    l_out: int,
    *,
    normalization: str = "unit",
    backend=None,
) -> torch.Tensor:
    """``(x (x) y)_{l_out}`` per channel.

    ``x``: ``(N, 2l1+1, K)`` feature channels; ``y``: ``(N, 2l2+1)`` one external irrep per atom
    (broadcast over channels) or ``(N, 2l2+1, K)`` channel-wise. Returns ``(N, 2l_out+1, K)``.
    """
    l1 = (x.shape[1] - 1) // 2
    l2 = (y.shape[1] - 1) // 2
    C = coupling_tensor(l1, l2, l_out, normalization=normalization, backend=backend).to(device=x.device, dtype=x.dtype)
    if y.dim() == 2:
        return torch.einsum("abo,nak,nb->nok", C, x, y)
    return torch.einsum("abo,nak,nbk->nok", C, x, y)


def self_couple(y: torch.Tensor, l_out: int, *, normalization: str = "unit", backend=None) -> torch.Tensor:
    """``(y (x) y)_{l_out}`` of a per-atom irrep ``(N, 2l+1)`` -> ``(N, 2l_out+1)``."""
    return couple(y.unsqueeze(-1), y, l_out, normalization=normalization, backend=backend)[..., 0]


class IrrepCoupling(nn.Module):
    """Couple a feature block to an external irrep, after a learned channel reduction.

    ``out = (features[ir_features] @ W) (x) external`` for each requested output degree, with
    ``W`` a ``(P, K)`` channel reduction (``m`` untouched). The outputs are new feature blocks of
    ``K`` channels each, keyed by their irreps (parity ``p_features * p_external``).

    Example -- condition on a cavity polarization ``lam`` (``1o``) through the ``1o`` features::

        cpl = IrrepCoupling("1o", "1o", out_l=(0, 2), in_width=feats.widths["1o"], channels=8)
        extra = cpl(feats, lam)              # {0e: (N, 1, 8), 2e: (N, 5, 8)}
        feats = feats.cat(extra)             # wider 0e and 2e blocks for the readouts
    """

    def __init__(
        self,
        ir_features: IrrepLike,
        ir_external: IrrepLike,
        *,
        out_l: Sequence[int],
        in_width: int,
        channels: int,
        normalization: str = "unit",
        backend=None,
    ) -> None:
        super().__init__()
        self.ir_features = Irrep.parse(ir_features)
        self.ir_external = Irrep.parse(ir_external)
        self.normalization = normalization
        self.out_irreps = []
        for l in out_l:
            if not abs(self.ir_features.l - self.ir_external.l) <= l <= self.ir_features.l + self.ir_external.l:
                raise ValueError(f"cannot couple {self.ir_features} (x) {self.ir_external} to l={l}")
            self.out_irreps.append(Irrep(int(l), self.ir_features.p * self.ir_external.p))
        self.reduce = nn.Parameter(torch.randn(int(in_width), int(channels)) / math.sqrt(int(in_width)))
        for ir in self.out_irreps:
            self.register_buffer(
                f"_cg_{ir.l}",
                coupling_tensor(self.ir_features.l, self.ir_external.l, ir.l,
                                normalization=normalization, backend=backend).to(torch.get_default_dtype()),
                persistent=False,
            )

    def forward(self, features: "IrrepFeatures | torch.Tensor", external: torch.Tensor) -> dict[Irrep, torch.Tensor]:
        x = features[self.ir_features] if isinstance(features, IrrepFeatures) else features
        xk = torch.einsum("nmp,pk->nmk", x, self.reduce)
        out = {}
        for ir in self.out_irreps:
            C = getattr(self, f"_cg_{ir.l}").to(device=xk.device, dtype=xk.dtype)
            if external.dim() == 2:
                out[ir] = torch.einsum("abo,nak,nb->nok", C, xk, external)
            else:
                out[ir] = torch.einsum("abo,nak,nbk->nok", C, xk, external)
        return out
