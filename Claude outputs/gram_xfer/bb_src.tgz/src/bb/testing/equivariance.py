"""Equivariance checks for anything built from bb (or not).

``assert_equivariant`` rotates (and optionally inverts and translates) the positions *and* every
equivariant input together, runs the function on both, and compares the transformed output of
the original with the output of the transformed input::

    def model(pos, field):
        feats = featurizer(positions=pos, atomic_numbers=z, batch_idx=b)
        return readout(feats.cat(coupling(feats, field)))

    assert_equivariant(model, pos, inputs={"field": (E, "1o")})

Outputs may be an :class:`IrrepFeatures` (irreps known), a ``{irrep: tensor}`` mapping, a
tensor (pass ``out_irreps``), or a tuple/dict of those.
"""

from __future__ import annotations

from typing import Any, Callable, Mapping

import torch

from ..o3.irreps import Irrep, IrrepFeatures

__all__ = ["random_rotation", "wigner_D", "transform", "assert_equivariant"]


def random_rotation(dtype=None, generator: torch.Generator | None = None) -> torch.Tensor:
    """A uniformly random proper rotation ``(3, 3)``."""
    dtype = dtype or torch.get_default_dtype()
    q = torch.randn(4, dtype=torch.float64, generator=generator)
    q = q / q.norm()
    w, x, y, z = q
    R = torch.stack([
        torch.stack([1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)]),
        torch.stack([2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)]),
        torch.stack([2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]),
    ])
    return R.to(dtype)


def wigner_D(ir: "Irrep | str", R: torch.Tensor) -> torch.Tensor:
    """Representation matrix of an O(3) element ``R`` (rotation or rotoinversion) on ``ir``."""
    from e3nn import o3

    ir = Irrep.parse(ir)
    return o3.Irrep(ir.l, ir.p).D_from_matrix(R.to(torch.float64)).to(R.dtype)


def transform(x, ir: "Irrep | str | None", R: torch.Tensor):
    """Apply ``R`` to a block ``(N, 2l+1, ...)`` (``ir=None``: leave unchanged)."""
    if ir is None:
        return x
    ir = Irrep.parse(ir)
    D = wigner_D(ir, R).to(device=x.device, dtype=x.dtype)
    return torch.einsum("ij,nj...->ni...", D, x)


def _apply(out, R, out_irreps):
    if isinstance(out, IrrepFeatures):
        return {str(ir): transform(t, ir, R) for ir, t in out.items()}
    if isinstance(out, torch.Tensor):
        return transform(out, out_irreps, R)
    if isinstance(out, Mapping):
        if out_irreps is not None and isinstance(out_irreps, Mapping):
            return {k: _apply(v, R, out_irreps.get(k)) for k, v in out.items()}
        return {str(k): transform(v, k, R) for k, v in out.items()}
    if isinstance(out, (tuple, list)):
        irs = out_irreps if isinstance(out_irreps, (tuple, list)) else [out_irreps] * len(out)
        return [_apply(o, R, i) for o, i in zip(out, irs)]
    raise TypeError(f"cannot transform output of type {type(out).__name__}")


def _flatten(out) -> list[torch.Tensor]:
    if isinstance(out, IrrepFeatures):
        return [t for _, t in out.items()]
    if isinstance(out, torch.Tensor):
        return [out]
    if isinstance(out, Mapping):
        return [t for v in out.values() for t in _flatten(v)]
    if isinstance(out, (tuple, list)):
        return [t for v in out for t in _flatten(v)]
    raise TypeError(type(out).__name__)


def assert_equivariant(
    fn: Callable[..., Any],
    positions: torch.Tensor,
    inputs: Mapping[str, tuple[torch.Tensor, "Irrep | str | None"]] | None = None,
    *,
    out_irreps=None,
    rotation: torch.Tensor | None = None,
    inversion: bool = True,
    translation: bool = True,
    atol: float = 1e-8,
    rtol: float = 1e-6,
) -> float:
    """Check ``fn(R pos + t, R inputs) == R fn(pos, inputs)``; returns the max abs error.

    ``inputs`` maps keyword names to ``(tensor, irrep)``; ``irrep=None`` marks an invariant or a
    non-geometric input (indices, species) that is passed through unchanged. Per-atom
    equivariant inputs are ``(N, 2l+1)`` or ``(N, 2l+1, C)``.
    """
    inputs = dict(inputs or {})
    R = random_rotation(positions.dtype) if rotation is None else rotation.to(positions.dtype)
    elements = [R]
    if inversion:
        elements.append(-R)
    t = torch.randn(3, dtype=positions.dtype) * 2.0 if translation else torch.zeros(3, dtype=positions.dtype)

    base = fn(positions, **{k: v for k, (v, _) in inputs.items()})
    worst = 0.0
    for g in elements:
        pos_g = positions @ g.T + t
        kw = {k: transform(v, ir, g) for k, (v, ir) in inputs.items()}
        out_g = fn(pos_g, **kw)
        expected = _apply(base, g, out_irreps)
        for a, b in zip(_flatten(expected), _flatten(out_g)):
            a, b = a.detach(), b.detach()
            err = float((a - b).abs().max()) if a.numel() else 0.0
            scale = float(a.abs().max()) if a.numel() else 0.0
            worst = max(worst, err)
            if err > atol + rtol * scale:
                kind = "rotoinversion" if torch.det(g) < 0 else "rotation"
                raise AssertionError(
                    f"not equivariant under {kind}: max |R f(x) - f(R x)| = {err:.3e} "
                    f"(scale {scale:.3e})"
                )
    return worst
