"""Configs for bb's modules: strict dataclasses with ``build(...)`` and legacy key aliases."""

from .configs import (
    BispectrumConfig,
    Config,
    EdgeBasisConfig,
    EdgeFeaturizerConfig,
    EdgeReadoutConfig,
    FeaturizerConfig,
    MessagePassingConfig,
    ReadoutConfig,
)

__all__ = [
    "BispectrumConfig", "Config", "EdgeBasisConfig", "EdgeFeaturizerConfig", "EdgeReadoutConfig", "FeaturizerConfig",
    "MessagePassingConfig", "ReadoutConfig",
]
