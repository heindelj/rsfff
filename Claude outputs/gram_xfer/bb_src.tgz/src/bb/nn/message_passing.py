"""Equivariant message passing as a residual refinement of per-atom features.

A local featurizer builds every atom's features from its own neighbor density, with no
atom-to-atom communication. :class:`EquivariantMessagePassing` adds that communication without
changing the interface downstream modules see: it projects the features into a compact hidden
space of ``channels`` copies of each hidden irrep, runs a few convolution + gate layers over the
featurizer's neighbor graph, projects back to the feature widths and adds the result
*residually*. The final up-projection is zero-initialized, so at init the module is an exact
no-op and a model with it behaves identically to one without it (a warm start from a
no-message-passing checkpoint is bit-for-bit until the first optimizer step).

Hidden irreps
-------------
Any set of irreps can be refined, chosen with ``hidden_irreps`` (default: every irrep of the
input). A hidden irrep absent from the input starts at zero and is *created* by the messages
(e.g. a ``1o`` block grown from ``0e``/``2e`` features through ``l=1`` harmonics); it is
returned as a new block. The scalar ``0e`` hidden block is always present -- it carries the
gates.

Message structure per layer, for hidden node features ``h = {ir: (N, 2l+1, C)}``:

  1. For every coupling path ``(ir_in, l_sh, ir_out)`` allowed by the triangle rule and parity
     (``p_in * (-1)^l_sh == p_out``), with ``l_sh <= lmax``, the per-edge message is the CG
     contraction of the source node block with the edge spherical harmonics, followed by a
     per-path channel mix (channels only -- ``m`` is never mixed, so this stays equivariant).
  2. A per-edge radial gain -- an MLP over a smooth-cutoff Bessel basis of the edge length, one
     invariant scalar per output channel -- scales each message. The envelope vanishes with its
     first two derivatives at the cutoff, so forces switch off smoothly.
  3. Messages scatter to the center atom, are normalized by ``1/sqrt(avg_num_neighbors)``, and
     are combined with a self-connection. A gate nonlinearity (SiLU on the scalars, sigmoid gates
     multiplying each non-scalar block) keeps the update equivariant.

The normalization is a *fixed* model constant, measured once on the training data
(:func:`bb.graph.average_num_neighbors`) and saved with the model, as in NequIP/MACE.
Normalizing per batch would make every prediction depend on the rest of the batch; per molecule,
the energy would jump whenever an atom crosses the cutoff. A module built without it (only
checkpoints that predate the fix) falls back to the batch average with a warning.

Backend-agnostic by construction: every equivariant operation is an explicit CG contraction
built from the backend's ``wigner_3j`` and ``spherical_harmonics``, which agree between e3nn and
cuequivariance to ~1e-16, so the module gives the same numbers under both.

Conventions kept from the original (pauli_fierz_pinn / hbq_qed) module so its checkpoints load
unchanged: parameter names (``lin_in0``, ``lin_in2``, ``convs.k.path_mix.022``, ``self_0``,
``self_2``, ``lin_out0``, ``lin_out2``, ...), the edge vector ``r_center - r_neighbor`` for the
harmonics, and the default hidden set ``0e + 2e`` when built with ``p0=..., p2=...``.
"""

from __future__ import annotations

import math
import warnings
from typing import Mapping

import torch
import torch.nn as nn

from ..features.radial import bessel_envelope_basis
from ..o3.backend import resolve_backend
from ..o3.irreps import Irrep, IrrepFeatures, IrrepsLike, parse_irreps

__all__ = ["EquivariantMessagePassing", "message_paths"]

_SCALAR = Irrep(0, 1)


def _key(ir: Irrep) -> str:
    """Parameter-name fragment for an irrep: the bare ``l`` for natural parity (the original
    module's names), ``l`` + ``e``/``o`` otherwise."""
    return str(ir.l) if ir.is_natural else str(ir)


def _sorted(irreps) -> list[Irrep]:
    return sorted(irreps, key=lambda ir: (ir.l, 0 if ir.is_natural else 1))


def message_paths(hidden: list[Irrep], lmax: int) -> list[tuple[Irrep, int, Irrep]]:
    """Coupling paths ``(ir_in, l_sh, ir_out)`` between hidden irreps through SH of degree
    ``l_sh <= lmax``. Ordered by input irrep, then output irrep, then ``l_sh``."""
    paths = []
    for ir_in in hidden:
        for ir_out in hidden:
            for l_sh in range(0, int(lmax) + 1):
                if ir_in.p * (-1) ** l_sh != ir_out.p:
                    continue
                if abs(ir_in.l - l_sh) <= ir_out.l <= ir_in.l + l_sh:
                    paths.append((ir_in, l_sh, ir_out))
    return paths


class _CGConvolution(nn.Module):
    """One layer: CG message + radial gain + scatter + self-connection + gate.

    Output channel budget: ``C`` post-SiLU scalars, ``C`` sigmoid gates per non-scalar hidden
    irrep, and ``C`` gated channels of each non-scalar irrep -- the explicit analogue of an
    ``e3nn.nn.Gate`` on a convolution output.
    """

    def __init__(
        self,
        channels: int,
        hidden: list[Irrep],
        paths: list[tuple[Irrep, int, Irrep]],
        cg: dict[tuple[Irrep, int, Irrep], torch.Tensor],
        num_basis: int,
        radial_hidden: int,
    ) -> None:
        super().__init__()
        self.channels = C = int(channels)
        self.hidden = list(hidden)
        self.gated = [ir for ir in self.hidden if ir != _SCALAR]
        self.paths = list(paths)
        n_gated = len(self.gated)
        self._width = {ir: (C + C * n_gated if ir == _SCALAR else C) for ir in self.hidden}
        for p, w in cg.items():
            if p in self.paths:
                self.register_buffer(self._cg_name(p), w, persistent=False)

        # Per-path channel mix into the output budget.
        self.path_mix = nn.ParameterDict()
        for (ir_in, l_sh, ir_out) in self.paths:
            w = torch.randn(C, self._width[ir_out]) / math.sqrt(C * max(len(self.paths), 1))
            self.path_mix[f"{_key(ir_in)}{l_sh}{_key(ir_out)}"] = nn.Parameter(w)

        # Radial gain: one invariant scalar per output channel.
        self.radial_mlp = nn.Sequential(
            nn.Linear(num_basis, radial_hidden), nn.SiLU(),
            nn.Linear(radial_hidden, sum(self._width.values())),
        )

        # Self-connection (per-irrep linear; bias only on the scalars).
        self.self_0 = nn.Linear(C, self._width[_SCALAR])
        for ir in self.gated:
            setattr(self, f"self_{_key(ir)}", nn.Parameter(torch.randn(C, C) / math.sqrt(C)))

    @staticmethod
    def _cg_name(path) -> str:
        ir_in, l_sh, ir_out = path
        return f"_cg_{_key(ir_in)}{l_sh}{_key(ir_out)}"

    def forward(
        self,
        h: dict[Irrep, torch.Tensor],      # {ir: (N, 2l+1, C)}
        src: torch.Tensor,                 # (E,) message source (neighbor)
        dst: torch.Tensor,                 # (E,) message destination (center)
        sh: dict[int, torch.Tensor],       # {l_sh: (E, 2l+1)}
        radial_emb: torch.Tensor,          # (E, num_basis)
        norm: float,
    ) -> dict[Irrep, torch.Tensor]:
        C = self.channels
        h0 = h[_SCALAR][:, 0]                                     # (N, C)
        n = h0.shape[0]

        msg: dict[Irrep, torch.Tensor] = {}
        for path in self.paths:
            ir_in, l_sh, ir_out = path
            cg = getattr(self, self._cg_name(path)).to(device=h0.device, dtype=h0.dtype)
            t = torch.einsum(
                "iso,eic,es->eoc", cg, h[ir_in].index_select(0, src), sh[l_sh]
            )                                                      # (E, 2lo+1, C)
            mixed = torch.einsum(
                "eoc,cd->eod", t, self.path_mix[f"{_key(ir_in)}{l_sh}{_key(ir_out)}"]
            )
            msg[ir_out] = mixed if ir_out not in msg else msg[ir_out] + mixed

        gain = self.radial_mlp(radial_emb)                          # (E, total)
        out: dict[Irrep, torch.Tensor] = {}
        offset = 0
        for ir in self.hidden:
            width = self._width[ir]
            g = gain[:, offset: offset + width]
            offset += width
            agg = h0.new_zeros(n, ir.dim, width)
            if ir in msg:
                agg = agg.index_add_(0, dst, msg[ir] * g.unsqueeze(1)) * norm
            if ir == _SCALAR:
                conv = agg[:, 0] + self.self_0(h0)                  # (N, C + C*n_gated)
            else:
                conv = agg + torch.einsum("nmc,cd->nmd", h[ir], getattr(self, f"self_{_key(ir)}"))
            out[ir] = conv

        conv0 = out[_SCALAR]
        result = {_SCALAR: torch.nn.functional.silu(conv0[:, :C]).unsqueeze(1)}
        for k, ir in enumerate(self.gated):
            gates = conv0[:, C * (k + 1): C * (k + 2)]
            result[ir] = out[ir] * torch.sigmoid(gates).unsqueeze(1)
        return result


class EquivariantMessagePassing(nn.Module):
    """Refine per-atom equivariant features with CG convolutions (residual, no-op at init).

    Parameters
    ----------
    irreps_in      : widths of the input feature blocks, e.g. ``"128x0e + 64x1o + 128x2e"``,
                     ``{"0e": 128, "2e": 128}`` or a featurizer's ``irreps_out``. Must include
                     ``0e``. (``p0=``, ``p2=`` is the original two-block spelling.)
    emb_dim        : width of extra per-atom invariants concatenated onto the scalars on the way
                     in (a species embedding, a charge/spin embedding, an external-field
                     invariant, ...). ``0`` for none.
    cutoff         : radius of the graph the messages run on.
    backend        : ``"e3nn"`` / ``"cue"`` or a backend instance.
    hidden_irreps  : irreps to refine (default: those of ``irreps_in``). Irreps not in the input
                     are created and returned as new blocks of width ``irreps_out`` (default
                     ``channels``).
    layers, channels, lmax, num_basis, radial_hidden : depth, hidden multiplicity, maximum SH
                     degree of the edge harmonics, radial basis size, radial-MLP width.
    avg_num_neighbors : the message normalization constant (see module docstring).
    """

    def __init__(
        self,
        *,
        irreps_in: IrrepsLike | None = None,
        p0: int | None = None,
        p2: int | None = None,
        emb_dim: int = 0,
        cutoff: float,
        backend="e3nn",
        hidden_irreps: IrrepsLike | list | None = None,
        irreps_out: IrrepsLike | None = None,
        layers: int = 2,
        channels: int = 32,
        lmax: int = 2,
        num_basis: int = 8,
        radial_hidden: int = 64,
        avg_num_neighbors: float | None = None,
    ) -> None:
        super().__init__()
        if irreps_in is None:
            if p0 is None or p2 is None:
                raise ValueError("pass irreps_in (or the original p0=, p2=)")
            in_widths = {_SCALAR: int(p0), Irrep(2, 1): int(p2)}
        else:
            in_widths = {}
            for mul, ir in parse_irreps(irreps_in):
                in_widths[ir] = in_widths.get(ir, 0) + int(mul)
        if _SCALAR not in in_widths:
            raise ValueError("message passing needs 0e input features (the gates are scalars)")
        backend = resolve_backend(backend)

        if hidden_irreps is None:
            hidden = list(in_widths)
        else:
            if isinstance(hidden_irreps, (list, tuple)) and hidden_irreps and not isinstance(hidden_irreps[0], (tuple, list)):
                hidden = [Irrep.parse(x) for x in hidden_irreps]
            else:
                hidden = [ir for _, ir in parse_irreps(hidden_irreps)]
        if _SCALAR not in hidden:
            hidden.append(_SCALAR)
        hidden = _sorted(set(hidden))

        out_widths = {ir: in_widths[ir] for ir in hidden if ir in in_widths}
        if irreps_out is not None:
            for mul, ir in parse_irreps(irreps_out):
                out_widths[ir] = int(mul)
        for ir in hidden:
            out_widths.setdefault(ir, int(channels))

        self.avg_num_neighbors = None if avg_num_neighbors is None else float(avg_num_neighbors)
        self._warned_legacy = False
        self.cutoff = float(cutoff)
        self.num_basis = int(num_basis)
        self.lmax = int(lmax)
        self.channels = C = int(channels)
        self.emb_dim = int(emb_dim)
        self.hidden_irreps = hidden
        self.in_widths = dict(in_widths)
        self.out_widths = out_widths
        # the original two-block attributes
        self.p0 = in_widths[_SCALAR]
        self.p2 = in_widths.get(Irrep(2, 1))

        paths = message_paths(hidden, self.lmax)
        cg = {
            p: backend.wigner_3j(p[0].l, p[1], p[2].l).to(torch.get_default_dtype())
            for p in paths
        }
        self._sh_ls = sorted({l_sh for (_, l_sh, _) in paths})
        self._backend = backend  # only spherical_harmonics is used at runtime

        # Inputs (+ extra scalars) -> hidden widths.
        self.lin_in0 = nn.Linear(in_widths[_SCALAR] + self.emb_dim, C)
        for ir in hidden:
            if ir != _SCALAR and ir in in_widths:
                p = in_widths[ir]
                setattr(self, f"lin_in{_key(ir)}", nn.Parameter(torch.randn(p, C) / math.sqrt(p)))

        self.convs = nn.ModuleList(
            _CGConvolution(C, hidden, paths, cg, self.num_basis, int(radial_hidden))
            for _ in range(int(layers))
        )

        # Zero-init the up-projection so the refiner starts as an exact no-op.
        self.lin_out0 = nn.Linear(C, out_widths[_SCALAR])
        with torch.no_grad():
            self.lin_out0.weight.zero_()
            self.lin_out0.bias.zero_()
        for ir in hidden:
            if ir != _SCALAR:
                setattr(self, f"lin_out{_key(ir)}", nn.Parameter(torch.zeros(C, out_widths[ir])))

    def extra_repr(self) -> str:
        hid = " + ".join(f"{self.channels}x{ir}" for ir in self.hidden_irreps)
        return (
            f"hidden={hid}, layers={len(self.convs)}, lmax={self.lmax}, cutoff={self.cutoff}, "
            f"avg_num_neighbors={self.avg_num_neighbors}"
        )

    # ------------------------------------------------------------------ helpers
    def _norm(self, edge_index: torch.Tensor, n: int) -> float:
        if self.avg_num_neighbors is not None:
            avg_deg = self.avg_num_neighbors
        else:
            if not self._warned_legacy:
                warnings.warn(
                    "message passing has no avg_num_neighbors (a checkpoint from before it was "
                    "fixed): normalising by the batch's average degree, so predictions depend on "
                    "batch composition. Retrain (or warm-start) to fix the constant.",
                    RuntimeWarning, stacklevel=3)
                self._warned_legacy = True
            avg_deg = max(edge_index.shape[1] / max(n, 1), 1.0)
        return 1.0 / math.sqrt(avg_deg)

    def refine(
        self,
        blocks: Mapping[Irrep, torch.Tensor],
        positions: torch.Tensor,
        edge_index: torch.Tensor,
        emb: torch.Tensor | None = None,
        edge_offsets: torch.Tensor | None = None,
    ) -> dict[Irrep, torch.Tensor]:
        """``{ir: (N, 2l+1, P_ir)}`` in, residually refined (and created) blocks out.

        ``edge_offsets`` (E, 3): periodic image offset of each edge's row-1 (neighbor) atom."""
        inv = blocks[_SCALAR][:, 0, :]
        n = inv.shape[0]
        x0 = inv if (emb is None or self.emb_dim == 0) else torch.cat((inv, emb), dim=-1)
        h: dict[Irrep, torch.Tensor] = {_SCALAR: self.lin_in0(x0).unsqueeze(1)}
        for ir in self.hidden_irreps:
            if ir == _SCALAR:
                continue
            if ir in blocks and ir in self.in_widths:
                h[ir] = torch.einsum("nmp,pc->nmc", blocks[ir], getattr(self, f"lin_in{_key(ir)}"))
            else:
                h[ir] = inv.new_zeros(n, ir.dim, self.channels)

        # Messages flow neighbor (src) -> center (dst).
        dst, src = edge_index[0], edge_index[1]
        edge_vec = positions.index_select(0, dst) - positions.index_select(0, src)
        if edge_offsets is not None:
            edge_vec = edge_vec - edge_offsets
        sh = {}
        if self._sh_ls:
            sh_all = self._backend.spherical_harmonics(edge_vec, max(self._sh_ls))
            for l_sh in self._sh_ls:
                start = l_sh * l_sh
                sh[l_sh] = sh_all[:, start: start + 2 * l_sh + 1]
        radial_emb = bessel_envelope_basis(edge_vec.norm(dim=-1), self.cutoff, self.num_basis)
        norm = self._norm(edge_index, n)

        for conv in self.convs:
            h = conv(h, src, dst, sh, radial_emb, norm)

        out = dict(blocks)
        d0 = self.lin_out0(h[_SCALAR][:, 0])
        out[_SCALAR] = (inv + d0).unsqueeze(1)
        for ir in self.hidden_irreps:
            if ir == _SCALAR:
                continue
            d = torch.einsum("nmc,cp->nmp", h[ir], getattr(self, f"lin_out{_key(ir)}"))
            out[ir] = blocks[ir] + d if ir in blocks else d
        return out

    def forward(self, feats, positions, edge_index=None, emb=None, *legacy, edge_offsets=None):
        """Two call forms.

        * ``mp(feats, positions, edge_index=None, emb=None)`` with ``feats`` an
          :class:`IrrepFeatures` (``edge_index`` defaults to ``feats.edge_index``) or a
          ``{irrep: block}`` mapping -> refined :class:`IrrepFeatures`.
        * the original ``mp(inv_feats, equiv_feats, positions, edge_index, emb)`` ->
          ``(inv_feats, equiv_feats)``.
        """
        if isinstance(feats, torch.Tensor):
            inv_feats, equiv_feats = feats, positions
            positions, edge_index, emb = edge_index, emb, (legacy[0] if legacy else None)
            out = self.refine(
                {_SCALAR: inv_feats.unsqueeze(1), Irrep(2, 1): equiv_feats}, positions, edge_index, emb
            )
            return out[_SCALAR][:, 0], out[Irrep(2, 1)]
        if isinstance(feats, IrrepFeatures):
            if edge_index is None:
                ei, off = feats.edge_index, feats.edge_offsets if edge_offsets is None else edge_offsets
            else:
                ei, off = edge_index, edge_offsets
            if ei is None:
                raise ValueError("no edge_index: pass one, or features that carry theirs")
            return feats.replace(self.refine(feats.blocks, positions, ei, emb, off))
        blocks = {Irrep.parse(k): v for k, v in feats.items()}
        return IrrepFeatures(self.refine(blocks, positions, edge_index, emb, edge_offsets),
                             edge_index=edge_index, edge_offsets=edge_offsets)
