"""Named parameter slots, and the two-slot linear layer.

A *slot* is a named set of parameters: "the environment sector", "the cavity coupling", ...
Tagging the parameters (rather than arguing about which module reads which input) is what lets a
penalty, a diagnostic or an ablation ("switch the environment off") name exactly the weights it
acts on. The tag rides on the parameter object (``param._<name>_slot = True``) and is not in the
state dict.

:class:`TwoSlotLinear` is the first layer of an MLP whose input is ``[ h | eta | tail ]`` -- a
primary block, a secondary ("environment") block and a tail (e.g. a species embedding) -- with
the secondary weights a separate, tagged, zero-initialized parameter. A fresh model is therefore
bit-identical to one without the secondary input, and a *narrow* input (``h`` and ``tail`` only)
evaluates the model as if the secondary block were zero, without allocating that zero.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from .init import exempt_parameter
from .mlp import mlp

__all__ = [
    "mark_slot",
    "slot_parameters",
    "unslotted_parameters",
    "mark_env_slot",
    "env_parameters",
    "core_parameters",
    "TwoSlotLinear",
    "two_slot_mlp",
    "slot_reduce",
    "env_reduce_parameter",
]


def mark_slot(param: torch.Tensor, name: str = "env", *, exempt: bool = True) -> torch.Tensor:
    """Tag ``param`` as belonging to slot ``name``; by default also exempt it from decay.

    Why exempt: decay on a slot's weights is a second, unnamed prior pulling toward "this input
    does not matter", competing with whatever named penalty governs that slot.
    """
    setattr(param, f"_{name}_slot", True)
    return exempt_parameter(param) if exempt else param


def slot_parameters(module: nn.Module, name: str = "env"):
    """Every ``(name, param)`` of slot ``name`` in ``module``, in ``named_parameters`` order."""
    attr = f"_{name}_slot"
    for pname, p in module.named_parameters():
        if getattr(p, attr, False):
            yield pname, p


def unslotted_parameters(module: nn.Module, name: str = "env"):
    """Every ``(name, param)`` **not** in slot ``name``."""
    attr = f"_{name}_slot"
    for pname, p in module.named_parameters():
        if not getattr(p, attr, False):
            yield pname, p


def mark_env_slot(param: torch.Tensor) -> torch.Tensor:
    """``mark_slot(param, "env")`` -- the rsfff spelling."""
    return mark_slot(param, "env")


def env_parameters(module: nn.Module):
    return slot_parameters(module, "env")


def core_parameters(module: nn.Module):
    return unslotted_parameters(module, "env")


class TwoSlotLinear(nn.Module):
    """``W_frag . h + W_env . eta + W_tail . t + b`` on an input laid out ``[h | eta | t]``.

    ``w_env`` is zero-initialized and tagged with :func:`mark_env_slot`. Handed an input of width
    ``p_frag + p_tail`` (no ``eta``), the layer drops the environment term -- bit-identical to a
    zeroed ``eta``, without allocating it.
    """

    def __init__(
        self,
        p_frag: int,
        p_env: int,
        out_dim: int,
        *,
        p_tail: int = 0,
        bias: bool = True,
    ) -> None:
        super().__init__()
        if p_frag <= 0 or p_env <= 0:
            raise ValueError(
                f"TwoSlotLinear needs both slots, got p_frag={p_frag}, p_env={p_env}; "
                f"for a single-slot layer build nn.Linear (see two_slot_mlp)"
            )
        self.p_frag, self.p_env, self.p_tail = int(p_frag), int(p_env), int(p_tail)
        # nn.Linear's own initialization over the full primary width, then split, so a two-slot
        # and a one-slot model start from the same distribution on the columns they share.
        ref = nn.Linear(self.p_frag + self.p_tail, out_dim, bias=bias)
        w = ref.weight.detach().clone()
        self.w_frag = nn.Parameter(w[:, : self.p_frag].contiguous())
        self.w_tail = (
            nn.Parameter(w[:, self.p_frag :].contiguous()) if self.p_tail else None
        )
        self.bias = nn.Parameter(ref.bias.detach().clone()) if bias else None
        self.w_env = mark_env_slot(nn.Parameter(torch.zeros(out_dim, self.p_env)))

    def weight(self, *, isolated: bool) -> torch.Tensor:
        """``(out, p)`` the assembled weight, with or without the environment columns."""
        blocks = [self.w_frag] if isolated else [self.w_frag, self.w_env]
        if self.w_tail is not None:
            blocks.append(self.w_tail)
        return blocks[0] if len(blocks) == 1 else torch.cat(blocks, dim=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        narrow = self.p_frag + self.p_tail
        if x.shape[-1] == narrow:                            # the isolated evaluation
            return torch.nn.functional.linear(x, self.weight(isolated=True), self.bias)
        if x.shape[-1] != narrow + self.p_env:
            raise ValueError(
                f"TwoSlotLinear got input width {x.shape[-1]}; expected {narrow} (isolated) "
                f"or {narrow + self.p_env} (joined), for p_frag={self.p_frag}, "
                f"p_env={self.p_env}, p_tail={self.p_tail}"
            )
        return torch.nn.functional.linear(x, self.weight(isolated=False), self.bias)

    def extra_repr(self) -> str:
        return (
            f"p_frag={self.p_frag}, p_env={self.p_env}, p_tail={self.p_tail}, "
            f"out={self.w_frag.shape[0]}"
        )


def two_slot_mlp(
    p_frag: int,
    p_env: int,
    hidden: int,
    depth: int,
    out_dim: int,
    *,
    p_tail: int = 0,
) -> nn.Sequential:
    """:func:`bb.nn.mlp` with the two slots split in its **first layer only**.

    ``p_env = 0`` returns exactly ``mlp(p_frag + p_tail, hidden, depth, out_dim)``: the same
    modules, parameter names and state dict.
    """
    if not p_env:
        return mlp(p_frag + p_tail, hidden, depth, out_dim)
    if depth < 1:
        raise ValueError("two_slot_mlp needs depth >= 1 when p_env > 0")
    layers: list[nn.Module] = [
        TwoSlotLinear(p_frag, p_env, hidden, p_tail=p_tail),
        nn.SiLU(),
    ]
    d = hidden
    for _ in range(depth - 1):
        layers += [nn.Linear(d, hidden), nn.SiLU()]
        d = hidden
    layers.append(nn.Linear(d, out_dim))
    return nn.Sequential(*layers)


def slot_reduce(
    frag_weight: torch.Tensor,
    env_weight: torch.Tensor | None,
    n_channels: int,
) -> torch.Tensor:
    """The ``(p, k)`` channel reduction for an equivariant block of width ``n_channels``.

    Under two slots ``p = p_frag + p_env`` and only the environment half is tagged; the block
    width selects the isolated (``p_frag``) or joined form, as in :class:`TwoSlotLinear`.
    """
    if env_weight is None or n_channels == frag_weight.shape[0]:
        return frag_weight
    if n_channels != frag_weight.shape[0] + env_weight.shape[0]:
        raise ValueError(
            f"slot_reduce got a feature block of width {n_channels}; expected "
            f"{frag_weight.shape[0]} (isolated) or "
            f"{frag_weight.shape[0] + env_weight.shape[0]} (joined)"
        )
    return torch.cat((frag_weight, env_weight), dim=0)


def env_reduce_parameter(p_env: int | None, n_channels: int) -> nn.Parameter | None:
    """The zero-initialized, tagged environment half of an equivariant reduction, or ``None``."""
    if not p_env:
        return None
    return mark_env_slot(nn.Parameter(torch.zeros(int(p_env), int(n_channels))))
