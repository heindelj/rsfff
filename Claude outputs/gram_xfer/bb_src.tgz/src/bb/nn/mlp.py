"""The invariant MLP every head and trunk is built from."""

from __future__ import annotations

import torch.nn as nn

__all__ = ["mlp"]


def mlp(in_dim: int, hidden: int, depth: int, out_dim: int, *, act: type[nn.Module] = nn.SiLU) -> nn.Sequential:
    """``depth`` hidden layers of width ``hidden`` with SiLU, then a linear readout.

    ``depth = 0`` is a single linear layer. The module layout (``Linear, SiLU, ..., Linear`` in
    an ``nn.Sequential``) is part of the checkpoint key contract: ``mlp.0.weight``,
    ``mlp.2.weight``, ..., ``mlp.{2*depth}.weight``.
    """
    layers: list[nn.Module] = []
    d = int(in_dim)
    for _ in range(int(depth)):
        layers += [nn.Linear(d, int(hidden)), act()]
        d = int(hidden)
    layers.append(nn.Linear(d, int(out_dim)))
    return nn.Sequential(*layers)
