"""Initialization and weight-decay bookkeeping.

Two failure modes recur in models whose readouts start at zero, and both are handled here so no
caller has to remember them:

1. **Zero readout + weight decay.** With the readout at zero, every layer behind it gets an
   *exactly* zero gradient on the first step; weight decay is then the only force acting on those
   layers and wins uncontested. By the time the readout has grown enough to send a gradient back,
   the hidden layers have been flattened and the block is a constant forever. (Measured in rsfff:
   environment-quenched C6, per-channel compliances and a quadrupole anisotropy all silently
   reverted to constants this way.) :func:`zero_init_readout` therefore always exempts the block
   it zeroes.
2. **Gated equivariant heads deadlock.** A head ``out = reduce(x) . gate(s)`` with a zero-init
   gate has ``d out / d reduce == 0`` at init, so a decaying ``reduce`` goes to zero, which zeroes
   the gate's gradient, which keeps the gate at zero. The fix is to exempt the *whole head*
   (:func:`exempt_from_weight_decay` on the head module), which :class:`bb.heads.IrrepsReadout`
   does for itself.

Exemption is declared at two granularities -- per module (``module.no_weight_decay``) and per
parameter (``param._no_weight_decay``) -- and :func:`parameter_groups` reads both.
"""

from __future__ import annotations

import torch
import torch.nn as nn

__all__ = [
    "exempt_parameter",
    "exempt_from_weight_decay",
    "zero_init_readout",
    "parameter_groups",
]


def exempt_parameter(param: torch.Tensor) -> torch.Tensor:
    """Exempt **one parameter** from weight decay, rather than a whole module.

    The flag rides on the parameter object, which survives ``.to()``, ``.cuda()`` and
    ``load_state_dict`` (all of which write into ``.data`` rather than rebinding), so setting it
    once at construction is enough. It is deliberately *not* in the state dict: it is a property
    of how the model was built.
    """
    param._no_weight_decay = True
    return param


def exempt_from_weight_decay(module: nn.Module) -> nn.Module:
    """Mark ``module`` (and everything in it) so :func:`parameter_groups` gives it no decay."""
    module.no_weight_decay = True
    return module


def zero_init_readout(module: nn.Module, *, bias: bool = True) -> nn.Module:
    """Zero a block's readout **and** exempt the block from weight decay. Both, always.

    ``module`` is an ``nn.Sequential`` (its last layer is zeroed) or a single linear layer.
    ``bias=False`` keeps the readout bias -- for a block whose bias carries its initial value.
    """
    last = module[-1] if isinstance(module, nn.Sequential) else module
    with torch.no_grad():
        last.weight.zero_()
        if bias and last.bias is not None:
            last.bias.zero_()
    return exempt_from_weight_decay(module)


def parameter_groups(model: nn.Module, weight_decay: float) -> list[dict]:
    """Optimizer parameter groups that honor both exemption granularities.

    ``torch.optim.AdamW(parameter_groups(model, 1e-4), lr=...)``. Exempt parameters get
    ``weight_decay=0``; everything else gets ``weight_decay``. Frozen parameters are skipped.
    """
    decayed, exempt = [], []
    seen: set[int] = set()
    for module in model.modules():
        if not getattr(module, "no_weight_decay", False):
            continue
        for p in module.parameters():
            if p.requires_grad and id(p) not in seen:
                seen.add(id(p))
                exempt.append(p)
    for p in model.parameters():
        if not p.requires_grad or id(p) in seen:
            continue
        seen.add(id(p))
        (exempt if getattr(p, "_no_weight_decay", False) else decayed).append(p)
    groups = [{"params": decayed, "weight_decay": float(weight_decay)}]
    if exempt:
        groups.append({"params": exempt, "weight_decay": 0.0})
    return groups
