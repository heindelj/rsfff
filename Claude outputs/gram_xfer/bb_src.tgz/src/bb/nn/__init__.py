"""Neural-network building blocks: MLPs, init/decay bookkeeping, slots, FiLM, message passing."""

from .conditioning import CONDITIONING_MODES, ConditionedTrunk, FiLMGenerator, FiLMLayer
from .init import exempt_from_weight_decay, exempt_parameter, parameter_groups, zero_init_readout
from .message_passing import EquivariantMessagePassing, message_paths
from .mlp import mlp
from .slots import (
    TwoSlotLinear,
    core_parameters,
    env_parameters,
    env_reduce_parameter,
    mark_env_slot,
    mark_slot,
    slot_parameters,
    slot_reduce,
    two_slot_mlp,
    unslotted_parameters,
)

__all__ = [
    "CONDITIONING_MODES", "ConditionedTrunk", "FiLMGenerator", "FiLMLayer",
    "exempt_from_weight_decay", "exempt_parameter", "parameter_groups", "zero_init_readout",
    "EquivariantMessagePassing", "message_paths", "mlp",
    "TwoSlotLinear", "core_parameters", "env_parameters", "env_reduce_parameter",
    "mark_env_slot", "mark_slot", "slot_parameters", "slot_reduce", "two_slot_mlp",
    "unslotted_parameters",
]
