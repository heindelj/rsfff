"""The minimal batch interface bb modules accept, and ragged-batching helpers.

bb never requires a particular batch class. Featurizers accept either explicit tensors or any
object exposing the three fields of :class:`GraphBatch`; everything else a model needs (targets,
fields, fragment labels, cavity vectors, ...) is the project's business and is passed to the
modules that use it as plain tensors.

A batch is *flat*: ``B`` structures concatenated into one graph of ``N = sum_b n_b`` atoms, with
``batch_idx`` giving each atom's structure. Each structure's atoms are contiguous and
``batch_idx`` is non-decreasing.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence, runtime_checkable

import torch

__all__ = [
    "GraphBatch",
    "SimpleBatch",
    "collate_atoms",
    "offset_index",
    "num_systems",
    "scatter_sum",
    "scatter_mean",
    "atom_counts",
]


@runtime_checkable
class GraphBatch(Protocol):
    positions: torch.Tensor        # (N, 3)
    atomic_numbers: torch.Tensor   # (N,) long
    batch_idx: torch.Tensor        # (N,) long, non-decreasing


@dataclass
class SimpleBatch:
    """The smallest concrete :class:`GraphBatch`: positions, atomic numbers, batch index."""

    positions: torch.Tensor
    atomic_numbers: torch.Tensor
    batch_idx: torch.Tensor
    n_systems: int | None = None

    def __post_init__(self) -> None:
        if self.n_systems is None:
            self.n_systems = num_systems(self.batch_idx)

    def to(self, device=None, dtype: torch.dtype | None = None) -> "SimpleBatch":
        """Move to ``device``; ``dtype`` applies to positions only."""
        return SimpleBatch(
            self.positions.to(device=device, dtype=dtype),
            self.atomic_numbers.to(device=device),
            self.batch_idx.to(device=device),
            self.n_systems,
        )


def num_systems(batch_idx: torch.Tensor) -> int:
    return 0 if batch_idx.numel() == 0 else int(batch_idx.max()) + 1


def collate_atoms(
    positions: Sequence[torch.Tensor],
    atomic_numbers: Sequence[torch.Tensor],
) -> SimpleBatch:
    """Concatenate per-structure ``(n_b, 3)`` / ``(n_b,)`` tensors into one flat batch."""
    if len(positions) != len(atomic_numbers):
        raise ValueError("positions and atomic_numbers must have the same number of structures")
    pos = torch.cat([torch.as_tensor(p) for p in positions], dim=0)
    z = torch.cat([torch.as_tensor(a, dtype=torch.long) for a in atomic_numbers], dim=0)
    counts = torch.tensor([len(a) for a in atomic_numbers], dtype=torch.long)
    batch_idx = torch.repeat_interleave(torch.arange(len(counts)), counts).to(pos.device)
    return SimpleBatch(pos, z.to(pos.device), batch_idx, len(counts))


def offset_index(indices: Sequence[torch.Tensor], sizes: Sequence[int]) -> torch.Tensor:
    """Concatenate per-structure index tensors, shifting each by the running total of ``sizes``.

    For anything that indexes atoms (an edge list, a fragment id per atom remapped to be
    batch-global, a bond list): ``offset_index([bonds_0, bonds_1], [n_atoms_0, n_atoms_1])``.
    """
    out, offset = [], 0
    for idx, size in zip(indices, sizes):
        out.append(torch.as_tensor(idx) + offset)
        offset += int(size)
    return torch.cat(out, dim=-1) if out else torch.empty(0, dtype=torch.long)


def atom_counts(batch_idx: torch.Tensor, n_systems: int | None = None) -> torch.Tensor:
    n = num_systems(batch_idx) if n_systems is None else int(n_systems)
    return torch.bincount(batch_idx, minlength=n)


def scatter_sum(values: torch.Tensor, batch_idx: torch.Tensor, n_systems: int | None = None) -> torch.Tensor:
    """Per-structure sums of per-atom rows: ``(N, ...) -> (B, ...)``."""
    n = num_systems(batch_idx) if n_systems is None else int(n_systems)
    out = values.new_zeros((n, *values.shape[1:]))
    return out.index_add_(0, batch_idx, values)


def scatter_mean(values: torch.Tensor, batch_idx: torch.Tensor, n_systems: int | None = None) -> torch.Tensor:
    """Per-structure means of per-atom rows: ``(N, ...) -> (B, ...)``."""
    n = num_systems(batch_idx) if n_systems is None else int(n_systems)
    total = scatter_sum(values, batch_idx, n)
    counts = values.new_zeros(n).index_add_(0, batch_idx, values.new_ones(values.shape[0]))
    return total / counts.clamp_min(1.0).reshape(-1, *([1] * (values.dim() - 1)))
