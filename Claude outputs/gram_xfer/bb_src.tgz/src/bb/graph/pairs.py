"""Pair graphs with environments: the topology for an edge cluster expansion on arbitrary pairs.

A :class:`~bb.graph.bonded.BondGraph` describes a fixed covalent topology: the environment of a
bond is its bonded neighbours. Here the pairs come from a distance cutoff (e.g. all pairs of
magnetic ions within 6.5 A, through :func:`bb.graph.site_pair_graph`) and the environment of each
end is every atom within a second, shorter cutoff (an ordinary radius graph). Both may be
periodic.

The layout matches :class:`BondGraph`, so :class:`bb.heads.EdgeScalarReadout` and friends work
unchanged: edges ``0 .. B-1`` are one canonical direction of each undirected pair and edge
``e + B`` is its reverse. For a pair ``e = (i -> j, shift s)``

* ``near`` lists ``(e, m)`` for every environment edge ``m`` centred on ``i``, except the one that
  is ``e`` itself (neighbour ``j`` at shift ``s``);
* ``far`` lists ``(e, m)`` for every environment edge centred on ``j``, except the one pointing
  back at ``i`` (neighbour ``i`` at shift ``-s``).

Environment vectors are translation invariant, so the environment of the image of ``j`` is the
environment of ``j``.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch

from .periodic import PeriodicEdges

__all__ = ["PairGraph", "pair_graph"]


@dataclass
class PairGraph:
    edge_index: torch.Tensor  # (2, E) directed pairs, E = 2 B
    shifts: torch.Tensor      # (E, 3) long, image of the row-1 atom
    offsets: torch.Tensor     # (E, 3) Cartesian
    rev: torch.Tensor         # (E,)
    bond_id: torch.Tensor     # (E,)
    bonds: torch.Tensor       # (B, 2) canonical direction
    near: torch.Tensor        # (2, P) (pair edge, env edge)
    far: torch.Tensor         # (2, Q)
    env: PeriodicEdges
    n_atoms: int

    @property
    def n_bonds(self) -> int:
        return int(self.bonds.shape[0])

    @property
    def n_edges(self) -> int:
        return int(self.edge_index.shape[1])

    def vectors(self, positions: torch.Tensor) -> torch.Tensor:
        a, b = self.edge_index
        return positions[b] + self.offsets - positions[a]


def _keys(a, b, s, n_atoms, span):
    base = 2 * span + 1
    s = s + span
    return (((a * n_atoms + b) * base + s[:, 0]) * base + s[:, 1]) * base + s[:, 2]


def _gather_by_center(centers: torch.Tensor, env_center: torch.Tensor, n_atoms: int):
    """All (q, m) with env_center[m] == centers[q]."""
    order = torch.argsort(env_center, stable=True)
    counts = torch.bincount(env_center, minlength=n_atoms)
    starts = torch.cumsum(counts, 0) - counts
    per = counts[centers]
    q = torch.repeat_interleave(torch.arange(len(centers), device=centers.device), per)
    first = torch.repeat_interleave(starts[centers], per)
    within = torch.arange(len(q), device=centers.device) - torch.repeat_interleave(torch.cumsum(per, 0) - per, per)
    return q, order[first + within]


def pair_graph(pairs: PeriodicEdges, env: PeriodicEdges, n_atoms: int) -> PairGraph:
    """Reorder a symmetric directed pair list into the canonical layout and attach environments.

    ``pairs`` must contain the reverse ``(j, i, -s)`` of every edge ``(i, j, s)`` (a radius graph
    does, unless the neighbour cap truncated it, which raises here).
    """
    a, b = pairs.edge_index
    s = pairs.shifts
    device = a.device
    if a.numel() == 0:
        z = torch.zeros(0, dtype=torch.long, device=device)
        z2 = torch.zeros(2, 0, dtype=torch.long, device=device)
        return PairGraph(z2, s, pairs.offsets, z, z, z.reshape(0, 2), z2, z2, env, n_atoms)
    span = int(s.abs().max()) + 1 if s.numel() else 1
    lex_pos = (s[:, 0] > 0) | ((s[:, 0] == 0) & (s[:, 1] > 0)) | ((s[:, 0] == 0) & (s[:, 1] == 0) & (s[:, 2] > 0))
    canon = (a < b) | ((a == b) & lex_pos)
    key = _keys(a, b, s, n_atoms, span)
    rkey = _keys(b, a, -s, n_atoms, span)
    order = torch.argsort(key)
    pos_rev = torch.searchsorted(key[order], rkey).clamp(max=len(key) - 1)
    rev_old = order[pos_rev]
    if not bool((key[rev_old] == rkey).all()):
        raise ValueError("pair_graph: the pair list is not symmetric (a truncated neighbour list?)")
    c_idx = canon.nonzero(as_tuple=True)[0]
    new_order = torch.cat([c_idx, rev_old[c_idx]])
    nb = len(c_idx)
    ei = torch.stack([a[new_order], b[new_order]])
    sh = s[new_order]
    off = pairs.offsets[new_order]
    rev = torch.cat([torch.arange(nb, 2 * nb, device=device), torch.arange(nb, device=device)])
    bond_id = torch.cat([torch.arange(nb, device=device), torch.arange(nb, device=device)])
    bonds = ei[:, :nb].T.contiguous()

    ea, eb = env.edge_index
    # near: env edges centred on i, minus the one that coincides with the pair edge
    q, m = _gather_by_center(ei[0], ea, n_atoms)
    same = (eb[m] == ei[1][q]) & (env.shifts[m] == sh[q]).all(-1)
    near = torch.stack([q[~same], m[~same]])
    # far: env edges centred on j, minus the one pointing back at i
    q, m = _gather_by_center(ei[1], ea, n_atoms)
    back = (eb[m] == ei[0][q]) & (env.shifts[m] == -sh[q]).all(-1)
    far = torch.stack([q[~back], m[~back]])
    return PairGraph(ei, sh, off, rev, bond_id, bonds, near, far, env, n_atoms)
