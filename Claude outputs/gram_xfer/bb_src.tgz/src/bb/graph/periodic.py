"""Periodic neighbor lists.

Edge convention (shared with :func:`bb.graph.build_radius_graph`): edges are directed, both
``(a, b)`` and ``(b, a)`` are present, row 1 is the query atom whose degree the cap bounds. Each
edge also carries an integer image ``shift`` ``(3,)`` and its Cartesian ``offset = shift @ cell``,
both attached to the *row-1* atom: the neighbor of ``a`` along edge ``(a, b, s)`` is the image
of ``b`` at ``positions[b] + offset``, so

    vec(a -> b) = positions[b] + offset - positions[a]

and the reverse edge is ``(b, a, -s)``. Consumers that point the other way (message passing
uses ``center - neighbor``) apply the offset to the same row and keep their own sign.

Self-image edges (``a == b``, ``s != 0``) are kept: in a cell smaller than twice the cutoff an
atom is its own neighbor, and dropping those pairs would make the energy depend on the choice of
supercell.

The search is brute force over the images that can reach the cutoff (``O(N^2 n_images)`` per
frame, chunked over images). That is the right trade for the few-hundred-atom DFT cells this is
written for; a cell list wins for large boxes.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch

from .neighbors import DEFAULT_MAX_NUM_NEIGHBORS, _check_cap

__all__ = ["PeriodicEdges", "build_periodic_graph", "edge_offsets", "site_pair_graph"]


@dataclass
class PeriodicEdges:
    """A periodic graph. ``offsets`` is differentiable in ``cell`` (for stress)."""

    edge_index: torch.Tensor  # (2, E) long
    shifts: torch.Tensor      # (E, 3) long, image of the row-1 atom
    offsets: torch.Tensor     # (E, 3) Cartesian, shifts @ cell[frame]

    @property
    def n_edges(self) -> int:
        return int(self.edge_index.shape[1])

    def vectors(self, positions: torch.Tensor) -> torch.Tensor:
        """``positions[b] + offset - positions[a]`` per edge ``(a, b)``: ``(E, 3)``."""
        a, b = self.edge_index
        return positions[b] + self.offsets - positions[a]

    def to(self, device) -> "PeriodicEdges":
        return PeriodicEdges(self.edge_index.to(device), self.shifts.to(device), self.offsets.to(device))


def edge_offsets(shifts: torch.Tensor, cell: torch.Tensor, frame: torch.Tensor) -> torch.Tensor:
    """Cartesian offsets ``shift @ cell[frame]`` for integer ``shifts`` (E, 3), ``cell`` (B, 3, 3)
    (rows are lattice vectors) and the frame of each edge ``frame`` (E,)."""
    return torch.einsum("ek,ekc->ec", shifts.to(cell.dtype), cell[frame])


def _image_range(cell: torch.Tensor, pbc: torch.Tensor, frac: torch.Tensor, r: float) -> list[int]:
    """Images needed per lattice direction so that every pair within ``r`` is found, also for
    atoms that are not wrapped into the cell (the spread of fractional coordinates is added)."""
    vol = torch.linalg.det(cell).abs()
    out = []
    for k in range(3):
        if not bool(pbc[k]):
            out.append(0)
            continue
        i, j = [x for x in range(3) if x != k]
        height = vol / torch.linalg.cross(cell[i], cell[j]).norm()
        span = float(frac[:, k].max() - frac[:, k].min()) if frac.shape[0] else 0.0
        out.append(int(math.ceil(r / float(height) + span)))
    return out


def _frame_edges(pos, cell, pbc, r, loop, image_chunk):
    n = pos.shape[0]
    device, dtype = pos.device, pos.dtype
    frac = torch.linalg.solve(cell.T, pos.T).T if n else pos
    nk = _image_range(cell.detach(), pbc, frac.detach(), r)
    grids = [torch.arange(-m, m + 1, device=device) for m in nk]
    shifts = torch.cartesian_prod(*grids).reshape(-1, 3)                      # (S, 3)
    offs = shifts.to(dtype) @ cell                                             # (S, 3)
    src, dst, sh = [], [], []
    for s0 in range(0, shifts.shape[0], image_chunk):
        so = offs[s0:s0 + image_chunk]
        ss = shifts[s0:s0 + image_chunk]
        # d[s, a, b] = (pos[b] - pos[a]) + off[s]: in this order the reverse edge (b, a, -s) is the exact
        # negation, so a pair at the cutoff is kept both ways or neither (pos[b] + off - pos[a] rounds
        # differently in the two directions, and pair_graph rejects the one-sided pair)
        d = (pos[None, None, :, :] - pos[None, :, None, :]) + so[:, None, None, :]
        dist = (d * d).sum(-1).detach().sqrt()
        near = dist < r
        if not loop:
            zero = (ss == 0).all(-1)
            if bool(zero.any()):
                eye = torch.eye(n, dtype=torch.bool, device=device)
                near[zero] &= ~eye
        s_idx, a, b = near.nonzero(as_tuple=True)
        src.append(a)
        dst.append(b)
        sh.append(ss[s_idx])
    if not src:
        z = torch.zeros(0, dtype=torch.long, device=device)
        return z, z, torch.zeros(0, 3, dtype=torch.long, device=device)
    return torch.cat(src), torch.cat(dst), torch.cat(sh)


def _keep_nearest(a, b, vec, n_atoms, cap):
    """Keep at most ``cap`` nearest neighbors per query (row-1) atom."""
    dist = vec.norm(dim=-1).detach()
    order = torch.argsort(dist)
    b_sorted = b[order]
    rank = torch.zeros_like(b_sorted)
    # rank of each edge among its query atom's edges, by distance
    perm = torch.argsort(b_sorted, stable=True)
    counts = torch.bincount(b_sorted, minlength=n_atoms)
    starts = torch.cumsum(counts, 0) - counts
    rank[perm] = torch.arange(len(b_sorted), device=b.device) - starts[b_sorted[perm]]
    keep = torch.zeros_like(b, dtype=torch.bool)
    keep[order] = rank < cap
    return keep


def build_periodic_graph(
    positions: torch.Tensor,            # (N, 3) Cartesian
    r: float,
    cell: torch.Tensor,                 # (B, 3, 3) or (3, 3), rows are lattice vectors
    pbc: torch.Tensor | None = None,    # (B, 3) or (3,) bool; default all periodic
    batch: torch.Tensor | None = None,  # (N,) non-decreasing frame index
    *,
    context: str,
    loop: bool = False,
    max_num_neighbors: int = DEFAULT_MAX_NUM_NEIGHBORS,
    image_chunk: int = 32,
) -> PeriodicEdges:
    """Directed radius graph under periodic boundary conditions (see the module docstring).

    Non-periodic directions (``pbc[k] = False``) get no images, so a cluster in a big box with
    ``pbc = False`` reproduces :func:`bb.graph.build_radius_graph` (as a set of edges). The cap
    keeps the nearest ``max_num_neighbors`` per query atom and is reported exactly as
    :func:`bb.graph.build_radius_graph` reports it.
    """
    n_atoms = positions.shape[0]
    device = positions.device
    if batch is None:
        batch = torch.zeros(n_atoms, dtype=torch.long, device=device)
    cell = cell.reshape(-1, 3, 3).to(positions.dtype)
    n_frames = cell.shape[0]
    if pbc is None:
        pbc = torch.ones(n_frames, 3, dtype=torch.bool, device=device)
    pbc = torch.as_tensor(pbc, device=device).reshape(-1, 3).expand(n_frames, 3)
    counts = torch.bincount(batch, minlength=n_frames)
    if counts.numel() != n_frames:
        raise ValueError(f"{n_frames} cells for {counts.numel()} frames")
    bounds = torch.cat([counts.new_zeros(1), counts.cumsum(0)]).tolist()

    src, dst, sh, fr = [], [], [], []
    for f in range(n_frames):
        lo, hi = bounds[f], bounds[f + 1]
        if hi == lo:
            continue
        a, b, s = _frame_edges(positions[lo:hi], cell[f], pbc[f], r, loop, image_chunk)
        src.append(a + lo)
        dst.append(b + lo)
        sh.append(s)
        fr.append(torch.full_like(a, f))
    if src:
        a, b, s, frame = torch.cat(src), torch.cat(dst), torch.cat(sh), torch.cat(fr)
    else:
        a = b = frame = torch.zeros(0, dtype=torch.long, device=device)
        s = torch.zeros(0, 3, dtype=torch.long, device=device)
    off = edge_offsets(s, cell, frame)
    cap = int(max_num_neighbors)
    if a.numel():
        degree = torch.bincount(b, minlength=n_atoms)
        if int(degree.max()) > cap:
            vec = positions[b] + off - positions[a]
            keep = _keep_nearest(a, b, vec, n_atoms, cap)
            a, b, s, off = a[keep], b[keep], s[keep], off[keep]
    edge = torch.stack([a, b])
    from . import neighbors as _nb

    if _nb._CHECK:
        _check_cap(edge, n_atoms, r, cap, context)
    return PeriodicEdges(edge, s, off)


def site_pair_graph(
    positions: torch.Tensor,
    r: float,
    site_mask: torch.Tensor,            # (N,) bool: which atoms are sites
    cell: torch.Tensor | None = None,
    pbc: torch.Tensor | None = None,
    batch: torch.Tensor | None = None,
    *,
    context: str = "site_pair_graph",
    max_num_neighbors: int = DEFAULT_MAX_NUM_NEIGHBORS,
) -> PeriodicEdges:
    """Directed pairs of *sites* within ``r`` (with images), in global atom indices.

    Which atoms are sites is the caller's business (magnetic ions, say). Without a ``cell`` the
    graph is non-periodic (zero shifts).
    """
    n_atoms = positions.shape[0]
    device = positions.device
    if batch is None:
        batch = torch.zeros(n_atoms, dtype=torch.long, device=device)
    idx = site_mask.nonzero(as_tuple=True)[0]
    sub_pos, sub_batch = positions[idx], batch[idx]
    if cell is None:
        n_frames = int(batch.max()) + 1 if n_atoms else 1
        big = torch.eye(3, dtype=positions.dtype, device=device).expand(n_frames, 3, 3) * 1.0
        pe = build_periodic_graph(sub_pos, r, big, torch.zeros(n_frames, 3, dtype=torch.bool, device=device),
                                  sub_batch, context=context, max_num_neighbors=max_num_neighbors)
    else:
        pe = build_periodic_graph(sub_pos, r, cell, pbc, sub_batch, context=context,
                                  max_num_neighbors=max_num_neighbors)
    return PeriodicEdges(idx[pe.edge_index], pe.shifts, pe.offsets)
