"""Graph statistics that become model constants (e.g. message-passing normalization)."""

from __future__ import annotations

from typing import Iterable

import torch

__all__ = ["count_neighbors", "average_num_neighbors"]


@torch.no_grad()
def count_neighbors(
    positions: torch.Tensor,
    batch_idx: torch.Tensor,
    cutoff: float,
    max_neighbors: int | None = None,
    chunk: int = 4096,
) -> tuple[int, int]:
    """``(edges, atoms)`` of the radius graph for one flat batch, counted without building it.

    Directed edges within ``cutoff`` (strictly), same group only, no self loops, each center
    capped at ``max_neighbors``.
    """
    n = int(positions.shape[0])
    edges = 0
    for start in range(0, n, chunk):
        stop = min(start + chunk, n)
        d = torch.cdist(positions[start:stop], positions)
        mask = (d < cutoff) & (batch_idx[start:stop, None] == batch_idx[None, :])
        rows = torch.arange(stop - start, device=positions.device)
        mask[rows, rows + start] = False
        degree = mask.sum(dim=1)
        if max_neighbors is not None:
            degree = degree.clamp(max=int(max_neighbors))
        edges += int(degree.sum())
    return edges, n


@torch.no_grad()
def average_num_neighbors(
    batches: Iterable,
    cutoff: float,
    max_neighbors: int | None = None,
) -> float:
    """Average degree (total directed edges / total atoms) over an iterable of batches.

    Each item is anything with ``positions`` and ``batch_idx`` (see
    :class:`bb.graph.GraphBatch`), or a ``(positions, batch_idx)`` tuple. This is the
    ``avg_num_neighbors`` constant message passing normalizes by: measure it once on the
    training split and store it with the model, as NequIP/MACE do.
    """
    edges = atoms = 0
    for item in batches:
        if isinstance(item, tuple):
            pos, bidx = item
        else:
            pos, bidx = item.positions, item.batch_idx
        e, a = count_neighbors(pos, bidx, cutoff, max_neighbors)
        edges += e
        atoms += a
    if atoms == 0:
        raise ValueError("no atoms to measure the neighbor count on")
    return max(edges / atoms, 1.0)
