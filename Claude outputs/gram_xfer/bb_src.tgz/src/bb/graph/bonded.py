"""Bond (topology) graphs for the edge cluster expansion.

The caller supplies an undirected bond list. Everything here is index bookkeeping on that fixed
topology, so it is built once and reused for every geometry. :func:`bond_graph` takes either a
python/numpy bond list (built with loops, once) or a ``(B, 2)`` tensor (vectorized on the
tensor's device, cheap enough to rebuild every batch inside a training loop). There is no distance
cutoff: the graph is smooth by construction and nothing leaks between molecules. A batch of
molecules is one bond list in global atom indices (offset each molecule's bonds by the number of
atoms before it).

A fixed topology rules out bond breaking; this is for nonreactive bonded models.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

__all__ = ["COVALENT_RADII", "BondGraph", "LineGraph", "bond_graph", "covalent_bonds", "line_graph"]

#: Single-bond covalent radii (Angstrom), Cordero et al., Dalton Trans. 2832 (2008); C is sp3.
COVALENT_RADII: dict[int, float] = {
    1: 0.31, 2: 0.28, 3: 1.28, 4: 0.96, 5: 0.84, 6: 0.76, 7: 0.71, 8: 0.66, 9: 0.57, 10: 0.58,
    11: 1.66, 12: 1.41, 13: 1.21, 14: 1.11, 15: 1.07, 16: 1.05, 17: 1.02, 18: 1.06,
    19: 2.03, 20: 1.76, 30: 1.22, 31: 1.22, 32: 1.20, 33: 1.19, 34: 1.20, 35: 1.20, 36: 1.16,
    37: 2.20, 38: 1.95, 50: 1.39, 51: 1.39, 52: 1.38, 53: 1.39, 54: 1.40, 55: 2.44, 56: 2.15,
}


@dataclass
class BondGraph:
    """Directed-edge view of an undirected bond list.

    Edge ``e`` and ``e + n_bonds`` are the two directions of bond ``e``.

    Attributes
    ----------
    edge_index : (2, E) src, dst of each directed edge; E = 2 * n_bonds.
    rev        : (E,) index of the reverse edge.
    bond_id    : (E,) undirected bond of each directed edge.
    near       : (2, P) pairs (e, e'): e' leaves src(e) and e' != e.
                 Neighbour k = dst(e') sits on the *near* end of e.
    far        : (2, Q) pairs (e, e''): e'' leaves dst(e) and e'' != rev(e).
                 Neighbour l = dst(e'') sits on the *far* end of e.
    bonds      : (B, 2) the canonical (input) orientation of each bond.
    """

    edge_index: torch.Tensor
    rev: torch.Tensor
    bond_id: torch.Tensor
    near: torch.Tensor
    far: torch.Tensor
    bonds: torch.Tensor
    n_atoms: int

    @property
    def n_bonds(self) -> int:
        return int(self.bonds.shape[0])

    @property
    def n_edges(self) -> int:
        return int(self.edge_index.shape[1])

    def to(self, device) -> "BondGraph":
        f = lambda t: t.to(device)  # noqa: E731
        return BondGraph(f(self.edge_index), f(self.rev), f(self.bond_id), f(self.near),
                         f(self.far), f(self.bonds), self.n_atoms)


def _out_edge_slots(src: torch.Tensor, n_atoms: int):
    """Edges sorted by source, ``(n_atoms,)`` counts and offsets, and the max degree."""
    order = torch.argsort(src, stable=True)
    counts = torch.bincount(src, minlength=n_atoms)
    offsets = torch.cumsum(counts, 0) - counts
    deg_max = int(counts.max()) if src.numel() else 0
    return order, counts, offsets, deg_max


def _pairs_through(atom: torch.Tensor, exclude: torch.Tensor, order, counts, offsets, deg_max):
    """``(2, P)`` pairs ``(e, e')``: every edge ``e'`` leaving ``atom[e]``, except ``exclude[e]``."""
    ne = atom.numel()
    device = atom.device
    if ne == 0 or deg_max == 0:
        return torch.zeros(2, 0, dtype=torch.long, device=device)
    t = torch.arange(deg_max, device=device)
    keep = t[None, :] < counts[atom][:, None]                                # (E, deg_max)
    slot = (offsets[atom][:, None] + t[None, :]).clamp(max=ne - 1)
    cand = order[slot]
    keep = keep & (cand != exclude[:, None])
    e = torch.arange(ne, device=device)[:, None].expand_as(cand)
    return torch.stack((e[keep], cand[keep]))


def _bond_graph_torch(b: torch.Tensor, n_atoms: int) -> BondGraph:
    b = b.to(torch.long).reshape(-1, 2)
    device = b.device
    nb = b.shape[0]
    src = torch.cat((b[:, 0], b[:, 1]))
    dst = torch.cat((b[:, 1], b[:, 0]))
    ne = 2 * nb
    ar = torch.arange(nb, device=device)
    rev = torch.cat((ar + nb, ar))
    bond_id = torch.cat((ar, ar))
    order, counts, offsets, deg_max = _out_edge_slots(src, n_atoms)
    e_all = torch.arange(ne, device=device)
    near = _pairs_through(src, e_all, order, counts, offsets, deg_max)
    far = _pairs_through(dst, rev, order, counts, offsets, deg_max)
    return BondGraph(torch.stack((src, dst)), rev, bond_id, near, far, b, int(n_atoms))


def bond_graph(bonds, n_atoms: int, *, check: bool = True) -> BondGraph:
    """Build a :class:`BondGraph` from an undirected bond list ``(B, 2)``.

    A tensor input takes the vectorized path on its own device; the pair *sets* are identical to
    the list path's (their order may differ, which nothing downstream depends on: densities are
    sums). ``check=False`` skips the host-side validation (range, self-bonds, duplicates).
    """
    if isinstance(bonds, torch.Tensor):
        b = bonds.reshape(-1, 2)
        if check and b.numel():
            if int(b.min()) < 0 or int(b.max()) >= n_atoms:
                raise ValueError("bond_graph: atom index out of range")
            if bool((b[:, 0] == b[:, 1]).any()):
                raise ValueError("bond_graph: self-bond")
            key = torch.sort(b, dim=1).values
            if torch.unique(key, dim=0).shape[0] != key.shape[0]:
                raise ValueError("bond_graph: duplicate bond")
        return _bond_graph_torch(b, n_atoms)
    b = np.asarray(bonds, dtype=np.int64).reshape(-1, 2)
    if len(b) and (b.min() < 0 or b.max() >= n_atoms):
        raise ValueError("bond_graph: atom index out of range")
    if (b[:, 0] == b[:, 1]).any():
        raise ValueError("bond_graph: self-bond")
    key = np.sort(b, axis=1)
    if len(np.unique(key, axis=0)) != len(key):
        raise ValueError("bond_graph: duplicate bond")
    nb = len(b)
    src = np.concatenate([b[:, 0], b[:, 1]])
    dst = np.concatenate([b[:, 1], b[:, 0]])
    ne = 2 * nb
    rev = np.concatenate([np.arange(nb, ne), np.arange(nb)])
    bond_id = np.concatenate([np.arange(nb), np.arange(nb)])

    out_edges: list[list[int]] = [[] for _ in range(n_atoms)]
    for e in range(ne):
        out_edges[src[e]].append(e)

    near, far = [], []
    for e in range(ne):
        for e2 in out_edges[src[e]]:
            if e2 != e:
                near.append((e, e2))
        for e2 in out_edges[dst[e]]:
            if e2 != rev[e]:
                far.append((e, e2))

    def t(x):
        return torch.as_tensor(np.asarray(x, dtype=np.int64))

    near_t = t(near).reshape(-1, 2).T.contiguous()
    far_t = t(far).reshape(-1, 2).T.contiguous()
    return BondGraph(t(np.stack([src, dst])), t(rev), t(bond_id), near_t, far_t, t(b), n_atoms)


def covalent_bonds(positions, atomic_numbers, scale: float = 1.2) -> np.ndarray:
    """Perceive bonds from one reference geometry: ``r_ij < scale * (r_cov,i + r_cov,j)``.

    Returns ``(B, 2)`` with ``i < j``. Run it once per molecule (e.g. on the optimized
    structure) and keep the topology fixed for every other geometry.
    """
    pos = np.asarray(torch.as_tensor(positions).detach().cpu(), dtype=np.float64)
    z = np.asarray(torch.as_tensor(atomic_numbers).cpu(), dtype=np.int64)
    missing = sorted({int(x) for x in z} - COVALENT_RADII.keys())
    if missing:
        raise KeyError(f"covalent_bonds: no covalent radius for Z={missing}")
    rad = np.array([COVALENT_RADII[int(x)] for x in z])
    d = np.linalg.norm(pos[:, None] - pos[None], axis=-1)
    i, j = np.nonzero(np.triu(d < scale * (rad[:, None] + rad[None]), k=1))
    return np.stack([i, j], axis=1)


@dataclass
class LineGraph:
    """Unordered pairs of distinct bonds that share an atom.

    ``sigma`` is +1 where the bond's canonical orientation (as given to :func:`bond_graph`)
    points away from the shared atom, else -1. A coupling between directed quantities on the two
    bonds (e.g. split charges) is then ``sigma_b * sigma_b' * k_bb'`` with ``k`` orientation-free.
    """

    pairs: torch.Tensor   # (2, M) bond ids b < b'
    shared: torch.Tensor  # (M,) shared atom
    sigma: torch.Tensor   # (2, M) orientation signs of b and b'


def line_graph(g: BondGraph) -> LineGraph:
    b = g.bonds.cpu().numpy()
    by_atom: list[list[int]] = [[] for _ in range(g.n_atoms)]
    for i, (p, q) in enumerate(b):
        by_atom[p].append(i)
        by_atom[q].append(i)
    pairs, shared, sig = [], [], []
    for a, lst in enumerate(by_atom):
        for x in range(len(lst)):
            for y in range(x + 1, len(lst)):
                b1, b2 = sorted((lst[x], lst[y]))
                pairs.append((b1, b2))
                shared.append(a)
                sig.append((1 if b[b1, 0] == a else -1, 1 if b[b2, 0] == a else -1))
    pairs_t = torch.as_tensor(np.asarray(pairs, dtype=np.int64)).reshape(-1, 2).T.contiguous()
    sig_t = torch.as_tensor(np.asarray(sig, dtype=np.int64)).reshape(-1, 2).T.contiguous()
    return LineGraph(pairs_t, torch.as_tensor(np.asarray(shared, dtype=np.int64)), sig_t)
