"""Generic output transforms: pooling, constraints, Cartesian conversion, positivity.

These are the post-processing steps the source repos had folded into named heads, factored out so
a readout's physical meaning is assembled by the caller:

====================================  ================================================
old head                               readout + transforms
====================================  ================================================
per-atom charge, total pinned          ``1x0e`` -> :func:`constrain_sum`
extensive energy                       ``1x0e`` (+ species bias) -> :func:`pool`
positive width / ratio                 ``1x0e`` -> :func:`softplus_floor` / :func:`bounded`
symmetric rank-2 (polarizability)      ``1x0e + 1x2e`` -> :func:`to_voigt` or :func:`psd_symmetric`
molecular dipole                       ``1x0e`` (sum-constrained) + ``1x1o`` -> :func:`first_moment`
====================================  ================================================
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F

from ..graph.batch import num_systems, scatter_sum
from ..o3.cartesian import irrep6_to_voigt, min_eig_sym3x3, voigt_to_matrix

__all__ = [
    "pool",
    "constrain_sum",
    "to_voigt",
    "psd_symmetric",
    "softplus_floor",
    "inverse_softplus_floor",
    "bounded",
    "logit_bounded",
    "first_moment",
]


def pool(x: torch.Tensor, batch_idx: torch.Tensor, n_systems: int | None = None, reduce: str = "sum") -> torch.Tensor:
    """Per-atom rows to per-structure rows: ``(N, ...) -> (B, ...)``, ``"sum"`` or ``"mean"``."""
    n = num_systems(batch_idx) if n_systems is None else int(n_systems)
    total = scatter_sum(x, batch_idx, n)
    if reduce == "sum":
        return total
    if reduce == "mean":
        counts = x.new_zeros(n).index_add_(0, batch_idx, x.new_ones(x.shape[0]))
        return total / counts.clamp_min(1.0).reshape(-1, *([1] * (x.dim() - 1)))
    raise ValueError(f"reduce must be 'sum' or 'mean', got {reduce!r}")


def constrain_sum(
    x: torch.Tensor,
    batch_idx: torch.Tensor,
    target: torch.Tensor | float = 0.0,
    n_systems: int | None = None,
) -> torch.Tensor:
    """Shift per-atom values uniformly so each structure sums exactly to ``target``.

    A uniform shift is the minimum-norm correction and leaves the relative pattern intact. For
    charges this is what makes ``sum_i q_i r_i`` origin-independent.
    """
    n = num_systems(batch_idx) if n_systems is None else int(n_systems)
    counts = x.new_zeros(n).index_add_(0, batch_idx, torch.ones_like(x))
    totals = scatter_sum(x, batch_idx, n)
    if not isinstance(target, torch.Tensor):
        target = torch.as_tensor(target, dtype=x.dtype, device=x.device)
    target = target.to(dtype=x.dtype, device=x.device).expand(n)
    shift = (target - totals) / counts.clamp_min(1.0)
    return x + shift.index_select(0, batch_idx)


def to_voigt(x0: torch.Tensor, x2: torch.Tensor, irrep6_to_voigt_matrix: torch.Tensor | None = None) -> torch.Tensor:
    """``0e`` ``(..., 1)`` + ``2e`` ``(..., 5)`` -> symmetric tensor in Voigt order ``(..., 6)``."""
    M = irrep6_to_voigt() if irrep6_to_voigt_matrix is None else irrep6_to_voigt_matrix
    return torch.cat((x0, x2), dim=-1) @ M.to(device=x2.device, dtype=x2.dtype).t()


def psd_symmetric(
    x0: torch.Tensor,
    x2: torch.Tensor,
    *,
    floor: float = 1e-4,
    enforce: bool = True,
    smooth: float | None = 0.05,
    irrep6_to_voigt_matrix: torch.Tensor | None = None,
) -> torch.Tensor:
    """A symmetric rank-2 tensor with a strictly positive isotropic part, in Voigt ``(..., 6)``.

    ``T = T_aniso(x2) + a I`` with ``a = softplus(x0) + floor``, assembled in Cartesian space:
    the ``0e`` irrep maps to ``(1/sqrt 3) I``, so a shift in irrep space would move eigenvalues by
    only ``1/sqrt 3`` and guarantee nothing.

    With ``enforce`` the shift is additionally raised above the most negative eigenvalue of
    ``T_aniso``, so every eigenvalue of ``T`` is ``>= floor``:

    * ``smooth=None``: ``a -> a - min(min_eig(T_aniso), 0)`` (kinked where the eigenvalue
      changes sign);
    * ``smooth=s``: ``a -> a + t softplus(-min_eig / t)`` with ``t = s a``, an upper bound of the
      hard shift that is C-infinity -- no force discontinuity where an atomic tensor passes
      through singularity.
    """
    M = irrep6_to_voigt() if irrep6_to_voigt_matrix is None else irrep6_to_voigt_matrix
    M = M.to(device=x2.device, dtype=x2.dtype)
    voigt_aniso = torch.cat((torch.zeros_like(x0), x2), dim=-1) @ M.t()
    a = F.softplus(x0) + floor
    if enforce:
        min_eig = min_eig_sym3x3(voigt_to_matrix(voigt_aniso)).unsqueeze(-1)
        if smooth is None:
            a = a - min_eig.clamp(max=0.0)
        else:
            t = (smooth * a).clamp_min(1e-30)
            a = a + t * F.softplus(-min_eig / t)
    iso = torch.cat((a, a, a, torch.zeros_like(a).expand(*a.shape[:-1], 3)), dim=-1)
    return voigt_aniso + iso


def softplus_floor(x: torch.Tensor, floor: float = 0.0) -> torch.Tensor:
    """``softplus(x) + floor``: positive and bounded away from zero."""
    return F.softplus(x) + floor


def inverse_softplus_floor(value: float, floor: float = 0.0) -> float:
    """The pre-activation giving ``softplus_floor(x, floor) == value`` (for bias init)."""
    target = max(float(value) - float(floor), 1e-3)
    # computed in the default dtype, as the original heads did, so an initial bias is
    # bit-identical to theirs
    return float(torch.log(torch.expm1(torch.tensor(target))))


def bounded(x: torch.Tensor, lo: float, hi: float) -> torch.Tensor:
    """``lo + (hi - lo) sigmoid(x)``: a two-sided bound, for a weakly identified quantity that
    must not run off to a degenerate optimum."""
    return lo + (hi - lo) * torch.sigmoid(x)


def logit_bounded(value: float, lo: float, hi: float) -> float:
    """The pre-activation giving ``bounded(x, lo, hi) == value`` (for bias init)."""
    if not lo < value < hi:
        raise ValueError(f"need lo < value < hi, got {lo} / {value} / {hi}")
    frac = (float(value) - lo) / (hi - lo)
    return float(math.log(frac / (1.0 - frac)))


def first_moment(
    positions: torch.Tensor,
    batch_idx: torch.Tensor,
    scalars: torch.Tensor | None = None,
    vectors: torch.Tensor | None = None,
    n_systems: int | None = None,
) -> torch.Tensor:
    """``sum_i s_i (r_i - r_ref) + sum_i v_i`` per structure, ``(B, 3)``.

    The first moment of a per-atom scalar distribution plus per-atom vectors -- with charges and
    atomic dipoles, the molecular dipole. ``r_ref`` is the per-structure centroid; when the
    scalars sum to zero (:func:`constrain_sum`) the result does not depend on it, and using it
    keeps the summands small in float32.
    """
    n = num_systems(batch_idx) if n_systems is None else int(n_systems)
    dipole = positions.new_zeros((n, 3))
    if scalars is not None:
        counts = torch.zeros(n, dtype=positions.dtype, device=positions.device).index_add_(
            0, batch_idx, torch.ones(positions.shape[0], dtype=positions.dtype, device=positions.device)
        )
        centroid = scatter_sum(positions, batch_idx, n) / counts[:, None]
        rel = positions - centroid.index_select(0, batch_idx)
        dipole = dipole + scatter_sum(scalars[:, None] * rel, batch_idx, n)
    if vectors is not None:
        dipole = dipole + scatter_sum(vectors, batch_idx, n)
    return dipole
