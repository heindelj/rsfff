"""Readouts specified by irreps: features in, any ``Kx0e + Mx1o + Px2e + ...`` out.

One construction covers every per-atom head the source repos had (scalar, vector, quadrupole,
polarizability, response tensors): an invariant MLP produces the scalar outputs and per-channel
*gates*, and for each non-scalar output irrep a learned channel reduction contracts the input
block of the same irrep without ever mixing its ``m`` axis::

    s          = cat(features[0e], scalars)              # (N, P0 + D)  invariant MLP input
    o          = MLP(s)                                   # scalar outputs | gates
    y[0e]      = o[:, :K0]                                # (N, 1, K0)
    x_k[ir]    = features[ir] @ reduce[ir]                # (N, 2l+1, R_ir) channel reduction
    y[ir][:, :, c] = sum_r x_k[ir][:, :, r] * gate[ir][:, c, r]

The output is equivariant because only invariants (the gates) multiply the equivariant
channels, and its magnitude and sign are conditioned on the environment. Physical meaning is the
caller's: a charge is a ``1x0e`` output, an atomic dipole ``1x1o``, a polarizability
``1x0e + 1x2e`` passed through :func:`bb.heads.to_voigt` and :func:`bb.heads.psd_symmetric`.

Options
-------
``scalar_dim``     width of extra invariants appended to the ``0e`` features (an embedding, a
                   field magnitude, a state vector, ...).
``reduce_channels`` ``R`` (int, or per irrep). ``reduce=False`` skips the reduction: the input
                   block is already reduced (a projection shared by several readouts), and its
                   width is ``R``.
``zero_init``      zero the MLP readout, so every output starts at exactly 0 (or at the scalar
                   bias set with :meth:`set_scalar_bias`). Wrong for a target fitted with a loss
                   that is even in the prediction (a phase-free dipole): zero is then a
                   stationary point the head never leaves.
``exempt_decay``   exempt the whole readout from weight decay. With a zero-initialized gate the
                   reduction has no gradient, so a decaying reduction deadlocks the pair (see
                   :mod:`bb.nn.init`).
``env_widths``     two-slot inputs: the trailing ``{irrep: p_env}`` channels of each input block
                   are an "environment" slot with separate, tagged, zero-initialized weights
                   (:class:`bb.nn.TwoSlotLinear`). A block given without them is evaluated as
                   isolated.
``species_bias``   ``n_species`` for a learnable per-species bias on the scalar outputs.
``gate_layout``    ``"blocked"`` (``[scalars | gates(ir1) | gates(ir2) ...]``) or
                   ``"interleaved"`` (per output channel ``c``: ``[scalar_c | gates_c(ir1) | ...]``;
                   needs equal multiplicities).
"""

from __future__ import annotations

import math
from typing import Mapping

import torch
import torch.nn as nn

from ..nn.init import exempt_from_weight_decay
from ..nn.slots import env_reduce_parameter, slot_reduce, two_slot_mlp
from ..o3.irreps import Irrep, IrrepFeatures, Irreps, IrrepsLike

__all__ = ["IrrepsReadout"]

_SCALAR = Irrep(0, 1)


def _widths(spec) -> dict[Irrep, int]:
    out: dict[Irrep, int] = {}
    for mul, ir in Irreps(spec):
        out[ir] = out.get(ir, 0) + mul
    return out


class IrrepsReadout(nn.Module):
    def __init__(
        self,
        irreps_in: IrrepsLike,
        irreps_out: IrrepsLike,
        *,
        scalar_dim: int = 0,
        hidden: int = 64,
        depth: int = 2,
        reduce_channels: int | Mapping = 32,
        reduce: bool = True,
        zero_init: bool = True,
        exempt_decay: bool = True,
        env_widths: Mapping | None = None,
        species_bias: int | None = None,
        gate_layout: str = "blocked",
    ) -> None:
        super().__init__()
        self.in_widths = _widths(irreps_in)
        self.out_mults = _widths(irreps_out)
        self.scalar_dim = int(scalar_dim)
        self.gated = [ir for ir in sorted(self.out_mults, key=lambda r: (r.l, r.p != (-1) ** r.l)) if ir != _SCALAR]
        self.n_scalar_out = self.out_mults.get(_SCALAR, 0)
        self.reduce_on = bool(reduce)
        if gate_layout not in ("blocked", "interleaved"):
            raise ValueError(f"gate_layout must be 'blocked' or 'interleaved', got {gate_layout!r}")
        self.gate_layout = gate_layout
        env = {Irrep.parse(k): int(v) for k, v in (env_widths or {}).items()}
        self.env_widths = env

        # per-irrep reduction width R
        self.reduce_width: dict[Irrep, int] = {}
        for ir in self.gated:
            if ir not in self.in_widths:
                raise ValueError(
                    f"output irrep {ir} needs an input block of the same irrep; inputs are "
                    f"{Irreps([(m, i) for i, m in self.in_widths.items()])}"
                )
            if not self.reduce_on:
                self.reduce_width[ir] = self.in_widths[ir]
            elif isinstance(reduce_channels, Mapping):
                self.reduce_width[ir] = int({Irrep.parse(k): v for k, v in reduce_channels.items()}[ir])
            else:
                self.reduce_width[ir] = int(reduce_channels)

        if self.gate_layout == "interleaved":
            mults = {self.out_mults[ir] for ir in self.out_mults}
            if len(mults) != 1:
                raise ValueError("gate_layout='interleaved' needs every output irrep to have the same multiplicity")

        # Channel reductions first, then the MLP: the order the original heads drew their
        # initial weights in, so a seeded fresh model matches them bit for bit.
        self.reduce = nn.ParameterDict()
        self.reduce_env = nn.ParameterDict()
        if self.reduce_on:
            for ir in self.gated:
                p_ir = self.in_widths[ir] - env.get(ir, 0)
                k = self.reduce_width[ir]
                self.reduce[str(ir)] = nn.Parameter(torch.randn(p_ir, k) / math.sqrt(p_ir))
                e = env_reduce_parameter(env.get(ir, 0), k)
                if e is not None:
                    self.reduce_env[str(ir)] = e

        # invariant MLP: [0e features | scalars] -> [scalar outputs | gates]
        p0 = self.in_widths.get(_SCALAR, 0)
        p0_env = env.get(_SCALAR, 0)
        n_out = self.n_scalar_out + sum(self.out_mults[ir] * self.reduce_width[ir] for ir in self.gated)
        self.mlp = two_slot_mlp(p0 - p0_env, p0_env, hidden, depth, n_out, p_tail=self.scalar_dim)

        self.species_bias = (
            nn.Parameter(torch.zeros(int(species_bias), max(self.n_scalar_out, 1)))
            if species_bias else None
        )

        if zero_init:
            last = self.mlp[-1]
            with torch.no_grad():
                last.weight.zero_()
                last.bias.zero_()
        if exempt_decay:
            exempt_from_weight_decay(self)

    # ------------------------------------------------------------------ init helpers
    def set_scalar_bias(self, value: float | torch.Tensor) -> None:
        """Set the bias of the scalar outputs (e.g. so ``softplus(y) + floor`` starts at a target)."""
        with torch.no_grad():
            bias = self.mlp[-1].bias
            if self.gate_layout == "blocked":
                bias[: self.n_scalar_out] = torch.as_tensor(value, dtype=bias.dtype)
            else:
                stride = 1 + sum(self.reduce_width[ir] for ir in self.gated)
                bias.view(-1, stride)[:, 0] = torch.as_tensor(value, dtype=bias.dtype)

    @property
    def irreps_out(self) -> Irreps:
        return Irreps([(m, ir) for ir, m in sorted(self.out_mults.items(), key=lambda t: (t[0].l, t[0].p != (-1) ** t[0].l))])

    # ------------------------------------------------------------------ forward
    def _split(self, o: torch.Tensor) -> tuple[torch.Tensor | None, dict[Irrep, torch.Tensor]]:
        n = o.shape[0]
        gates: dict[Irrep, torch.Tensor] = {}
        if self.gate_layout == "blocked":
            scal = o[:, : self.n_scalar_out] if self.n_scalar_out else None
            off = self.n_scalar_out
            for ir in self.gated:
                m, k = self.out_mults[ir], self.reduce_width[ir]
                gates[ir] = o[:, off: off + m * k].reshape(n, m, k)
                off += m * k
            return scal, gates
        m = next(iter(self.out_mults.values()))
        o = o.reshape(n, m, -1)
        off = 0
        scal = None
        if self.n_scalar_out:
            scal = o[..., 0]
            off = 1
        for ir in self.gated:
            k = self.reduce_width[ir]
            gates[ir] = o[..., off: off + k]
            off += k
        return scal, gates

    def forward(
        self,
        features: "IrrepFeatures | Mapping",
        scalars: torch.Tensor | None = None,
        species_idx: torch.Tensor | None = None,
    ) -> IrrepFeatures:
        """``features``: :class:`IrrepFeatures` or ``{irrep: (N, 2l+1, P)}``; ``scalars``:
        ``(N, scalar_dim)`` extra invariants. Returns :class:`IrrepFeatures` with one
        ``(N, 2l+1, mult)`` block per output irrep."""
        if isinstance(features, IrrepFeatures):
            blocks = features.blocks
            if species_idx is None:
                species_idx = features.species_idx
        else:
            blocks = {Irrep.parse(k): v for k, v in features.items()}

        parts = []
        if _SCALAR in blocks:
            parts.append(blocks[_SCALAR][:, 0, :])
        if self.scalar_dim:
            if scalars is None:
                raise ValueError(f"this readout expects scalars of width {self.scalar_dim}")
            parts.append(scalars)
        s = parts[0] if len(parts) == 1 else torch.cat(parts, dim=-1)
        scal, gates = self._split(self.mlp(s))

        out: dict[Irrep, torch.Tensor] = {}
        if scal is not None:
            if self.species_bias is not None:
                if species_idx is None:
                    raise ValueError("species_bias needs species_idx")
                scal = scal + self.species_bias[species_idx]
            out[_SCALAR] = scal.unsqueeze(1)
        for ir in self.gated:
            x = blocks[ir]
            if self.reduce_on:
                key = str(ir)
                R = slot_reduce(self.reduce[key], self.reduce_env[key] if key in self.reduce_env else None, x.shape[-1])
                x = torch.einsum("nmp,pk->nmk", x, R)
            g = gates[ir]                                        # (N, mult, R)
            if g.shape[1] == 1:
                out[ir] = torch.einsum("nmk,nk->nm", x, g[:, 0]).unsqueeze(-1)
            else:
                out[ir] = torch.einsum("nmk,nck->nmc", x, g)
        return IrrepFeatures(out, species_idx=species_idx)
