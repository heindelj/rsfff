"""Readouts on :class:`bb.features.EdgeFeatures`.

:class:`EdgeScalarReadout` is an invariant MLP per directed edge, combined over the two
directions of each bond: summed (``symmetry="sym"``: bond energies, force constants, polarizable
bond widths) or subtracted (``"antisym"``: quantities that follow the bond's canonical
orientation, e.g. a split-charge drive). :class:`EdgeReadout` gives equivariant outputs of any
irreps (dipoles, quadrupoles, polarizabilities per bond), built in the bond frame and rotated back.
"""

from __future__ import annotations

import torch
from torch import nn

from ..features.edge import EdgeFeatures
from ..nn.init import zero_init_readout
from ..nn.mlp import mlp

__all__ = ["EdgeReadout", "EdgeScalarReadout", "bond_to_atoms", "flow_to_charges"]


class EdgeScalarReadout(nn.Module):
    """``n_out`` O(3)-invariant scalars per bond from ECE features.

    Parameters
    ----------
    dim_0e, dim_0o, n_radial, n_species : feature sizes; :meth:`from_ece` reads them off an
        :class:`~bb.features.EdgeClusterExpansion`.
    symmetry : ``"sym"`` (sum of both directions) or ``"antisym"`` (canonical minus reverse).
    odd : how the ``0o`` block enters. ``"symmetrize"`` (default) evaluates the MLP at ``+o`` and
        ``-o`` and averages, which is exactly invariant and keeps every even function of ``o``,
        products between different pseudoscalars included, at twice the MLP cost. ``"square"``
        feeds ``o**2`` once (cheaper, but loses the cross products). ``"drop"`` ignores it.
    zero_init : start at zero (and exempt the MLP from weight decay; see :mod:`bb.nn.init`).
    bond_basis : if > 0, the MLP emits ``bond_basis`` coefficients per output and the edge value
        is their dot product with the first ``bond_basis`` Morse functions of r_ij (as ECENet's
        ``n_max_d``): ``y = sum_q c_q(x) b_q(r_ij)``. Makes the dependence on the bond length an
        explicit expansion instead of one more MLP input.

    ``forward`` returns ``{"edge": (E, n_out), "bond": (B, n_out)}`` and, for ``"sym"``,
    ``"total"``: ``(n_out,)``, or ``(n_systems, n_out)`` if ``batch_idx`` is given.
    """

    def __init__(
        self,
        dim_0e: int,
        dim_0o: int,
        n_radial: int,
        n_species: int,
        n_out: int = 1,
        symmetry: str = "sym",
        odd: str = "symmetrize",
        species_dim: int = 8,
        hidden: int = 64,
        depth: int = 2,
        zero_init: bool = False,
        bond_basis: int = 0,
    ):
        super().__init__()
        if bond_basis > n_radial:
            raise ValueError(f"bond_basis={bond_basis} exceeds the {n_radial} bond functions available")
        self.bond_basis = bond_basis
        if symmetry not in ("sym", "antisym"):
            raise ValueError(f"symmetry must be 'sym' or 'antisym', got {symmetry!r}")
        if odd not in ("symmetrize", "square", "drop"):
            raise ValueError(f"odd must be 'symmetrize', 'square' or 'drop', got {odd!r}")
        self.symmetry, self.odd, self.n_out = symmetry, odd, n_out
        self.emb = nn.Embedding(n_species, species_dim)
        d_odd = 0 if odd == "drop" else dim_0o
        self.mlp = mlp(dim_0e + d_odd + n_radial + 2 * species_dim, hidden, depth,
                       n_out * max(bond_basis, 1))
        if zero_init:
            zero_init_readout(self.mlp)

    @classmethod
    def from_ece(cls, ece, **kwargs) -> "EdgeScalarReadout":
        return cls(ece.dim_0e, ece.dim_0o, ece.n_max, ece.n_species, **kwargs)

    def edge_values(self, ef: EdgeFeatures) -> torch.Tensor:
        """``(E, n_out)``: the readout on each directed edge, before combining directions."""
        y = self._mlp_values(ef)
        if self.bond_basis:
            y = (y.reshape(-1, self.n_out, self.bond_basis) * ef.bond_radial[:, None, :self.bond_basis]).sum(-1)
        return y

    def _mlp_values(self, ef: EdgeFeatures) -> torch.Tensor:
        dt = ef.inv0e.dtype
        rest = [ef.bond_radial, self.emb(ef.species_src).to(dt), self.emb(ef.species_dst).to(dt)]
        o = ef.inv0o
        if self.odd == "drop":
            return self.mlp(torch.cat([ef.inv0e, *rest], dim=-1))
        if self.odd == "square" or o.shape[-1] == 0:
            return self.mlp(torch.cat([ef.inv0e, o.square(), *rest], dim=-1))
        both = torch.cat([torch.cat([ef.inv0e, s * o, *rest], dim=-1) for s in (1.0, -1.0)], dim=0)
        y = self.mlp(both)
        n = o.shape[0]
        return 0.5 * (y[:n] + y[n:])

    def forward(self, ef: EdgeFeatures, batch_idx: torch.Tensor | None = None,
                n_systems: int | None = None) -> dict[str, torch.Tensor]:
        e_edge = self.edge_values(ef)
        g = ef.graph
        nb = g.n_bonds
        rev = g.rev[:nb]
        if self.symmetry == "sym":
            e_bond = e_edge[:nb] + e_edge[rev]
        else:
            e_bond = e_edge[:nb] - e_edge[rev]
        out = {"edge": e_edge, "bond": e_bond}
        if self.symmetry == "sym":
            if batch_idx is None:
                out["total"] = e_bond.sum(0)
            else:
                n = int(batch_idx.max()) + 1 if n_systems is None else int(n_systems)
                sys_of_bond = batch_idx[g.bonds[:, 0]]
                out["total"] = e_bond.new_zeros(n, self.n_out).index_add(0, sys_of_bond, e_bond)
        return out


class EdgeReadout(nn.Module):
    """Equivariant outputs of any irreps per bond, built in the bond frame and rotated back.

    In the frame of a directed edge the residual symmetry is O(2): rotation about the bond, and a
    mirror containing it, which acts on every m-channel ``z_m = c[+m] + i c[-m]`` as complex
    conjugation. An output irrep ``(l, p)`` restricted to O(2) splits into an ``m = 0`` part and
    one 2-vector per ``m = 1..l``; its ``m = 0`` part is a scalar (0e) if the parity is natural,
    ``p = (-1)^l`` (1o, 2e, 3o), and a pseudoscalar (0o) otherwise (1e, 2o, 3e). So, with
    ``h_e`` / ``h_o`` the even / odd parts in the 0o features of an invariant MLP:

        natural     y_0 = h_e,   y_m = sum_c h_e,c z_m,c + h_o,c (i z_m,c)
        unnatural   y_0 = h_o,   y_m = sum_c h_e,c (i z_m,c) + h_o,c z_m,c

    over the ``4C`` m-channels of the ECE (two projections of each end). ``y`` is placed in the
    real-SH layout of degree ``l`` and rotated back with ``D^l(R_e)^T``. The two directions of a
    bond are added (``symmetry="sym"``) or subtracted (``"antisym"``, e.g. a bond dipole that
    follows the bond's canonical orientation, or a split-charge flow for ``1x0e``).

    Every m-component is linear in the density channels with invariant coefficients; that is
    complete wherever some channel with that m is nonzero (it can vanish at symmetric
    geometries, where the output component must vanish too). Requires ``l <= ece.l_max``.

    ``extra_dim`` > 0 appends caller-supplied invariant scalars per directed edge (``extra`` in
    :meth:`forward`, ``(E, extra_dim)``: atom latents, type embeddings, ...) to the MLP input; they
    must be even under improper operations. ``compress=True`` passes the ECE invariants and the bond
    radial functions through ``asinh`` first (the density products span orders of magnitude between
    a terminal and a highly connected bond). Defaults reproduce the plain readout exactly.

    ``forward`` returns ``{"edge": {irrep: (E, 2l+1, mul)}, "bond": {irrep: (B, 2l+1, mul)}}``.
    """

    SIDES = ("na", "nb", "fa", "fb")

    def __init__(self, ece, irreps_out, symmetry: str = "sym", species_dim: int = 8,
                 hidden: int = 64, depth: int = 2, zero_init: bool = False,
                 extra_dim: int = 0, compress: bool = False):
        super().__init__()
        from ..o3.irreps import Irreps

        if symmetry not in ("sym", "antisym"):
            raise ValueError(f"symmetry must be 'sym' or 'antisym', got {symmetry!r}")
        self.irreps = Irreps(irreps_out)
        if self.irreps.lmax > ece.l_max:
            raise ValueError(f"output l={self.irreps.lmax} exceeds the ECE's l_max={ece.l_max}")
        self.symmetry = symmetry
        self.backend = ece.backend
        self.n_cov = len(self.SIDES) * ece.channels
        self.blocks = []
        n_out = 0
        for mul, ir in self.irreps:
            size = mul * (1 + ir.l * self.n_cov)
            self.blocks.append((mul, ir, n_out, size))
            n_out += size
        self.emb = nn.Embedding(ece.n_species, species_dim)
        self.extra_dim, self.compress = int(extra_dim), bool(compress)
        self.mlp = mlp(ece.dim_0e + ece.dim_0o + ece.n_max + 2 * species_dim + self.extra_dim,
                       hidden, depth, n_out)
        if zero_init:
            zero_init_readout(self.mlp)

    def _gates(self, ef: EdgeFeatures, extra=None):
        dt = ef.inv0e.dtype
        c = torch.asinh if self.compress else (lambda t: t)
        rest = [c(ef.bond_radial), self.emb(ef.species_src).to(dt), self.emb(ef.species_dst).to(dt)]
        if self.extra_dim:
            if extra is None or extra.shape[-1] != self.extra_dim:
                raise ValueError(f"EdgeReadout built with extra_dim={self.extra_dim}; pass extra (E, {self.extra_dim})")
            rest.append(extra.to(dt))
        o = c(ef.inv0o)                      # asinh is odd, so the parity of o is kept
        e = c(ef.inv0e)
        x = torch.cat([torch.cat([e, s * o, *rest], -1) for s in (1.0, -1.0)], 0)
        h = self.mlp(x)
        n = o.shape[0]
        return 0.5 * (h[:n] + h[n:]), 0.5 * (h[:n] - h[n:])

    def edge_values(self, ef: EdgeFeatures, extra=None) -> dict:
        """``{irrep: (E, 2l+1, mul)}`` per directed edge, in the global frame."""
        from ..o3.frames import wigner_d_recursive

        if ef.mblocks is None:
            raise ValueError("EdgeReadout needs EdgeFeatures with mblocks (EdgeClusterExpansion output)")
        he, ho = self._gates(ef, extra)
        E = he.shape[0]
        L = self.irreps.lmax
        zr = [None] + [torch.cat([ef.mblocks[s][m][0] for s in self.SIDES], -1) for m in range(1, L + 1)]
        zi = [None] + [torch.cat([ef.mblocks[s][m][1] for s in self.SIDES], -1) for m in range(1, L + 1)]
        Ds = wigner_d_recursive(ef.frames, L, self.backend)
        out = {}
        for mul, ir, off, size in self.blocks:
            l = ir.l
            natural = ir.p == (-1) ** l
            ge, go = he[:, off:off + size], ho[:, off:off + size]
            local = ge.new_zeros(E, 2 * l + 1, mul)
            local[:, l] = (ge if natural else go)[:, :mul]
            for m in range(1, l + 1):
                sl = slice(mul + (m - 1) * mul * self.n_cov, mul + m * mul * self.n_cov)
                Ge = ge[:, sl].reshape(E, mul, self.n_cov)
                Go = go[:, sl].reshape(E, mul, self.n_cov)
                er = torch.einsum("euc,ec->eu", Ge, zr[m])
                ei = torch.einsum("euc,ec->eu", Ge, zi[m])
                orr = torch.einsum("euc,ec->eu", Go, zr[m])
                oi = torch.einsum("euc,ec->eu", Go, zi[m])
                if natural:      # Ge z + Go (i z)
                    re, im = er - oi, ei + orr
                else:            # Ge (i z) + Go z
                    re, im = -ei + orr, er + oi
                local[:, l + m] = re
                local[:, l - m] = im
            key = str(ir)
            glob = torch.einsum("eji,eju->eiu", Ds[l], local)       # D^T y
            out[key] = out[key] + glob if key in out else glob
        return out

    def forward(self, ef: EdgeFeatures, extra=None) -> dict:
        y = self.edge_values(ef, extra)
        g = ef.graph
        nb = g.n_bonds
        rev = g.rev[:nb]
        sign = 1.0 if self.symmetry == "sym" else -1.0
        return {"edge": y, "bond": {k: v[:nb] + sign * v[rev] for k, v in y.items()}}


def bond_to_atoms(values: torch.Tensor, graph, n_atoms: int | None = None) -> torch.Tensor:
    """Split per-bond values ``(B, ...)`` half and half onto the two atoms ``(N, ...)``."""
    n = graph.n_atoms if n_atoms is None else n_atoms
    out = values.new_zeros(n, *values.shape[1:])
    out = out.index_add(0, graph.bonds[:, 0], 0.5 * values)
    return out.index_add(0, graph.bonds[:, 1], 0.5 * values)


def flow_to_charges(flow: torch.Tensor, graph, n_atoms: int | None = None) -> torch.Tensor:
    """Atomic charges from bond charge flows ``(B, ...)`` along each bond's canonical direction
    ``a -> b`` (``q_a -= f``, ``q_b += f``): the total charge is conserved exactly."""
    n = graph.n_atoms if n_atoms is None else n_atoms
    out = flow.new_zeros(n, *flow.shape[1:])
    out = out.index_add(0, graph.bonds[:, 0], -flow)
    return out.index_add(0, graph.bonds[:, 1], flow)
