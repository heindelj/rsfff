"""Irreps bookkeeping and the per-atom feature container.

Every equivariant tensor in bb is stored per irrep as ``(N, 2l+1, C)``: atoms first, the ``m``
components in the middle, channels last. That is the layout the featurizers have always produced
and the one every head contracts against (``einsum("nmp,pk->nmk", ...)``), so it is kept rather
than flattened into an e3nn-style ``(N, dim)`` vector.

Parity follows O(3): ``p = +1`` ("e", even) or ``p = -1`` ("o", odd). Everything built from the
neighbor density has *natural* parity ``p = (-1)^l`` (``0e, 1o, 2e, 3o, ...``), because the density
is a sum of spherical harmonics of bond vectors. Inputs supplied by a caller need not: a magnetic
field or a spin is a pseudovector, ``1e``. Keys therefore carry the parity, and asking for a block
by bare ``l`` only works when that ``l`` is unambiguous.
"""

from __future__ import annotations

import re
from typing import Iterable, Iterator, Mapping, NamedTuple, Union

import torch

__all__ = ["Irrep", "Irreps", "IrrepFeatures", "natural_irrep", "parse_irreps", "split_by_l"]


def split_by_l(x: torch.Tensor, l_max: int) -> list[torch.Tensor]:
    """Split the last dim (size ``(l_max+1)**2``) into per-l blocks ``(..., 2l+1)``."""
    out, start = [], 0
    for l in range(l_max + 1):
        size = 2 * l + 1
        out.append(x[..., start:start + size])
        start += size
    return out


class Irrep(NamedTuple):
    """One O(3) irrep: degree ``l`` and parity ``p`` (``+1`` even, ``-1`` odd)."""

    l: int
    p: int

    @property
    def dim(self) -> int:
        return 2 * self.l + 1

    @property
    def is_scalar(self) -> bool:
        return self.l == 0 and self.p == 1

    @property
    def is_natural(self) -> bool:
        """``p == (-1)^l``: the parity a spherical harmonic of degree ``l`` has."""
        return self.p == (-1) ** self.l

    def __str__(self) -> str:
        return f"{self.l}{'e' if self.p == 1 else 'o'}"

    def __repr__(self) -> str:
        return f"Irrep('{self}')"

    @classmethod
    def parse(cls, value: "IrrepLike") -> "Irrep":
        if isinstance(value, Irrep):
            return value
        if isinstance(value, tuple) and len(value) == 2:
            l, p = value
            if int(p) not in (1, -1):
                raise ValueError(f"parity must be +1 or -1, got {p}")
            return cls(int(l), int(p))
        if isinstance(value, str):
            m = re.fullmatch(r"\s*(\d+)\s*([eoy])\s*", value)
            if not m:
                raise ValueError(f"cannot parse irrep {value!r}; expected e.g. '0e', '1o', '2e'")
            l = int(m.group(1))
            if m.group(2) == "y":  # 'y' = parity of the spherical harmonic, as in e3nn
                return natural_irrep(l)
            return cls(l, 1 if m.group(2) == "e" else -1)
        raise TypeError(f"cannot interpret {value!r} as an irrep")


IrrepLike = Union[Irrep, str, tuple]


def natural_irrep(l: int) -> Irrep:
    """The irrep of a degree-``l`` spherical harmonic: ``0e, 1o, 2e, 3o, ...``."""
    return Irrep(int(l), (-1) ** int(l))


class Irreps(tuple):
    """An ordered multiset of irreps with multiplicities: ``((mul, Irrep), ...)``.

    ``Irreps("8x0e + 4x1o + 2x2e")``; ``Irreps({"0e": 8, "1o": 4})``; ``Irreps([(8, "0e")])``.
    Repeated irreps are kept in the order given (they are distinct blocks of the output), but
    :meth:`as_dict` merges them.
    """

    def __new__(cls, spec: "IrrepsLike" = ()):
        return super().__new__(cls, parse_irreps(spec))

    @property
    def dim(self) -> int:
        return sum(mul * ir.dim for mul, ir in self)

    @property
    def num_irreps(self) -> int:
        return sum(mul for mul, _ in self)

    @property
    def lmax(self) -> int:
        return max((ir.l for _, ir in self), default=-1)

    def as_dict(self) -> dict[Irrep, int]:
        out: dict[Irrep, int] = {}
        for mul, ir in self:
            out[ir] = out.get(ir, 0) + mul
        return out

    def __str__(self) -> str:
        return " + ".join(f"{mul}x{ir}" for mul, ir in self) or "0"

    def __repr__(self) -> str:
        return f"Irreps('{self}')"


IrrepsLike = Union[str, Mapping, Iterable, "Irreps"]


def parse_irreps(spec: IrrepsLike) -> tuple[tuple[int, Irrep], ...]:
    if isinstance(spec, Irreps):
        return tuple(spec)
    if isinstance(spec, str):
        spec = spec.strip()
        if not spec or spec == "0":
            return ()
        out = []
        for term in spec.split("+"):
            term = term.strip()
            m = re.fullmatch(r"(?:(\d+)\s*x\s*)?(\d+\s*[eoy])", term)
            if not m:
                raise ValueError(f"cannot parse irreps term {term!r} in {spec!r}")
            mul = int(m.group(1)) if m.group(1) else 1
            out.append((mul, Irrep.parse(m.group(2))))
        return tuple(out)
    if isinstance(spec, Mapping):
        return tuple((int(mul), Irrep.parse(ir)) for ir, mul in spec.items())
    out = []
    for item in spec:
        mul, ir = item
        out.append((int(mul), Irrep.parse(ir)))
    return tuple(out)


def _sort_key(ir: Irrep) -> tuple[int, int]:
    # l ascending; at equal l the natural-parity block first
    return (ir.l, 0 if ir.is_natural else 1)


_LEGACY_FIELDS = {"inv_feats": Irrep(0, 1), "vec_feats": Irrep(1, -1), "equiv_feats": Irrep(2, 1)}


class IrrepFeatures:
    """Per-atom equivariant features, one ``(N, 2l+1, C_ir)`` block per irrep.

    Generalizes the old fixed-field ``LambdaFeatures`` (``inv_feats`` / ``vec_feats`` /
    ``equiv_feats``) to any set of irreps while keeping those names as properties, so code
    written against the old container keeps working:

    * ``inv_feats``   -> the ``0e`` block squeezed to ``(N, C0)``
    * ``vec_feats``   -> the ``1o`` block ``(N, 3, C1)``, or ``None``
    * ``equiv_feats`` -> the ``2e`` block ``(N, 5, C2)``

    The same keywords are accepted by the constructor, so ``LambdaFeatures(inv_feats=...,
    equiv_feats=..., ...)`` builds one.

    Bookkeeping that travels with the features: ``species_idx`` and ``batch_idx`` ``(N,)``, and
    the ``edge_index`` ``(2, E)`` they were built on (row 0 the center, row 1 the neighbor) and, for
    a periodic graph, ``edge_offsets`` ``(E, 3)`` (the Cartesian image offset of the row-1 atom, see
    :mod:`bb.graph.periodic`), so a
    downstream consumer -- message passing, a pair head -- reuses the same graph.
    """

    __slots__ = ("_blocks", "species_idx", "batch_idx", "edge_index", "edge_offsets")

    def __init__(
        self,
        blocks: Mapping[IrrepLike, torch.Tensor] | None = None,
        *,
        species_idx: torch.Tensor | None = None,
        batch_idx: torch.Tensor | None = None,
        edge_index: torch.Tensor | None = None,
        edge_offsets: torch.Tensor | None = None,
        inv_feats: torch.Tensor | None = None,
        vec_feats: torch.Tensor | None = None,
        equiv_feats: torch.Tensor | None = None,
    ) -> None:
        parsed: dict[Irrep, torch.Tensor] = {}
        for key, value in (blocks or {}).items():
            parsed[Irrep.parse(key)] = value
        if inv_feats is not None:
            parsed[Irrep(0, 1)] = inv_feats.unsqueeze(1) if inv_feats.dim() == 2 else inv_feats
        if vec_feats is not None:
            parsed[Irrep(1, -1)] = vec_feats
        if equiv_feats is not None:
            parsed[Irrep(2, 1)] = equiv_feats
        for ir, t in parsed.items():
            if t.dim() != 3 or t.shape[1] != ir.dim:
                raise ValueError(
                    f"block {ir} must be (N, {ir.dim}, C), got {tuple(t.shape)}"
                )
        self._blocks = {ir: parsed[ir] for ir in sorted(parsed, key=_sort_key)}
        self.species_idx = species_idx
        self.batch_idx = batch_idx
        self.edge_index = edge_index
        self.edge_offsets = edge_offsets

    # ---------------------------------------------------------------- lookup
    def _resolve(self, key) -> Irrep | None:
        if isinstance(key, int):
            matches = [ir for ir in self._blocks if ir.l == key]
            if len(matches) > 1:
                raise KeyError(
                    f"l={key} is ambiguous here ({', '.join(map(str, matches))}); "
                    f"ask for the irrep, e.g. '{matches[0]}'"
                )
            return matches[0] if matches else None
        ir = Irrep.parse(key)
        return ir if ir in self._blocks else None

    def __getitem__(self, key) -> torch.Tensor:
        ir = self._resolve(key)
        if ir is None:
            raise KeyError(f"no {key} block; have {self.irreps}")
        return self._blocks[ir]

    def get(self, key, default=None):
        ir = self._resolve(key)
        return default if ir is None else self._blocks[ir]

    def __contains__(self, key) -> bool:
        try:
            return self._resolve(key) is not None
        except KeyError:
            return True

    def __iter__(self) -> Iterator[Irrep]:
        return iter(self._blocks)

    def __len__(self) -> int:
        return len(self._blocks)

    def keys(self):
        return self._blocks.keys()

    def items(self):
        return self._blocks.items()

    def values(self):
        return self._blocks.values()

    @property
    def blocks(self) -> dict[Irrep, torch.Tensor]:
        return dict(self._blocks)

    @property
    def irreps(self) -> Irreps:
        return Irreps([(t.shape[-1], ir) for ir, t in self._blocks.items()])

    @property
    def widths(self) -> dict[Irrep, int]:
        return {ir: t.shape[-1] for ir, t in self._blocks.items()}

    @property
    def feature_dims(self) -> dict[int, int]:
        """``{l: width}`` -- the old featurizer convention (natural-parity blocks only)."""
        return {ir.l: t.shape[-1] for ir, t in self._blocks.items() if ir.is_natural}

    @property
    def n_atoms(self) -> int:
        for t in self._blocks.values():
            return t.shape[0]
        return 0 if self.species_idx is None else int(self.species_idx.shape[0])

    # ---------------------------------------------------------------- legacy fields
    @property
    def inv_feats(self) -> torch.Tensor | None:
        t = self._blocks.get(Irrep(0, 1))
        return None if t is None else t[:, 0, :]

    @inv_feats.setter
    def inv_feats(self, value: torch.Tensor | None) -> None:
        self._set(Irrep(0, 1), None if value is None else value.unsqueeze(1))

    @property
    def vec_feats(self) -> torch.Tensor | None:
        return self._blocks.get(Irrep(1, -1))

    @vec_feats.setter
    def vec_feats(self, value: torch.Tensor | None) -> None:
        self._set(Irrep(1, -1), value)

    @property
    def equiv_feats(self) -> torch.Tensor | None:
        return self._blocks.get(Irrep(2, 1))

    @equiv_feats.setter
    def equiv_feats(self, value: torch.Tensor | None) -> None:
        self._set(Irrep(2, 1), value)

    def _set(self, ir: Irrep, value: torch.Tensor | None) -> None:
        blocks = dict(self._blocks)
        if value is None:
            blocks.pop(ir, None)
        else:
            blocks[ir] = value
        self._blocks = {k: blocks[k] for k in sorted(blocks, key=_sort_key)}

    # ---------------------------------------------------------------- construction
    def replace(self, blocks: Mapping[IrrepLike, torch.Tensor | None] | None = None, **meta) -> "IrrepFeatures":
        """A copy with some blocks replaced (``None`` drops a block) and/or metadata changed.

        The old ``LambdaFeatures`` field names work as keywords too, so code written as
        ``dataclasses.replace(feats, inv_feats=x)`` becomes ``feats.replace(inv_feats=x)``
        (``inv_feats`` is ``(N, C0)``; ``vec_feats`` / ``equiv_feats`` are the ``1o`` / ``2e``
        blocks). On Python >= 3.13 ``copy.replace(feats, ...)`` is the same call.
        """
        new = dict(self._blocks)
        updates = dict(blocks or {})
        for name, ir in _LEGACY_FIELDS.items():
            if name in meta:
                value = meta.pop(name)
                if name == "inv_feats" and value is not None and value.dim() == 2:
                    value = value.unsqueeze(1)
                updates[ir] = value
        for key, value in updates.items():
            ir = Irrep.parse(key)
            if value is None:
                new.pop(ir, None)
            else:
                new[ir] = value
        kw = dict(species_idx=self.species_idx, batch_idx=self.batch_idx, edge_index=self.edge_index,
                  edge_offsets=self.edge_offsets)
        unknown = set(meta) - set(kw)
        if unknown:
            raise TypeError(f"IrrepFeatures.replace got unexpected keyword(s) {sorted(unknown)}")
        kw.update(meta)
        return IrrepFeatures(new, **kw)

    def __replace__(self, **changes) -> "IrrepFeatures":
        return self.replace(**changes)

    def cat(self, *others: "IrrepFeatures | Mapping[IrrepLike, torch.Tensor]") -> "IrrepFeatures":
        """Concatenate channels irrep by irrep. Irreps missing from some inputs are kept as-is."""
        merged: dict[Irrep, list[torch.Tensor]] = {ir: [t] for ir, t in self._blocks.items()}
        for other in others:
            items = other.items() if isinstance(other, IrrepFeatures) else (
                (Irrep.parse(k), v) for k, v in other.items()
            )
            for ir, t in items:
                merged.setdefault(ir, []).append(t)
        return self.replace({ir: (ts[0] if len(ts) == 1 else torch.cat(ts, dim=-1)) for ir, ts in merged.items()})

    def select(self, keys: Iterable[IrrepLike]) -> "IrrepFeatures":
        want = {Irrep.parse(k) if not isinstance(k, int) else self._resolve(k) for k in keys}
        return self.replace({ir: None for ir in self._blocks if ir not in want})

    def map(self, fn) -> "IrrepFeatures":
        return self.replace({ir: fn(ir, t) for ir, t in self._blocks.items()})

    def to(self, *args, **kwargs) -> "IrrepFeatures":
        return self.replace(
            {ir: t.to(*args, **kwargs) for ir, t in self._blocks.items()},
        )

    def flatten(self) -> torch.Tensor:
        """``(N, sum_ir C_ir (2l+1))`` in e3nn ``mul_ir`` layout (channel-major per irrep)."""
        return torch.cat(
            [t.transpose(1, 2).reshape(t.shape[0], -1) for t in self._blocks.values()], dim=-1
        )

    def __repr__(self) -> str:
        return f"IrrepFeatures({self.irreps}, n_atoms={self.n_atoms})"
