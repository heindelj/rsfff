"""Cartesian <-> irrep conversions for low-rank tensors.

Conventions, shared by every backend:

* A ``1o`` block's three components *are* Cartesian ``(x, y, z)`` (e3nn's real-SH basis maps
  ``l=1`` onto the coordinate axes), so a vector readout needs no conversion.
* A symmetric rank-2 tensor is ``1x0e + 1x2e`` (6 numbers). Voigt order is
  ``xx yy zz yz xz xy`` with plain matrix entries (no factor of 2 on the off-diagonals).
  :func:`irrep6_to_voigt` is the fixed change of basis; it equals e3nn's
  ``CartesianTensor("ij=ji")`` and the backend's ``irrep6_to_voigt()``.
* The ``0e`` component of a symmetric tensor maps to ``(1/sqrt 3) I``, not ``I``: shifting the
  irrep scalar by ``s`` moves every eigenvalue by ``s/sqrt 3``. Positivity constraints are
  therefore applied in Cartesian space (see :mod:`bb.heads.transforms`).
"""

from __future__ import annotations

import math
from functools import lru_cache

import torch

__all__ = [
    "irrep6_to_voigt",
    "voigt_to_irrep6",
    "irreps_to_voigt",
    "voigt_to_irreps",
    "voigt_to_matrix",
    "matrix_to_voigt",
    "irrep2_to_traceless_matrix",
    "min_eig_sym3x3",
]


@lru_cache(maxsize=None)
def _irrep6_to_voigt_f64() -> torch.Tensor:
    from .backend import E3nnBackend

    b = E3nnBackend()
    w0 = b.wigner_3j(1, 1, 0).to(torch.float64)
    w2 = b.wigner_3j(1, 1, 2).to(torch.float64)
    basis = [w0[:, :, 0]] + [math.sqrt(5.0) * w2[:, :, m] for m in range(5)]
    rows = [torch.stack((B[0, 0], B[1, 1], B[2, 2], B[1, 2], B[0, 2], B[0, 1])) for B in basis]
    return torch.stack(rows, dim=0).t().contiguous()            # (6_voigt, 6_irrep)


def irrep6_to_voigt(backend=None) -> torch.Tensor:
    """``(6_voigt, 6_irrep)`` map from ``[0e | 2e]`` coefficients to Voigt. Default dtype.

    ``voigt = irrep6 @ irrep6_to_voigt().T``. Pass a backend to build it from that backend's
    own ``wigner_3j`` (identical values; keeps a cue-only process off e3nn).
    """
    if backend is not None:
        return backend.irrep6_to_voigt()
    return _irrep6_to_voigt_f64().to(torch.get_default_dtype())


def voigt_to_irrep6(backend=None) -> torch.Tensor:
    """Inverse of :func:`irrep6_to_voigt`, laid out ``(6_voigt, 6_irrep)``.

    ``irrep6 = voigt @ voigt_to_irrep6()``; columns ``1:`` are the ``2e`` block.
    """
    M = irrep6_to_voigt(backend).to(torch.float64)
    return torch.linalg.inv(M).t().contiguous().to(torch.get_default_dtype())


def irreps_to_voigt(x0: torch.Tensor, x2: torch.Tensor, backend=None) -> torch.Tensor:
    """``x0 (..., 1)`` and ``x2 (..., 5)`` -> Voigt ``(..., 6)``."""
    M = irrep6_to_voigt(backend).to(device=x2.device, dtype=x2.dtype)
    return torch.cat((x0, x2), dim=-1) @ M.t()


def voigt_to_irreps(v: torch.Tensor, backend=None) -> tuple[torch.Tensor, torch.Tensor]:
    """Voigt ``(..., 6)`` -> ``(x0 (..., 1), x2 (..., 5))``."""
    M = voigt_to_irrep6(backend).to(device=v.device, dtype=v.dtype)
    out = v @ M
    return out[..., :1], out[..., 1:]


def voigt_to_matrix(values: torch.Tensor) -> torch.Tensor:
    """Expand ``(..., 6)`` vectors in ``xx yy zz yz xz xy`` order to ``(..., 3, 3)``.

    Tensor inputs keep their own dtype; list/array inputs adopt the default dtype.
    """
    if not isinstance(values, torch.Tensor):
        values = torch.as_tensor(values, dtype=torch.get_default_dtype())
    if values.shape[-1] != 6:
        raise ValueError(
            f"Expected last dimension 6 for xx yy zz yz xz xy data, got {tuple(values.shape)}"
        )
    xx, yy, zz, yz, xz, xy = (values[..., i] for i in range(6))
    row_x = torch.stack((xx, xy, xz), dim=-1)
    row_y = torch.stack((xy, yy, yz), dim=-1)
    row_z = torch.stack((xz, yz, zz), dim=-1)
    return torch.stack((row_x, row_y, row_z), dim=-2)


def matrix_to_voigt(matrix: torch.Tensor) -> torch.Tensor:
    """Collapse symmetric ``(..., 3, 3)`` matrices to Voigt ``(..., 6)`` (upper entries read)."""
    if not isinstance(matrix, torch.Tensor):
        matrix = torch.as_tensor(matrix, dtype=torch.get_default_dtype())
    if matrix.shape[-2:] != (3, 3):
        raise ValueError(f"Expected trailing shape (3, 3), got {tuple(matrix.shape)}")
    return torch.stack(
        (
            matrix[..., 0, 0], matrix[..., 1, 1], matrix[..., 2, 2],
            matrix[..., 1, 2], matrix[..., 0, 2], matrix[..., 0, 1],
        ),
        dim=-1,
    )


def irrep2_to_traceless_matrix(x2: torch.Tensor, backend=None) -> torch.Tensor:
    """``2e`` coefficients ``(..., 5)`` -> traceless symmetric ``(..., 3, 3)``.

    Contractions of two such matrices (``A_ab B_ab``) are invariant whatever the normalization
    of the 5-component basis, which makes this the safe form for building invariants from
    rank-2 quantities that arrive in a project-specific spherical convention.
    """
    return voigt_to_matrix(irreps_to_voigt(torch.zeros_like(x2[..., :1]), x2, backend))


def min_eig_sym3x3(A: torch.Tensor) -> torch.Tensor:
    """Smallest eigenvalue of a batch of symmetric 3x3 matrices, in closed form.

    Trigonometric (Smith) solution of the characteristic cubic. Pure torch, differentiable,
    device-agnostic. Deliberately avoids ``torch.linalg.eigvalsh``, whose batched cuSOLVER kernel
    raises ``CUSOLVER_STATUS_INVALID_VALUE`` for large batches and is unimplemented on MPS.
    ``A`` is assumed symmetric; only the upper entries are read.
    """
    a00 = A[..., 0, 0]; a11 = A[..., 1, 1]; a22 = A[..., 2, 2]
    a01 = A[..., 0, 1]; a02 = A[..., 0, 2]; a12 = A[..., 1, 2]
    p1 = a01 * a01 + a02 * a02 + a12 * a12
    q = (a00 + a11 + a22) / 3.0
    d0 = a00 - q; d1 = a11 - q; d2 = a22 - q
    p2 = d0 * d0 + d1 * d1 + d2 * d2 + 2.0 * p1
    # p == 0 only for an isotropic (triple-root) matrix; the clamp keeps the division and the
    # sqrt gradient finite there, and the result correctly reduces to q.
    p = torch.sqrt(torch.clamp(p2 / 6.0, min=1e-30))
    b00 = d0 / p; b11 = d1 / p; b22 = d2 / p
    b01 = a01 / p; b02 = a02 / p; b12 = a12 / p
    detB = (b00 * (b11 * b22 - b12 * b12)
            - b01 * (b01 * b22 - b12 * b02)
            + b02 * (b01 * b12 - b11 * b02))
    # r in [-1, 1]; clamp strictly inside so that at a double root (r -> +/-1, where acos'
    # diverges) the 0*inf does not poison the backward pass with NaNs.
    r = torch.clamp(detB / 2.0, min=-1.0 + 1e-6, max=1.0 - 1e-6)
    phi = torch.acos(r) / 3.0
    # Eigenvalues are q + 2p*cos(phi + 2*pi*k/3); the k=1 branch is the smallest.
    return q + 2.0 * p * torch.cos(phi + (2.0 * math.pi / 3.0))
