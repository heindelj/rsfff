"""Two interchangeable equivariant backends: ``e3nn`` and ``cuequivariance``.

Everything in bb that touches O(3) goes through a small set of primitives:

  * ``spherical_harmonics(vectors, l_max)`` -- component-normalized real SH, ``(E, (l_max+1)^2)``
  * ``wigner_3j(l1, l2, l3)``               -- unit-Frobenius CG coupling tensor (e3nn convention)
  * ``irrep6_to_voigt()``                   -- the fixed ``(0e + 2e) -> Voigt(6)`` map
  * ``make_weighted_bispectrum(...)``       -- a trainable nu=3 lambda-bispectrum

The two are a *faithful* implementation swap, verified numerically:

  * cue ``SphericalHarmonics`` == e3nn ``spherical_harmonics(normalization="component")`` to
    ~1e-16, and
  * ``cue.clebsch_gordan(O3(l1), O3(l2), O3(l3))`` renormalized to unit Frobenius norm ==
    ``e3nn.o3.wigner_3j(l1, l2, l3)`` to ~1e-16 *with matching signs*.

So the density, the nu=2 power spectrum, message passing and every readout give the same
numbers on either backend, ``irrep6_to_voigt`` is identical (and matches the historical
``e3nn.io.CartesianTensor("ij=ji")`` constant, so old checkpoints still load), and only the
*learnable* bispectrum weights differ between them (random init, trained per model).

Each backend imports **only its own** library, lazily. (Import-order caveat: on some OpenMP
builds importing ``cuequivariance_torch`` *before* ``e3nn`` in the same process segfaults; normal
use only touches one library, so this bites only cross-backend tests, which import e3nn first.)
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod

import torch
import torch.nn as nn

__all__ = ["EquivariantBackend", "E3nnBackend", "CueBackend", "get_backend", "resolve_backend"]


class EquivariantBackend(ABC):
    """Minimal set of O(3) primitives shared by the featurizers, message passing and heads."""

    name: str

    @abstractmethod
    def spherical_harmonics(
        self, vectors: torch.Tensor, l_max: int, *, normalize: bool = True
    ) -> torch.Tensor:
        """Real spherical harmonics, component-normalized. ``(E, (l_max+1)**2)``."""

    @abstractmethod
    def wigner_3j(self, l1: int, l2: int, l3: int) -> torch.Tensor:
        """CG coupling ``(2l1+1, 2l2+1, 2l3+1)``, unit Frobenius norm (e3nn convention)."""

    def irrep6_to_voigt(self) -> torch.Tensor:
        """Constant ``(1x0e + 1x2e) -> Voigt(6)`` map, ``(6_voigt, 6_irrep)``.

        Built purely from ``wigner_3j``: the Cartesian image of each irrep basis vector is
        ``sqrt(2L+1) * wigner_3j(1, 1, L)[:, :, m]`` (verified against
        ``e3nn.io.CartesianTensor("ij=ji")``). Voigt order ``xx yy zz yz xz xy``, matrix entries
        (no factor of 2). Identical across backends.
        """
        w0 = self.wigner_3j(1, 1, 0).to(torch.float64)          # (3, 3, 1)
        w2 = self.wigner_3j(1, 1, 2).to(torch.float64)          # (3, 3, 5)
        basis = [math.sqrt(1.0) * w0[:, :, 0]] + [
            math.sqrt(5.0) * w2[:, :, m] for m in range(5)
        ]                                                        # 6 x (3, 3)
        rows = [
            torch.stack((B[0, 0], B[1, 1], B[2, 2], B[1, 2], B[0, 2], B[0, 1]))
            for B in basis
        ]
        M = torch.stack(rows, dim=0)                            # (6_irrep, 6_voigt)
        return M.t().contiguous().to(torch.get_default_dtype())  # (6_voigt, 6_irrep)

    @abstractmethod
    def make_weighted_bispectrum(self, **kwargs) -> nn.Module:
        """Trainable nu=3 lambda-bispectrum: ``forward(A, species_idx) -> {lam: tensor}``."""

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"

    # Backends hold only caches and library handles: copies share the instance, and pickling
    # (``torch.save(model)``) rebuilds it by name.
    def __deepcopy__(self, memo):
        return self

    def __reduce__(self):
        return (get_backend, (self.name,))


class E3nnBackend(EquivariantBackend):
    name = "e3nn"

    def __init__(self) -> None:
        from e3nn import o3  # lazy: never import e3nn unless this backend is built

        self._o3 = o3
        self._sh_irreps: dict[int, object] = {}
        self._w3j: dict[tuple[int, int, int], torch.Tensor] = {}

    def spherical_harmonics(self, vectors, l_max, *, normalize=True):
        irreps = self._sh_irreps.get(l_max)
        if irreps is None:
            irreps = self._o3.Irreps.spherical_harmonics(l_max)
            self._sh_irreps[l_max] = irreps
        return self._o3.spherical_harmonics(
            irreps, vectors, normalize=normalize, normalization="component"
        )

    def wigner_3j(self, l1, l2, l3):
        key = (l1, l2, l3)
        w = self._w3j.get(key)
        if w is None:
            w = self._o3.wigner_3j(l1, l2, l3).to(torch.float64)
            self._w3j[key] = w
        return w.to(torch.get_default_dtype())

    def make_weighted_bispectrum(self, **kwargs):
        from ..features.bispectrum import E3nnWeightedBispectrum

        kwargs.pop("implementation", None)
        kwargs.pop("device", None)
        return E3nnWeightedBispectrum(backend=self, **kwargs)


class CueBackend(EquivariantBackend):
    name = "cue"

    def __init__(self, device: torch.device | str | None = None) -> None:
        import cuequivariance as cue          # lazy: only when this backend is built
        import cuequivariance_torch as cuet

        self._cue = cue
        self._cuet = cuet
        self._device = None if device is None else torch.device(device)
        self._sh: dict[tuple, nn.Module] = {}
        self._w3j: dict[tuple[int, int, int], torch.Tensor] = {}

    def spherical_harmonics(self, vectors, l_max, *, normalize=True):
        # cue has no MPS kernel; force the "naive" kernel anywhere but CUDA (on CUDA
        # method=None lets cue pick the fast kernel).
        method = "naive" if vectors.device.type != "cuda" else None
        key = (l_max, bool(normalize), vectors.device.type)
        sh = self._sh.get(key)
        if sh is None:
            sh = self._cuet.SphericalHarmonics(
                ls=list(range(l_max + 1)), normalize=normalize, method=method
            )
            self._sh[key] = sh
        return sh(vectors)

    def wigner_3j(self, l1, l2, l3):
        import numpy as np

        key = (l1, l2, l3)
        w = self._w3j.get(key)
        if w is None:
            ir = lambda l: self._cue.O3(l, (-1) ** l)  # parity (-1)^l, matches SH
            cg = np.asarray(self._cue.clebsch_gordan(ir(l1), ir(l2), ir(l3)))
            # cg has shape (n_paths, d1, d2, d3); n_paths == 0 when (l1, l2, l3) do not
            # couple (parity/triangle), matching e3nn's all-zeros wigner_3j.
            if cg.shape[0] == 0:
                w = torch.zeros(2 * l1 + 1, 2 * l2 + 1, 2 * l3 + 1, dtype=torch.float64)
            else:
                t = torch.tensor(cg[0], dtype=torch.float64)
                w = t / t.norm()                        # unit Frobenius -> e3nn convention
            self._w3j[key] = w
        return w.to(torch.get_default_dtype())

    def make_weighted_bispectrum(
        self,
        *,
        implementation: str = "sym_contraction",
        method: str = "auto",
        device: torch.device | str | None = None,
        **kwargs,
    ):
        from ..features.bispectrum import LearnableBispectrum, LearnableSymContraction

        dev = torch.device(device) if device is not None else self._device
        resolved = self._resolve_method(method, dev)
        # The two cue kernels take different degree kwargs; route accordingly.
        degrees = kwargs.pop("degrees", (3,))
        contraction_degree = kwargs.pop("contraction_degree", 3)
        if implementation == "descriptor":
            return LearnableBispectrum(method=resolved, degrees=degrees, **kwargs)
        if implementation == "sym_contraction":
            # SymmetricContraction takes `method=None` to auto-pick; map "" -> None.
            return LearnableSymContraction(
                method=(resolved or None), contraction_degree=contraction_degree, **kwargs
            )
        raise ValueError(
            f"unknown cue bispectrum implementation {implementation!r}; "
            "use 'sym_contraction' or 'descriptor'"
        )

    @staticmethod
    def _resolve_method(method: str, device: torch.device | None) -> str:
        if method != "auto":
            return method
        on_cuda = (device is not None and device.type == "cuda") or (
            device is None and torch.cuda.is_available()
        )
        return "" if on_cuda else "naive"


def get_backend(name: str, *, device: torch.device | str | None = None) -> EquivariantBackend:
    """Build a backend by name: ``"e3nn"`` (default) or ``"cue"``."""
    name = (name or "e3nn").lower()
    if name == "e3nn":
        return E3nnBackend()
    if name in ("cue", "cuequivariance"):
        return CueBackend(device=device)
    raise ValueError(f"unknown equivariant backend {name!r}; use 'e3nn' or 'cue'")


def resolve_backend(backend: "EquivariantBackend | str | None") -> EquivariantBackend:
    """Accept an :class:`EquivariantBackend` instance or a name string."""
    if backend is None or isinstance(backend, str):
        return get_backend(backend or "e3nn")
    return backend
