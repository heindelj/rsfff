"""Edge (bond) frames for the edge cluster expansion.

Each directed edge gets a rotation ``R_e`` that maps its unit vector onto the backend's polar
axis (the axis whose spherical harmonics are nonzero only at m = 0). In that frame the residual
symmetry is rotation about the bond, so real-basis components pair into complex numbers
``z_m = c[l, +m] + i c[l, -m]`` that pick up a phase ``exp(i m gamma)`` under a rotation by
``gamma`` about the axis.

The axis and the pairing are *calibrated* from the backend rather than assumed
(:func:`calibrate`). For e3nn (and cue, which reproduces e3nn's harmonics) the polar axis is y.

The residual azimuth of ``R_e`` is a gauge: every ECE output is invariant under it.
:func:`edge_frames` therefore uses two charts (one away from each pole), so it is never
singular, and switching charts changes no value or gradient.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import torch

from .backend import EquivariantBackend, resolve_backend

__all__ = [
    "FrameConvention",
    "E3NN",
    "MIndex",
    "calibrate",
    "edge_frames",
    "frame_convention",
    "rotation_about",
    "wigner_d_recursive",
]

ShFn = Callable[[torch.Tensor, int], torch.Tensor]


# --------------------------------------------------------------------------- #
# Calibration
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class FrameConvention:
    axis: tuple[float, float, float]
    """Polar axis: ``Y_l(axis)`` is nonzero only at the m = 0 index."""
    perp: tuple[float, float, float]
    """A fixed axis perpendicular to ``axis`` (used for the second chart)."""


#: The convention of e3nn's (and cue's) component-normalized real harmonics.
E3NN = FrameConvention(axis=(0.0, 1.0, 0.0), perp=(0.0, 0.0, 1.0))


def _sh_fn(backend: "EquivariantBackend | str | None") -> ShFn:
    be = resolve_backend(backend)
    return lambda v, l_max: be.spherical_harmonics(v, l_max)


def rotation_about(axis: torch.Tensor, angle: torch.Tensor) -> torch.Tensor:
    """Rotation matrices about a fixed unit ``axis`` by ``angle`` (any shape) -> ``(..., 3, 3)``."""
    k = _skew(axis.expand(*angle.shape, 3))
    eye = torch.eye(3, dtype=axis.dtype, device=axis.device)
    s, c = torch.sin(angle)[..., None, None], torch.cos(angle)[..., None, None]
    return eye + s * k + (1.0 - c) * (k @ k)


def calibrate(backend: "EquivariantBackend | str | None" = "e3nn", l_max: int = 4,
              tol: float = 1e-10) -> FrameConvention:
    """Find the polar axis and verify the (+m, -m) pairing for a backend.

    Raises if no coordinate axis is polar, or if a pair does not rotate as ``exp(+-i m gamma)``
    about it -- in that case the pairing in :mod:`bb.features.edge` must be adapted for that
    backend.
    """
    sh = _sh_fn(backend)
    dt = torch.float64
    basis = torch.eye(3, dtype=dt)
    polar = None
    for i in range(3):
        y = sh(basis[i:i + 1], l_max)[0]
        mask = torch.ones_like(y, dtype=torch.bool)
        for l in range(l_max + 1):
            mask[l * l + l] = False
        if y[mask].abs().max() < tol:
            polar = i
            break
    if polar is None:
        raise RuntimeError("calibrate: no coordinate axis is polar for this backend")
    axis = basis[polar]
    perp = basis[(polar + 1) % 3]

    gamma = torch.tensor(0.37, dtype=dt)
    rot = rotation_about(axis, gamma)
    v = torch.tensor([[0.3, -0.5, 0.8]], dtype=dt)
    a, b = sh(v, l_max)[0], sh(v @ rot.T, l_max)[0]
    for l in range(1, l_max + 1):
        for m in range(1, l + 1):
            za = complex(a[l * l + l + m], a[l * l + l - m])
            zb = complex(b[l * l + l + m], b[l * l + l - m])
            ph = complex(math.cos(m * gamma), math.sin(m * gamma))
            if not (abs(zb - za * ph) < 1e-8 or abs(zb - za * ph.conjugate()) < 1e-8):
                raise RuntimeError(f"calibrate: (l={l}, m={m}) pair does not rotate as exp(i m g)")
    return FrameConvention(tuple(axis.tolist()), tuple(perp.tolist()))


_CONVENTIONS: dict[str, FrameConvention] = {}


def frame_convention(backend: "EquivariantBackend | str | None" = "e3nn") -> FrameConvention:
    """:func:`calibrate`, cached per backend name."""
    be = resolve_backend(backend)
    conv = _CONVENTIONS.get(be.name)
    if conv is None:
        conv = _CONVENTIONS[be.name] = calibrate(be)
    return conv


# --------------------------------------------------------------------------- #
# Frames
# --------------------------------------------------------------------------- #
def _skew(v: torch.Tensor) -> torch.Tensor:
    z = torch.zeros_like(v[..., 0])
    x, y, w = v[..., 0], v[..., 1], v[..., 2]
    return torch.stack(
        [torch.stack([z, -w, y], -1), torch.stack([w, z, -x], -1), torch.stack([-y, x, z], -1)], -2
    )


def _align(u: torch.Tensor, a: torch.Tensor, eps: float) -> torch.Tensor:
    """Rodrigues rotation taking unit vectors ``u`` onto ``a``; valid for ``u . a > -1``."""
    k = _skew(torch.cross(u, a.expand_as(u), dim=-1))
    c = (u * a).sum(-1)
    eye = torch.eye(3, dtype=u.dtype, device=u.device)
    return eye + k + (k @ k) / (1.0 + c).clamp_min(eps)[..., None, None]


def edge_frames(
    unit: torch.Tensor,
    convention: FrameConvention = E3NN,
    twist: torch.Tensor | None = None,
) -> torch.Tensor:
    """Rotations ``R_e`` with ``R_e @ unit_e = axis``. Shape ``(E, 3, 3)``.

    Two charts: Rodrigues onto ``axis`` where ``unit . axis >= 0``, else Rodrigues onto
    ``-axis`` followed by a pi rotation about ``perp``. ``twist`` (radians, ``(E,)``) adds an
    extra rotation about the axis; outputs must not depend on it (the gauge-invariance tests use
    it).
    """
    a = torch.tensor(convention.axis, dtype=unit.dtype, device=unit.device)
    b = torch.tensor(convention.perp, dtype=unit.dtype, device=unit.device)
    eps = 1e-3  # only guards the branch that is not selected
    r_plus = _align(unit, a, eps)
    flip = 2.0 * torch.outer(b, b) - torch.eye(3, dtype=unit.dtype, device=unit.device)
    r_minus = flip @ _align(unit, -a, eps)
    c = (unit * a).sum(-1)[..., None, None]
    rot = torch.where(c >= 0, r_plus, r_minus)
    if twist is not None:
        rot = rotation_about(a, twist.to(unit.dtype)) @ rot
    return rot


# --------------------------------------------------------------------------- #
# Wigner-D by recursive Clebsch-Gordan coupling (1 x (l-1) -> l)
# --------------------------------------------------------------------------- #
def wigner_d_recursive(
    rot: torch.Tensor, l_max: int, backend: "EquivariantBackend | str | None" = "e3nn"
) -> list[torch.Tensor]:
    """Real Wigner-D blocks ``[D^0, ..., D^l_max]`` for rotations ``(..., 3, 3)``.

    D^1 is the rotation matrix in the backend's l = 1 basis; for e3nn/cue that basis is
    ``(x, y, z)``, so ``D^1 = R``. Uses the recursion of Xu, Xie & Hu (arXiv:2607.10664,
    Eq. 13): ``D^l = (2l+1) K^T (D^1 (x) D^{l-1}) K`` with ``K = wigner_3j(1, l-1, l)``.
    """
    be = resolve_backend(backend)
    batch = rot.shape[:-2]
    out = [torch.ones(*batch, 1, 1, dtype=rot.dtype, device=rot.device)]
    if l_max >= 1:
        out.append(rot)
    for l in range(2, l_max + 1):
        k = be.wigner_3j(1, l - 1, l).to(dtype=rot.dtype, device=rot.device)
        d = torch.einsum("abM,...ac,...bd,cdN->...MN", k, rot, out[-1], k)
        out.append((2 * l + 1) * d)
    return out


# --------------------------------------------------------------------------- #
# m-index bookkeeping
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class MIndex:
    """Flat indices into a ``(l_max+1)**2`` real-SH vector, grouped by m.

    ``zero[l]`` is the m = 0 index for l = 0..L. For m >= 1, ``plus[m]`` and ``minus[m]`` hold the
    indices of (l, +m) and (l, -m) for l = m..L, so that ``z_{l,m} = x[plus] + i x[minus]``.
    """

    l_max: int
    zero: torch.Tensor
    plus: tuple[torch.Tensor, ...]
    minus: tuple[torch.Tensor, ...]

    @staticmethod
    def build(l_max: int) -> "MIndex":
        zero = torch.tensor([l * l + l for l in range(l_max + 1)])
        plus = [torch.empty(0, dtype=torch.long)]
        minus = [torch.empty(0, dtype=torch.long)]
        for m in range(1, l_max + 1):
            plus.append(torch.tensor([l * l + l + m for l in range(m, l_max + 1)]))
            minus.append(torch.tensor([l * l + l - m for l in range(m, l_max + 1)]))
        return MIndex(l_max, zero, tuple(plus), tuple(minus))
