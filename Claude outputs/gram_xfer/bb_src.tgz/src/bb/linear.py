"""Least squares for models that are linear in their coefficients: E(R) = phi(R) . w.

Energies, forces and Hessians of such a model are all linear in ``w``, so every observation at
every geometry is one row of one regression problem: Hermite interpolation of a single smooth
function. This module builds those rows from any feature map (for example
:class:`bb.features.EdgeBodyOrderBasis`) and solves the ridge-regularized normal equations:

    rows = design_rows(phi, x, forces=True, hessian=True)      # dict of (n_rows, F) blocks
    ls = NormalEquations(F)
    ls.add(rows["energy"], E, sigma=sigma_E)                   # rows / sigma, targets / sigma
    ls.add(rows["forces"], F.reshape(-1), sigma=sigma_F)
    ls.add(rows["hessian"], hessian_upper(H), sigma=sigma_H)
    w = ls.solve(ridge=1e-8)

The normal matrix is dense, ``8 F^2`` bytes in float64 (10k features: 0.8 GB); rows are added
in blocks and only the columns a block touches are updated (``columns=``), so the cost is
``rows x active^2`` per block. The solve standardizes columns by their norm before adding
``ridge`` (so the regularization is scale-free) and drops columns no row touches.

:func:`nested_solve` fits a sequence of truncations (e.g. body order 0, <= 1, <= 2, ...) on the
same data. The change in prediction from one truncation to the next is the part of the data the
new order explains and the lower ones cannot: a unique, non-redundant attribution, whatever
linear dependences the columns have.

Nothing here is specific to energies; any linear observation (dipole components of a linear
charge model, say) uses the same rows.
"""

from __future__ import annotations

from typing import Callable

import torch

__all__ = ["design_rows", "hessian_upper", "active_columns", "NormalEquations", "nested_solve", "order_ridge"]


def hessian_upper(H: torch.Tensor) -> torch.Tensor:
    """Upper triangle (with diagonal) of ``(D, D)``, off-diagonal entries scaled by sqrt(2) so
    the Euclidean norm of the vector is the Frobenius norm of the matrix."""
    D = H.shape[-1]
    iu = torch.triu_indices(D, D, device=H.device)
    w = torch.where(iu[0] == iu[1], 1.0, 2**0.5).to(H.dtype)
    return H[..., iu[0], iu[1]] * w


def active_columns(phi: Callable, x: torch.Tensor, n_probe: int = 2, scale: float = 0.05,
                   seed: int = 0) -> torch.Tensor:
    """Columns that are not structurally zero for this system (nonzero at perturbed geometries)."""
    g = torch.Generator().manual_seed(seed)
    nz = None
    for _ in range(n_probe):
        v = phi(x + scale * torch.randn(x.shape, generator=g, dtype=x.dtype).to(x.device)).detach()
        cur = v.reshape(-1) != 0
        nz = cur if nz is None else nz | cur
    return nz.nonzero().squeeze(-1)


def design_rows(phi: Callable, x: torch.Tensor, *, energy: bool = True, forces: bool = True,
                hessian: bool = False, columns: torch.Tensor | None = None) -> dict:
    """Rows of the linear model at one geometry (flat positions ``x``, shape ``(3N,)``).

    ``phi(x) -> (F,)``. Returns ``energy`` ``(1, F)``, ``forces`` ``(3N, F)`` (``-dphi/dx``) and
    ``hessian`` ``(3N(3N+1)/2, F)`` (:func:`hessian_upper` layout), restricted to ``columns``.
    """
    from torch.func import jacfwd, jvp

    def f(z):
        v = phi(z).reshape(-1)
        return v if columns is None else v[columns]

    out = {}
    if energy:
        out["energy"] = f(x).detach()[None]
    if forces or hessian:
        Jf = jacfwd(f)
        if forces:
            out["forces"] = -Jf(x).detach().T
        if hessian:
            D = x.numel()
            eye = torch.eye(D, dtype=x.dtype, device=x.device)
            K = torch.stack([jvp(Jf, (x,), (eye[i],))[1].detach() for i in range(D)], -1)  # (F, D, D)
            out["hessian"] = hessian_upper(K).T
    return out


class NormalEquations:
    """Accumulates ``G = A^T A`` and ``b = A^T y`` (weighted) for ``F`` coefficients."""

    def __init__(self, n_features: int, dtype=torch.float64, device=None):
        self.F = n_features
        self.G = torch.zeros(n_features, n_features, dtype=dtype, device=device)
        self.b = torch.zeros(n_features, dtype=dtype, device=device)
        self.yy = 0.0
        self.n_rows = 0

    def add(self, A: torch.Tensor, y: torch.Tensor, sigma: float = 1.0,
            columns: torch.Tensor | None = None) -> None:
        """Add rows ``A`` (``(n, F)``, or ``(n, len(columns))``) with targets ``y`` / ``sigma``."""
        A = A.to(self.G) / sigma
        y = y.reshape(-1).to(self.G) / sigma
        if columns is None:
            self.G += A.T @ A
            self.b += A.T @ y
        else:
            c = columns.to(self.G.device)
            self.G[c[:, None], c[None, :]] += A.T @ A
            self.b[c] += A.T @ y
        self.yy += float(y @ y)
        self.n_rows += A.shape[0]

    def merge(self, other: "NormalEquations") -> None:
        self.G += other.G
        self.b += other.b
        self.yy += other.yy
        self.n_rows += other.n_rows

    def solve(self, ridge: "float | torch.Tensor" = 1e-8, mask: torch.Tensor | None = None) -> torch.Tensor:
        """Ridge solution with standardized columns; ``mask`` restricts the columns used.

        Minimizes ``|A w - y|^2 + sum_f ridge_f G_ff w_f^2``; ``ridge`` is one number or one per
        column (e.g. growing with body order, so higher orders only take what lower ones cannot
        fit). Columns that no row touches (or outside ``mask``) get ``w = 0``.
        """
        d = self.G.diagonal().clone()
        keep = d > 0
        if mask is not None:
            keep &= mask.to(keep.device)
        idx = keep.nonzero().squeeze(-1)
        s = d[idx].sqrt()
        Gs = self.G[idx[:, None], idx[None, :]] if len(idx) < self.F else self.G.clone()
        Gs /= s[:, None]
        Gs /= s[None, :]
        if torch.is_tensor(ridge):
            Gs.diagonal().add_(ridge.to(Gs)[idx])
        else:
            Gs.diagonal().add_(ridge)
        bs = self.b[idx] / s
        u = _spd_solve(Gs, bs)
        w = torch.zeros(self.F, dtype=self.G.dtype, device=self.G.device)
        w[idx] = u / s
        return w

    def loss(self, w: torch.Tensor) -> float:
        """Weighted sum of squared residuals ``|A w - y|^2`` of the accumulated rows."""
        return float(w @ (self.G @ w) - 2 * (self.b @ w) + self.yy)


def _spd_solve(A: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Solve ``A x = b`` for symmetric positive definite ``A``; ``A`` is overwritten (on CPU the
    Cholesky factorization runs in place with SciPy, so no second copy of the matrix is made)."""
    if A.device.type == "cpu":
        try:
            import numpy as np
            from scipy.linalg import cho_factor, cho_solve
        except ImportError:
            pass
        else:
            try:
                c = cho_factor(A.numpy(), lower=True, overwrite_a=True, check_finite=False)
            except np.linalg.LinAlgError as err:
                raise RuntimeError("normal matrix is not positive definite; increase ridge") from err
            return torch.from_numpy(cho_solve(c, b.numpy(), check_finite=False)).to(b)
    L, info = torch.linalg.cholesky_ex(A)
    if int(info) != 0:
        raise RuntimeError("normal matrix is not positive definite; increase ridge")
    return torch.cholesky_solve(b[:, None], L)[:, 0]


def order_ridge(labels: torch.Tensor, base: float = 1e-8, factor: float = 100.0) -> torch.Tensor:
    """Per-column ridge ``base * factor**max(nu, 0)``: stronger shrinkage for higher orders."""
    return base * factor ** labels.clamp_min(0).to(torch.float64)


def nested_solve(ne: NormalEquations, labels: torch.Tensor, orders, ridge=1e-8) -> dict:
    """``{k: w_k}``: one solve per truncation ``labels <= k`` (labels < 0, e.g. element counts,
    are always included)."""
    out = {}
    for k in orders:
        out[k] = ne.solve(ridge, mask=(labels <= k))
    return out
