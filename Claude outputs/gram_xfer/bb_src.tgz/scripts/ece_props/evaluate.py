#!/usr/bin/env python
"""Evaluate a trained model on extxyz files: errors per quantity, predictions, parity plots.

    python scripts/ece_props/evaluate.py runs/ece_sqe/best.pt data/test.xyz [more.xyz ...] \
        [--out runs/ece_sqe/eval] [--batch-size 32] [--device cpu] [--plot]

Uses the data conventions (keys, units, quadrupole convention, origin) stored in the
checkpoint's config. Writes ``<out>/metrics.json`` and ``<out>/predictions.npz`` (per frame, in
atomic units: ``pred_<q>`` / ``label_<q>`` arrays for every predicted quantity, ragged ones as
object arrays), and with ``--plot`` (needs matplotlib) ``<out>/parity.png`` in report units.
Labels may be absent: then only predictions are written.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np  # noqa: E402
import torch  # noqa: E402

from eceprops.data import DataConventions, Loader, load_molecules  # noqa: E402
from eceprops.models import PropertyModel  # noqa: E402
from eceprops.training import (  # noqa: E402
    ELECTRICAL, loss_terms, predict, report_factors, summarize,
)


def load_model(checkpoint, device="cpu"):
    """``(model, config)`` from a ``best.pt`` / ``last.pt`` written by train.py."""
    ck = torch.load(checkpoint, map_location=device, weights_only=False)
    cfg = ck["config"]
    torch.set_default_dtype(getattr(torch, cfg["train"]["dtype"]))
    conv = DataConventions.from_config(cfg["data"])
    model = PropertyModel(ck["species"], cfg["model"], quad_order=conv.quadrupole_order,
                          quad_convention=conv.quadrupole_convention)
    model.load_state_dict(ck["state_dict"])
    return model.to(device).eval(), cfg


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("checkpoint")
    ap.add_argument("xyz", nargs="+")
    ap.add_argument("--out", default=None)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--no-hessian", action="store_true", help="skip Hessians (slowest part)")
    args = ap.parse_args(argv)

    model, cfg = load_model(args.checkpoint, args.device)
    conv = DataConventions.from_config(cfg["data"])
    dtype = getattr(torch, cfg["train"]["dtype"])
    mols = load_molecules(args.xyz, conv, dtype)
    report, units = report_factors(cfg["report_units"])
    out = Path(args.out or Path(args.checkpoint).parent / "eval")
    out.mkdir(parents=True, exist_ok=True)

    quantities = ["energy", "forces", "hessian", "dipole", "quadrupole", "dipole_derivatives",
                  "quadrupole_derivatives", "polarizability", "polarizability_derivatives"]
    if model.kind == "none":
        quantities = [q for q in quantities if q not in ELECTRICAL]
    if args.no_hessian:
        quantities.remove("hessian")
    stats = []
    rec = {f"{k}_{q}": [] for q in quantities for k in ("pred", "label")}
    rec["name"], rec["charges"] = [], []
    for batch in Loader(mols, args.batch_size, shuffle=False):
        batch = batch.to(args.device)
        pred, o = predict(model, batch, set(quantities), training=False)
        _, st = loss_terms(pred, batch, cfg["loss"], report)
        stats.append(st)
        n = batch.n_atoms.tolist()
        offs = np.cumsum([0] + n)
        nmax = max(n)
        for q in quantities:
            p = pred[q]
            if q == "hessian":
                cols = p["cols"].detach().cpu().numpy()          # (N, 3, 3nmax)
                vals = [cols[offs[i]:offs[i + 1]].reshape(3 * n[i], 3 * nmax)[:, :3 * n[i]] for i in range(len(n))]
            elif q in ("forces", "dipole_derivatives", "quadrupole_derivatives", "polarizability_derivatives"):
                a = p.detach().cpu().numpy()
                vals = [a[offs[i]:offs[i + 1]] for i in range(len(n))]
            else:
                a = p.detach().cpu().numpy()
                vals = list(a)
            rec[f"pred_{q}"] += vals
            if q in batch.labels:
                lab, mask = batch.labels[q]
                lab = lab.cpu().numpy()
                for i in range(len(n)):
                    if not bool(mask[i]):
                        rec[f"label_{q}"].append(None)
                    elif q == "hessian":
                        rec[f"label_{q}"].append(lab[i, :3 * n[i], :3 * n[i]])
                    elif q in ("forces", "dipole_derivatives", "quadrupole_derivatives", "polarizability_derivatives"):
                        rec[f"label_{q}"].append(lab[offs[i]:offs[i + 1]])
                    else:
                        rec[f"label_{q}"].append(lab[i])
            else:
                rec[f"label_{q}"] += [None] * len(n)
        if "charges" in o:
            c = o["charges"].detach().cpu().numpy()
            rec["charges"] += [c[offs[i]:offs[i + 1]] for i in range(len(n))]
    rec["name"] = [m.name for m in mols]
    metrics = summarize(stats)
    print(f"{len(mols)} frames from {args.xyz}")
    for q, v in metrics.items():
        print(f"  {q:28s} rmse {v['rmse']:.4g}  mae {v['mae']:.4g}  [{units[q]}]")
    (out / "metrics.json").write_text(json.dumps({"units": units, "metrics": metrics}, indent=2))
    arrays = {}
    for k, v in rec.items():
        if not v or all(x is None for x in v):
            continue
        arr = np.empty(len(v), dtype=object)
        arr[:] = v
        arrays[k] = arr
    np.savez(out / "predictions.npz", **arrays)
    print(f"wrote {out / 'metrics.json'} and {out / 'predictions.npz'}")

    if args.plot:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        qs = [q for q in quantities if any(x is not None for x in rec[f"label_{q}"])]
        ncol = 3
        nrow = (len(qs) + ncol - 1) // ncol
        fig, axes = plt.subplots(nrow, ncol, figsize=(4 * ncol, 4 * nrow), squeeze=False)
        for ax, q in zip(axes.flat, qs):
            pairs = [(np.ravel(p), np.ravel(l)) for p, l in zip(rec[f"pred_{q}"], rec[f"label_{q}"]) if l is not None]
            p = np.concatenate([a for a, _ in pairs]) / report[q]
            lab = np.concatenate([b for _, b in pairs]) / report[q]
            if q == "energy":   # per-molecule offsets dominate; plot relative to each molecule's mean
                names = [n_ for n_, l in zip(rec["name"], rec[f"label_{q}"]) if l is not None]
                for nm in set(names):
                    sel = np.array([x == nm for x in names])
                    off = lab[sel].mean()
                    lab[sel] -= off
                    p[sel] -= off
            lo, hi = min(p.min(), lab.min()), max(p.max(), lab.max())
            ax.plot([lo, hi], [lo, hi], color="0.6", lw=0.8)
            ax.scatter(lab, p, s=3, alpha=0.5)
            ax.set_title(f"{q}\nrmse {metrics[q]['rmse']:.3g} {units[q]}", fontsize=9)
            ax.set_xlabel("label")
            ax.set_ylabel("model")
        for ax in list(axes.flat)[len(qs):]:
            ax.axis("off")
        fig.tight_layout()
        fig.savefig(out / "parity.png", dpi=130)
        print(f"wrote {out / 'parity.png'}")


if __name__ == "__main__":
    main()
