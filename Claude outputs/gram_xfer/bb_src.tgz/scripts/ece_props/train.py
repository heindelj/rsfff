#!/usr/bin/env python
"""Train an ECE model on energies, forces, Hessians, multipoles, polarizabilities and their
position derivatives, from extxyz files.

    python scripts/ece_props/train.py config.yaml
    python scripts/ece_props/train.py config.yaml --set train.epochs=50 --set model.electrical.kind=direct

Writes ``<train.out_dir>/``: ``config.yaml`` (fully resolved), ``log.csv``, ``best.pt``,
``last.pt`` and ``metrics.json`` (validation and, if given, test errors of the best model).
See README.md for the data format and every config option.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch  # noqa: E402

from eceprops.config import dump, load_config  # noqa: E402
from eceprops.data import DataConventions, Loader, load_molecules, split  # noqa: E402
from eceprops.models import PropertyModel  # noqa: E402
from eceprops.training import (  # noqa: E402
    init_from_data, loss_terms, predict, report_factors, summarize, wanted,
)


def _paths(x):
    if x is None:
        return []
    return [x] if isinstance(x, str) else list(x)


def build_model(cfg, species):
    conv = DataConventions.from_config(cfg["data"])
    return PropertyModel(species, cfg["model"], quad_order=conv.quadrupole_order,
                         quad_convention=conv.quadrupole_convention)


def evaluate(model, mols, cfg, report, batch_size, device, loss_cfg=None):
    """Weighted loss and per-quantity errors (report units) with full Jacobians/Hessians."""
    model.eval()
    loss_cfg = loss_cfg or cfg["loss"]
    stats, tot, n = [], 0.0, 0
    for batch in Loader(mols, batch_size, shuffle=False):
        batch = batch.to(device)
        want = wanted(loss_cfg, batch.labels.keys(), model.kind, for_eval=True)
        pred, _ = predict(model, batch, want, training=False)
        terms, st = loss_terms(pred, batch, loss_cfg, report)
        tot += float(sum(t.detach() for t in terms.values())) * batch.n_systems
        n += batch.n_systems
        stats.append(st)
    model.train()
    return tot / max(n, 1), summarize(stats)


def fmt(metrics, keys=("rmse",)):
    short = {"energy": "E", "forces": "F", "hessian": "H", "dipole": "mu", "quadrupole": "Q",
             "dipole_derivatives": "dmu", "quadrupole_derivatives": "dQ", "polarizability": "a",
             "polarizability_derivatives": "da"}
    return " ".join(f"{short[q]}={m['rmse']:.4g}" for q, m in metrics.items())


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("config")
    ap.add_argument("--set", action="append", default=[], help="override, e.g. train.lr=5e-4")
    args = ap.parse_args(argv)

    cfg = load_config(args.config, args.set)
    tc, dc = cfg["train"], cfg["data"]
    dtype = getattr(torch, tc["dtype"])
    torch.set_default_dtype(dtype)
    torch.manual_seed(tc["seed"])
    device = torch.device(tc["device"])
    out = Path(tc["out_dir"])
    out.mkdir(parents=True, exist_ok=True)
    dump(cfg, out / "config.yaml")

    # ---- data --------------------------------------------------------------------------------
    conv = DataConventions.from_config(dc)
    t0 = time.time()
    mols = load_molecules(_paths(dc["train"]), conv, dtype, dc["max_frames"])
    if dc["val"]:
        train_m, val_m = mols, load_molecules(_paths(dc["val"]), conv, dtype)
    else:
        train_m, val_m = split(mols, dc["val_fraction"], tc["seed"], dc["split_by"])
    test_m = load_molecules(_paths(dc["test"]), conv, dtype) if dc["test"] else []
    species = sorted({int(z) for m in train_m + val_m + test_m for z in m.z})
    if cfg["model"].get("species"):
        missing = sorted(set(species) - set(cfg["model"]["species"]))
        if missing:
            raise SystemExit(f"model.species lacks elements present in the data: {missing}")
        species = sorted(int(z) for z in cfg["model"]["species"])
    print(f"data: {len(train_m)} train / {len(val_m)} val / {len(test_m)} test frames, "
          f"elements {species} ({time.time() - t0:.1f} s)")
    present = sorted({q for m in train_m for q in m.labels})
    print(f"labels present: {present}")
    report, units = report_factors(cfg["report_units"])

    # ---- model -------------------------------------------------------------------------------
    model = build_model(cfg, species).to(device)
    init_from_data(model, train_m)
    model.to(device)
    n_par = sum(p.numel() for p in model.parameters())
    print(f"model: electrical={model.kind}, {n_par} parameters")
    want = wanted(cfg["loss"], present, model.kind)
    skipped = [q for q in present if q not in want]
    print(f"training on {sorted(want)}" + (f"; not in the loss: {skipped}" if skipped else ""))

    sp = set(id(p) for p in model.species_parameters())
    groups = [{"params": [p for p in model.parameters() if id(p) not in sp], "lr": tc["lr"]},
              {"params": model.species_parameters(), "lr": tc["lr"] * tc["species_lr_factor"]}]
    opt = torch.optim.AdamW(groups, lr=tc["lr"], weight_decay=tc["weight_decay"])
    sc = tc["scheduler"] or {"kind": "none"}
    if sc["kind"] == "plateau":
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=sc["factor"], patience=sc["patience"],
                                                           min_lr=sc["min_lr"])
    elif sc["kind"] == "cosine":
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, tc["epochs"], eta_min=sc.get("min_lr", 0.0))
    else:
        sched = None
    probes = {q: int(c.get("probes", 0)) for q, c in cfg["loss"].items()}
    gen = torch.Generator(device=device).manual_seed(tc["seed"])

    loader = Loader(train_m, tc["batch_size"], shuffle=True, seed=tc["seed"])
    log_f = open(out / "log.csv", "w", newline="")
    log = None
    best = float("inf")
    for epoch in range(1, tc["epochs"] + 1):
        t0 = time.time()
        tr_stats, tr_loss, n_sys = [], 0.0, 0
        for step, batch in enumerate(loader):
            batch = batch.to(device)
            w = wanted(cfg["loss"], batch.labels.keys(), model.kind)
            pred, _ = predict(model, batch, w, training=True, probes=probes, generator=gen)
            terms, st = loss_terms(pred, batch, cfg["loss"], report)
            loss = sum(terms.values())
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if tc["grad_clip"]:
                torch.nn.utils.clip_grad_norm_(model.parameters(), tc["grad_clip"])
            opt.step()
            tr_loss += float(loss.detach()) * batch.n_systems
            n_sys += batch.n_systems
            tr_stats.append(st)
            if tc["log_every"] and (step + 1) % tc["log_every"] == 0:
                print(f"  epoch {epoch} step {step + 1}/{len(loader)} loss {float(loss.detach()):.4g}", flush=True)
        tr_loss /= max(n_sys, 1)
        row = {"epoch": epoch, "lr": opt.param_groups[0]["lr"], "train_loss": tr_loss,
               "time": round(time.time() - t0, 2)}
        for q, m in summarize(tr_stats).items():
            row[f"train_{q}_rmse"] = m["rmse"]
        if val_m and (epoch % tc["eval_every"] == 0 or epoch == tc["epochs"]):
            vl, vm = evaluate(model, val_m, cfg, report, tc["val_batch_size"], device)
            row["val_loss"] = vl
            for q, m in vm.items():
                row[f"val_{q}_rmse"] = m["rmse"]
                row[f"val_{q}_mae"] = m["mae"]
            if vl < best:
                best = vl
                torch.save({"config": cfg, "species": species, "state_dict": model.state_dict(),
                            "epoch": epoch, "val_loss": vl}, out / "best.pt")
            if isinstance(sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                sched.step(vl)
            print(f"epoch {epoch:4d} {row['time']:6.1f}s lr {row['lr']:.2e} train {tr_loss:.4g} "
                  f"val {vl:.4g} | val rmse {fmt(vm)}", flush=True)
        else:
            print(f"epoch {epoch:4d} {row['time']:6.1f}s lr {row['lr']:.2e} train {tr_loss:.4g}", flush=True)
        if sched is not None and not isinstance(sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
            sched.step()
        if log is None:
            keys = list(row.keys())
            log = csv.DictWriter(log_f, fieldnames=keys, extrasaction="ignore")
            log.writeheader()
        log.writerow(row)
        log_f.flush()
    torch.save({"config": cfg, "species": species, "state_dict": model.state_dict(), "epoch": tc["epochs"]},
               out / "last.pt")
    if not val_m:
        torch.save({"config": cfg, "species": species, "state_dict": model.state_dict(),
                    "epoch": tc["epochs"]}, out / "best.pt")

    # ---- final metrics with the best checkpoint -----------------------------------------------
    ck = torch.load(out / "best.pt", map_location=device, weights_only=False)
    model.load_state_dict(ck["state_dict"])
    result = {"units": units, "best_epoch": ck["epoch"]}
    for name, ms in (("val", val_m), ("test", test_m)):
        if ms:
            _, m = evaluate(model, ms, cfg, report, tc["val_batch_size"], device)
            result[name] = m
            print(f"{name} (best epoch {ck['epoch']}):")
            for q, v in m.items():
                print(f"  {q:28s} rmse {v['rmse']:.4g}  mae {v['mae']:.4g}  [{units[q]}]")
    (out / "metrics.json").write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
