"""ECE models for one molecule at a time (fixed bonded topology): energy + electrical properties.

``PropertyModel`` = an energy head + an electrical head, each on an
:class:`bb.features.EdgeClusterExpansion` of the bond graph (one shared ECE, or one each).

Energy (always)::

    E(R) = sum_i E0[Z_i] + sum_bonds [Eb[Z_a, Z_b] + scale * eps_b(R)]     eps_b: EdgeScalarReadout (sym)

Electrical head (``model.electrical.kind``):

``none``    energy only (E, forces, Hessians).
``direct``  no solve. Per-atom quantities are sums over the atom's outgoing directed edges of an
            :class:`bb.heads.EdgeReadout` (each edge's outputs live in its bond frame and are
            rotated back): charges ``q = Q/n + bond flows`` (antisymmetric, so ``sum q = Q``
            exactly), atomic dipoles (1o), atomic second moments (0e + 2e), PSD atomic
            polarizabilities. The molecular polarizability is the sum of the atomic ones.
``sqe``     the no-Coulomb split-charge response model of :mod:`eceprops.response`: the edge
            readout predicts electronegativities, hardnesses, bond compliances, permanent
            atomic dipoles / second moments and atomic dipole / quadrupole polarizabilities; the
            permanent charges and the charge-flow polarizability come from one linear solve per
            molecule. Its field energy is zero-field subtracted, so it never changes the PES.

Both electrical kinds go through :func:`eceprops.response.response`, so moments and
polarizabilities are always the field derivatives of ``dE(F, G)``, the model's own energy in a
uniform field ``F`` and field gradient ``G``: ``PropertyModel.forward(..., field=, field_gradient=)``
returns ``E(R) + dE(R; F, G)``.

Positions are in bohr everywhere (the ECE sees Angstrom internally, for its covalent-radius
Morse basis). Outputs are in atomic units.
"""

from __future__ import annotations

import dataclasses
import math

import torch
from torch import nn

from bb.features import EdgeClusterExpansion
from bb.graph import bond_graph
from bb.heads import EdgeReadout, EdgeScalarReadout
from bb.o3.cartesian import irrep2_to_traceless_matrix

from .data import component_pairs, matrix_to_sym6
from .response import ResponseParameters, response
from .units import BOHR_ANG

# Free-atom static polarizabilities (bohr^3; Schwerdtfeger & Nagle 2018), used only to
# initialise the per-species atomic polarizabilities when the data has no alpha labels.
FREE_ATOM_ALPHA = {1: 4.5, 2: 1.38, 3: 164.0, 4: 37.7, 5: 20.5, 6: 11.3, 7: 7.4, 8: 5.3, 9: 3.74,
                   10: 2.66, 11: 163.0, 12: 71.0, 13: 57.8, 14: 37.3, 15: 25.0, 16: 19.4, 17: 14.6,
                   18: 11.1, 35: 21.0, 53: 32.9}

DEFAULT_MODEL = {
    "species": None,              # atomic numbers the model knows; null: every element in the data
    "backend": "e3nn",
    "shared_ece": False,          # electrical head reuses the energy head's ECE
    "compress": True,             # asinh on the ECE invariants before the MLPs
    "ece": {"n_max": 6, "l_max": 3, "channels": 16, "species_dim": 4, "morse_a": 2.0,
            "learn_r0": False},
    "energy": {"hidden": 64, "depth": 2, "species_dim": 8, "bond_basis": 0, "odd": "symmetrize"},
    "electrical": {
        "kind": "sqe",            # none | direct | sqe
        "ece": None,              # ECE settings for the electrical head (default: same as energy)
        "hidden": 64, "depth": 2, "species_dim": 8,
        # sqe / direct switches
        "atomic_dipoles": True,             # permanent atomic dipoles (1o per edge)
        "atomic_polarizability": True,      # PSD atomic dipole polarizabilities
        "anisotropic_polarizability": True, # 2e part of the atomic polarizabilities
        "atomic_quadrupoles": True,         # permanent atomic second moments (0e trace + 2e)
        "quadrupole_polarizability": True,  # sqe only: isotropic atomic c_i on the field gradient
        "charge_flow": True,                # sqe only: bond compliances (False = fixed q0)
        "init": {"eta": 0.5, "compliance": 0.5, "c_quad": 1.0},
    },
}


def merge(base: dict, over: dict | None) -> dict:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = merge(out[k], v)
        else:
            out[k] = v
    return out


def _compress(ef):
    return dataclasses.replace(ef, inv0e=torch.asinh(ef.inv0e), inv0o=torch.asinh(ef.inv0o))


class PropertyModel(nn.Module):
    def __init__(self, species, cfg: dict | None = None, quad_order=("xx", "xy", "yy", "xz", "yz", "zz"),
                 quad_convention: str = "primitive"):
        super().__init__()
        cfg = merge(DEFAULT_MODEL, cfg)
        self.cfg = cfg
        self.species = [int(z) for z in sorted(species)]
        S = len(self.species)
        lut = torch.full((120,), -1, dtype=torch.long)
        lut[torch.tensor(self.species)] = torch.arange(S)
        self.register_buffer("lut", lut, persistent=False)
        self.quad_pairs = component_pairs(list(quad_order))
        self.quad_convention = quad_convention

        e = cfg["ece"]
        mk = lambda c: EdgeClusterExpansion(  # noqa: E731
            self.species, n_max=c["n_max"], l_max=c["l_max"], channels=c["channels"],
            species_dim=c["species_dim"], morse_a=c["morse_a"], learn_r0=c["learn_r0"],
            backend=cfg["backend"])
        self.ece = mk(e)
        self.compress = bool(cfg["compress"])

        # ---- energy ------------------------------------------------------------------------
        en = cfg["energy"]
        self.energy_head = EdgeScalarReadout.from_ece(
            self.ece, n_out=1, symmetry="sym", odd=en["odd"], species_dim=en["species_dim"],
            hidden=en["hidden"], depth=en["depth"], zero_init=True, bond_basis=en["bond_basis"])
        self.register_buffer("e0", torch.zeros(S))
        self.register_buffer("e_bond", torch.zeros(S, S))     # per bond type (symmetric), fixed by LSQ
        self.register_buffer("energy_scale", torch.tensor(0.01))

        # ---- electrical --------------------------------------------------------------------
        el = cfg["electrical"]
        self.kind = el["kind"]
        if self.kind not in ("none", "direct", "sqe"):
            raise ValueError(f"electrical.kind must be none, direct or sqe, got {self.kind!r}")
        self.el = el
        if self.kind != "none":
            if cfg["shared_ece"]:
                self.ece_el = None
            else:
                self.ece_el = mk(merge(e, el.get("ece")))
            ece = self.ece if self.ece_el is None else self.ece_el
            self.scalar_names = (["flow"] if self.kind == "direct" else
                                 ["chi", "log_eta"] + (["log_s"] if el["charge_flow"] else []))
            if el["atomic_polarizability"]:
                self.scalar_names.append("a_alpha")
            if el["atomic_quadrupoles"]:
                self.scalar_names.append("m2_trace")
            if self.kind == "sqe" and el["quadrupole_polarizability"]:
                self.scalar_names.append("log_c")
            n2 = int(el["atomic_polarizability"] and el["anisotropic_polarizability"]) + int(el["atomic_quadrupoles"])
            irreps = f"{len(self.scalar_names)}x0e"
            if el["atomic_dipoles"]:
                irreps += " + 1x1o"
            if n2:
                irreps += f" + {n2}x2e"
            self.irreps = irreps
            self.el_head = EdgeReadout(ece, irreps, symmetry="sym", species_dim=el["species_dim"],
                                       hidden=el["hidden"], depth=el["depth"], zero_init=True,
                                       compress=self.compress)
            init = el["init"]
            self.chi_z = nn.Parameter(torch.zeros(S))
            self.log_eta_z = nn.Parameter(torch.full((S,), math.log(init["eta"])))
            self.log_s_zz = nn.Parameter(torch.full((S, S), math.log(init["compliance"])))
            self.log_alpha_z = nn.Parameter(torch.log(torch.tensor(
                [0.6 * FREE_ATOM_ALPHA.get(z, 10.0) for z in self.species])))
            self.log_c_z = nn.Parameter(torch.full((S,), math.log(init["c_quad"])))
            self.m2_trace_z = nn.Parameter(torch.zeros(S))
            # fixed output scales (atomic units) so the zero-initialised MLPs start at sane sizes
            self.out_scale = {"flow": 0.1, "chi": 0.1, "log_eta": 1.0, "log_s": 1.0, "a_alpha": 0.5,
                              "m2_trace": 1.0, "log_c": 1.0, "dipole": 0.1, "alpha_aniso": 0.3,
                              "m2_aniso": 0.5}

    # ------------------------------------------------------------------------------------------
    def species_parameters(self):
        """Per-species tables (they get their own learning-rate factor)."""
        return [p for n, p in self.named_parameters() if n.endswith("_z") or n.endswith("_zz")]

    def _features(self, ece, pos_ang, sidx, g):
        ef = ece(pos_ang, sidx, g)
        return ef

    def forward(self, batch, positions=None, field=None, field_gradient=None):
        """``batch``: :class:`eceprops.data.Batch`; ``positions`` (N, 3) bohr overrides
        ``batch.pos`` (pass a tensor that requires grad for forces and derivatives)."""
        pos = batch.pos if positions is None else positions
        M = batch.n_systems
        sidx = self.lut[batch.z]
        if bool((sidx < 0).any()):
            bad = sorted(set(batch.z[sidx < 0].tolist()))
            raise ValueError(f"elements {bad} are not in the model's species {self.species} "
                             "(set model.species in the config to include them)")
        g = bond_graph(batch.bonds, int(pos.shape[0]), check=False)
        pos_ang = pos * BOHR_ANG
        ef = self.ece(pos_ang, sidx, g)
        efc = _compress(ef) if self.compress else ef
        bond_e = self.energy_head(efc, batch.batch_idx, M)["total"][:, 0] if g.n_bonds else pos.new_zeros(M)
        energy = pos.new_zeros(M).index_add(0, batch.batch_idx, self.e0[sidx]) + self.energy_scale * bond_e
        if g.n_bonds:
            eb = self.e_bond[sidx[batch.bonds[:, 0]], sidx[batch.bonds[:, 1]]]
            energy = energy.index_add(0, batch.bond_batch, eb)
        out = {"energy_pes": energy}

        if self.kind == "none":
            out["energy"] = energy
            return out

        ef_el = ef if self.ece_el is None else self.ece_el(pos_ang, sidx, g)
        params = self._electrical_parameters(batch, ef_el, g, sidx, pos)
        sol = response(params, pos, batch.bonds, batch.batch_idx, batch.bond_batch, M, batch.origin)
        out["solution"] = sol
        out["charges"] = sol.charges
        out["dipole"] = sol.dipole
        out["second_moment"] = sol.second_moment
        out["quadrupole"] = self.quadrupole(sol.second_moment)
        out["polarizability"] = sol.polarizability
        out["energy"] = energy + sol.energy(field, field_gradient)
        return out

    def quadrupole(self, m2):
        """Primitive second moment (M, 3, 3) -> the label convention and order (M, 6)."""
        if self.quad_convention == "traceless":
            tr = torch.diagonal(m2, dim1=-2, dim2=-1).sum(-1)
            m2 = 1.5 * m2 - 0.5 * tr[:, None, None] * torch.eye(3, dtype=m2.dtype, device=m2.device)
        return matrix_to_sym6(m2, self.quad_pairs)

    # ------------------------------------------------------------------------------------------
    def _electrical_parameters(self, batch, ef, g, sidx, pos) -> ResponseParameters:
        el, sc = self.el, self.out_scale
        N, dt = pos.shape[0], pos.dtype
        n_at = batch.n_atoms.to(dt)[batch.batch_idx]
        q0 = (batch.charge[batch.batch_idx] / n_at).to(dt)
        if g.n_bonds:
            y = self.el_head.edge_values(_compress(ef) if self.compress else ef)
        else:
            y = {}
        src = g.edge_index[0]

        def atom_sum(v):
            return v.new_zeros((N,) + v.shape[1:]).index_add(0, src, v) if g.n_bonds else \
                pos.new_zeros((N,) + v.shape[1:])

        s0 = y["0e"][:, 0, :] if "0e" in y else pos.new_zeros(0, len(self.scalar_names))
        col = {n: s0[:, k] for k, n in enumerate(self.scalar_names)}
        at = {n: atom_sum(c) for n, c in col.items()}
        two = y.get("2e")
        k2 = 0
        eye = torch.eye(3, dtype=dt, device=pos.device)
        p = ResponseParameters(q0=q0)

        if self.kind == "direct":
            nb = g.n_bonds
            flow = sc["flow"] * (col["flow"][:nb] - col["flow"][g.rev[:nb]]) if nb else pos.new_zeros(0)
            q = q0.clone()
            if nb:
                q = q.index_add(0, g.bonds[:, 0], -flow).index_add(0, g.bonds[:, 1], flow)
            p.q0 = q
        else:
            p.chi = self.chi_z[sidx] + sc["chi"] * at["chi"]
            p.eta = torch.exp(self.log_eta_z[sidx] + sc["log_eta"] * at["log_eta"])
            if el["charge_flow"] and g.n_bonds:
                nb = g.n_bonds
                a, b = sidx[g.bonds[:, 0]], sidx[g.bonds[:, 1]]
                ls = 0.5 * (self.log_s_zz[a, b] + self.log_s_zz[b, a])
                p.compliance = torch.exp(ls + sc["log_s"] * (col["log_s"][:nb] + col["log_s"][g.rev[:nb]]))

        if el["atomic_dipoles"]:
            p.mu0 = sc["dipole"] * atom_sum(y["1o"][:, :, 0]) if "1o" in y else pos.new_zeros(N, 3)

        if el["atomic_polarizability"]:
            ea = torch.exp(sc["a_alpha"] * at["a_alpha"])
            if el["anisotropic_polarizability"]:
                T = sc["alpha_aniso"] * irrep2_to_traceless_matrix(atom_sum(two[:, :, k2]), self.ece.backend) \
                    if two is not None else pos.new_zeros(N, 3, 3)
                k2 += 1
                A = ea[:, None, None] * eye + T
                A = A @ A                                    # PSD, equivariant, polynomial
            else:
                A = (ea * ea)[:, None, None] * eye
            p.alpha = torch.exp(self.log_alpha_z[sidx])[:, None, None] * A

        if el["atomic_quadrupoles"]:
            tr = self.m2_trace_z[sidx] + sc["m2_trace"] * at["m2_trace"]
            T2 = sc["m2_aniso"] * irrep2_to_traceless_matrix(atom_sum(two[:, :, k2]), self.ece.backend) \
                if two is not None else pos.new_zeros(N, 3, 3)
            p.m2 = (tr / 3.0)[:, None, None] * eye + T2

        if self.kind == "sqe" and el["quadrupole_polarizability"]:
            p.c_quad = torch.exp(self.log_c_z[sidx] + sc["log_c"] * at["log_c"])
        return p
