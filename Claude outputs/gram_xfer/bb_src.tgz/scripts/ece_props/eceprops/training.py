"""Predictions with position derivatives, losses, metrics and data-driven initialisation."""

from __future__ import annotations

import math

import numpy as np
import torch

from .data import QUANTITIES, Batch
from .units import to_au

PER_ATOM = ("forces", "dipole_derivatives", "quadrupole_derivatives", "polarizability_derivatives")

DEFAULT_REPORT_UNITS = {
    "energy": "kcal/mol",
    "forces": "kcal/mol/angstrom",
    "hessian": "kcal/mol/angstrom^2",
    "dipole": "debye",
    "quadrupole": "debye*angstrom",
    "dipole_derivatives": "e",
    "quadrupole_derivatives": "debye",
    "polarizability": "bohr^3",
    "polarizability_derivatives": "bohr^2",
}

DEFAULT_LOSS = {
    # weight * mean(((pred - label) / scale)^2), in report units. scale ~ the accuracy you hope for.
    "energy": {"weight": 1.0, "scale": 0.5},
    "forces": {"weight": 1.0, "scale": 1.0},
    "hessian": {"weight": 0.0, "scale": 50.0, "probes": 2},
    "dipole": {"weight": 1.0, "scale": 0.05},
    "quadrupole": {"weight": 1.0, "scale": 0.05},
    "dipole_derivatives": {"weight": 1.0, "scale": 0.05, "probes": 0},
    "quadrupole_derivatives": {"weight": 0.0, "scale": 0.1, "probes": 0},
    "polarizability": {"weight": 1.0, "scale": 0.5},
    "polarizability_derivatives": {"weight": 0.0, "scale": 0.5, "probes": 0},
}

ELECTRICAL = ("dipole", "quadrupole", "dipole_derivatives", "quadrupole_derivatives",
              "polarizability", "polarizability_derivatives")

_SYM6 = [(0, 0), (0, 1), (0, 2), (1, 1), (1, 2), (2, 2)]


def _local(batch: Batch):
    counts = batch.n_atoms
    offs = torch.cumsum(counts, 0) - counts
    return torch.arange(batch.batch_idx.shape[0], device=counts.device) - offs[batch.batch_idx]


def _grad(y, pos, create):
    g = torch.autograd.grad(y, pos, create_graph=create, retain_graph=True, allow_unused=True)[0]
    return torch.zeros_like(pos) if g is None else g


def predict(model, batch: Batch, want: set, training: bool, probes: dict | None = None, generator=None):
    """Model values for every quantity in ``want`` (atomic units), plus what the losses need.

    Derivative quantities come from autograd with respect to the positions (bohr).
    ``probes[q] > 0`` replaces a full Jacobian (or Hessian) by that many random projections:
    ``{q: {"pred": (k, N, 3), "w": weights}}`` -- the labels are contracted with the same
    weights in :func:`loss_terms`. Evaluation (``training=False``) always uses full Jacobians,
    except for the Hessian, whose probes default to full columns as well.
    """
    probes = probes or {}
    need_pos = bool(want & {"forces", "hessian", *PER_ATOM})
    pos = batch.pos.detach().clone().requires_grad_(need_pos)
    with torch.enable_grad():
        out = model(batch, pos)
        pred = {}
        if "energy" in want:
            pred["energy"] = out["energy"]
        for q in ("dipole", "quadrupole", "polarizability"):
            if q in want:
                if q not in out:
                    raise ValueError(f"{q} labels requested but electrical.kind is 'none'")
                pred[q] = out[q]
        create = training
        if "forces" in want or "hessian" in want:
            g = _grad(out["energy"].sum(), pos, create or "hessian" in want)
            pred["forces"] = -g
            if "hessian" in want:
                k = int(probes.get("hessian", 0)) if training else 0
                if k > 0:
                    vs = torch.randn((k,) + pos.shape, dtype=pos.dtype, device=pos.device, generator=generator)
                    hv = torch.stack([_grad((g * v).sum(), pos, create) for v in vs])
                    pred["hessian"] = {"hv": hv, "v": vs}
                else:  # full Hessian, one batched column per local coordinate
                    loc = _local(batch)
                    nmax = int(batch.n_atoms.max())
                    cols = []
                    for c in range(3 * nmax):
                        v = torch.zeros_like(pos)
                        sel = loc == c // 3
                        v[sel, c % 3] = 1.0
                        cols.append(_grad((g * v).sum(), pos, create))      # (N, 3): H[:, c]
                    pred["hessian"] = {"cols": torch.stack(cols, -1)}         # (N, 3, 3nmax)
        jac_src = {
            "dipole_derivatives": lambda: out["dipole"],                                   # (M, 3)
            "quadrupole_derivatives": lambda: out["quadrupole"],                           # (M, 6)
            "polarizability_derivatives": lambda: torch.stack(
                [out["polarizability"][:, a, b] for a, b in _SYM6], -1),                   # (M, 6)
        }
        for q, f in jac_src.items():
            if q not in want:
                continue
            y = f()
            k = int(probes.get(q, 0)) if training else 0
            if k > 0:
                ws = torch.randn((k,) + y.shape, dtype=y.dtype, device=y.device, generator=generator)
                pred[q] = {"proj": torch.stack([_grad((y * w).sum(), pos, create) for w in ws]), "w": ws}
            else:
                J = torch.stack([_grad(y[:, c].sum(), pos, create) for c in range(y.shape[1])], -1)
                if q == "polarizability_derivatives":   # (N, 3, 6) -> (N, 3, 3, 3)
                    full = J.new_zeros(J.shape[0], 3, 3, 3)
                    for c, (a, b) in enumerate(_SYM6):
                        full[:, :, a, b] = J[..., c]
                        full[:, :, b, a] = J[..., c]
                    J = full
                pred[q] = J
    return pred, out


def _residuals(q, pred, label, mask, batch: Batch):
    """Flat residual vector (atomic units) over the systems that carry the label."""
    if q == "hessian":
        loc = _local(batch)
        nmax = int(batch.n_atoms.max())
        M = batch.n_systems
        if "hv" in pred:
            res = []
            for hv, v in zip(pred["hv"], pred["v"]):
                vp = v.new_zeros(M, nmax, 3)
                vp[batch.batch_idx, loc] = v
                lab = torch.einsum("mij,mj->mi", label, vp.reshape(M, 3 * nmax)).reshape(M, nmax, 3)
                res.append(hv - lab[batch.batch_idx, loc])
            r = torch.stack(res)                               # (k, N, 3)
            return r[:, mask[batch.batch_idx]].reshape(-1)
        cols = pred["cols"]                                    # (N, 3, 3nmax)
        lab = label.reshape(M, nmax, 3, 3 * nmax)[batch.batch_idx, loc]
        ncol = 3 * batch.n_atoms[batch.batch_idx]
        colmask = torch.arange(3 * nmax, device=cols.device)[None, :] < ncol[:, None]
        r = (cols - lab)[mask[batch.batch_idx]]
        return r[colmask[mask[batch.batch_idx]][:, None, :].expand_as(r)]
    if q in PER_ATOM:
        if q == "forces":
            r = pred - label
        elif isinstance(pred, dict):                           # random projections
            lab = label.reshape(label.shape[0], 3, -1)
            res = []
            for g, w in zip(pred["proj"], pred["w"]):
                wv = w[batch.batch_idx].reshape(label.shape[0], -1)
                if q == "polarizability_derivatives":
                    wf = wv.new_zeros(wv.shape[0], 3, 3)
                    for c, (a, b) in enumerate(_SYM6):
                        wf[:, a, b] = wv[:, c] * (1.0 if a == b else 0.5)
                        wf[:, b, a] = wv[:, c] * (1.0 if a == b else 0.5)
                    wv = wf.reshape(-1, 9)
                res.append(g - torch.einsum("nik,nk->ni", lab, wv))
            r = torch.stack(res, 0)
            return r[:, mask[batch.batch_idx]].reshape(-1)
        else:
            r = pred - label
        return r[mask[batch.batch_idx]].reshape(-1)
    return (pred - label)[mask].reshape(-1)


def loss_terms(pred, batch: Batch, loss_cfg: dict, report: dict):
    """``{q: weighted loss}`` and ``{q: (sum sq, sum abs, count)}`` in report units."""
    terms, stats = {}, {}
    for q, (label, mask) in batch.labels.items():
        if q not in pred or not bool(mask.any()):
            continue
        r = _residuals(q, pred[q], label, mask, batch) / report[q]
        if r.numel() == 0:
            continue
        c = loss_cfg.get(q, {})
        terms[q] = c.get("weight", 0.0) * (r / c.get("scale", 1.0)).pow(2).mean()
        d = r.detach()
        stats[q] = (float(d.pow(2).sum()), float(d.abs().sum()), int(d.numel()))
    return terms, stats


def wanted(loss_cfg, labels_present, kind, for_eval=False):
    """Quantities to predict: labelled ones with a weight (training) or all labelled ones (eval)."""
    out = set()
    for q in labels_present:
        if kind == "none" and q in ELECTRICAL:
            continue
        if for_eval or loss_cfg.get(q, {}).get("weight", 0.0) > 0:
            out.add(q)
    return out


# --------------------------------------------------------------------------------------------- #
# Initialisation from data
# --------------------------------------------------------------------------------------------- #
@torch.no_grad()
def init_from_data(model, mols, log=print):
    S = len(model.species)
    idx = {z: i for i, z in enumerate(model.species)}

    def comp(m):
        c = np.zeros(S)
        for z in m.z.tolist():
            c[idx[z]] += 1
        return c

    def lstsq(X, y, ridge=1e-8):
        X, y = np.asarray(X), np.asarray(y)
        return np.linalg.solve(X.T @ X + ridge * np.eye(X.shape[1]), X.T @ y)

    em = [m for m in mols if "energy" in m.labels]
    if em:
        # E ~ sum_atoms E0[Z] + sum_bonds Eb[Za, Zb]: ridge least squares on the counts
        pairs = [(a, b) for a in range(S) for b in range(a, S)]
        pidx = {p: k for k, p in enumerate(pairs)}

        def counts(m):
            c = np.zeros(S + len(pairs))
            c[:S] = comp(m)
            for a, b in m.bonds.tolist():
                i, j = sorted((idx[int(m.z[a])], idx[int(m.z[b])]))
                c[S + pidx[(i, j)]] += 1
            return c

        X = np.stack([counts(m) for m in em])
        y = np.array([float(m.labels["energy"]) for m in em])
        e0 = lstsq(X[:, :S], y)                       # atoms first ...
        r0 = y - X[:, :S] @ e0
        wb = lstsq(X[:, S:], r0, ridge=1e-6 * len(em))  # ... then bond types on what is left
        w = np.concatenate([e0, wb])
        res = r0 - X[:, S:] @ wb
        model.e0.copy_(torch.as_tensor(w[:S], dtype=model.e0.dtype))
        eb = torch.zeros(S, S, dtype=model.e_bond.dtype)
        for (i, j), k in pidx.items():
            eb[i, j] = eb[j, i] = w[S + k]
        model.e_bond.copy_(eb)
        # per-bond spread of what is left for the ECE (conformational energies)
        nb = np.array([max(len(m.bonds), 1) for m in em])
        scale = max(float(np.std(res / np.sqrt(nb))), 1e-3)
        model.energy_scale.fill_(scale)
        log(f"init: energy references by element and bond type; residual rms "
            f"{np.sqrt(np.mean(res ** 2)) * 627.5:.1f} kcal/mol (atoms only: "
            f"{np.sqrt(np.mean(r0 ** 2)) * 627.5:.1f}); bond energy scale {scale:.4f} Ha")
    if model.kind == "none":
        return
    am = [m for m in mols if "polarizability" in m.labels]
    if am and model.el["atomic_polarizability"]:
        X = np.stack([comp(m) for m in am])
        y = np.array([float(torch.diagonal(m.labels["polarizability"]).mean()) for m in am])
        a = lstsq(X, y, 1e-3)
        seen = X.sum(0) > 0
        frac = 0.8 if (model.kind == "sqe" and model.el["charge_flow"]) else 1.0
        a = np.where(seen, np.clip(a * frac, 0.3, None), np.exp(model.log_alpha_z.detach().cpu().numpy()))
        model.log_alpha_z.copy_(torch.log(torch.as_tensor(a, dtype=model.log_alpha_z.dtype)))
        log(f"init: atomic alpha per species (bohr^3) {dict(zip(model.species, np.round(a, 2)))}")
    qm = [m for m in mols if "quadrupole" in m.labels]
    if qm and model.el["atomic_quadrupoles"] and model.quad_convention == "primitive":
        diag = [k for k, (a, b) in enumerate(model.quad_pairs) if a == b]
        X = np.stack([comp(m) for m in qm])
        y = []
        for m in qm:
            r = m.pos - m.origin
            q0 = m.charge / len(m.z)
            y.append(float(m.labels["quadrupole"][diag].sum() - q0 * (r * r).sum()))
        t = lstsq(X, np.array(y), 1e-3)
        model.m2_trace_z.copy_(torch.as_tensor(t, dtype=model.m2_trace_z.dtype))
        log(f"init: atomic second-moment trace per species (e bohr^2) {dict(zip(model.species, np.round(t, 2)))}")


def report_factors(cfg_units: dict | None):
    """Atomic units per report unit, per quantity."""
    u = dict(DEFAULT_REPORT_UNITS)
    u.update(cfg_units or {})
    return {q: to_au(u[q], q) for q in QUANTITIES}, u


def summarize(stats_list):
    tot = {}
    for st in stats_list:
        for q, (s2, s1, n) in st.items():
            a = tot.setdefault(q, [0.0, 0.0, 0])
            a[0] += s2; a[1] += s1; a[2] += n
    return {q: {"rmse": math.sqrt(s2 / n), "mae": s1 / n} for q, (s2, s1, n) in tot.items() if n}
