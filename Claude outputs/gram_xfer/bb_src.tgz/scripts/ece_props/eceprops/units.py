"""Unit strings -> factors to atomic units, with a dimension check.

Everything inside the model is in atomic units: bohr, hartree, elementary charge. A unit string
is a product of tokens joined by ``*`` and ``/`` with optional integer powers ``^n``::

    "hartree"  "kcal/mol"  "ev/angstrom"  "hartree/bohr^2"  "e*bohr^2"  "debye*angstrom"  "bohr^3"

``mol`` is dimensionless, so ``kcal/mol`` is just a kcal per molecule. ``au`` means "already in
atomic units" for any quantity.

Polarizabilities are volumes (``bohr^3``, ``angstrom^3``): the atomic unit of polarizability
e^2 a0^2 / Eh equals a0^3.
"""

from __future__ import annotations

import re

BOHR_ANG = 0.529177210903            # Angstrom per bohr
HARTREE_EV = 27.211386245988
HARTREE_KCALMOL = 627.5094740631
HARTREE_KJMOL = 2625.4996394799
DEBYE_EBOHR = 0.3934303              # e*bohr per debye

# token -> (factor to atomic units, dims (energy, length, charge))
_TOKENS = {
    "hartree": (1.0, (1, 0, 0)), "ha": (1.0, (1, 0, 0)), "eh": (1.0, (1, 0, 0)),
    "ev": (1.0 / HARTREE_EV, (1, 0, 0)), "mev": (1e-3 / HARTREE_EV, (1, 0, 0)),
    "kcal": (1.0 / HARTREE_KCALMOL, (1, 0, 0)), "kj": (1.0 / HARTREE_KJMOL, (1, 0, 0)),
    "mol": (1.0, (0, 0, 0)),
    "bohr": (1.0, (0, 1, 0)), "a0": (1.0, (0, 1, 0)),
    "angstrom": (1.0 / BOHR_ANG, (0, 1, 0)), "ang": (1.0 / BOHR_ANG, (0, 1, 0)), "a": (1.0 / BOHR_ANG, (0, 1, 0)),
    "e": (1.0, (0, 0, 1)),
    "debye": (DEBYE_EBOHR, (0, 1, 1)),
}

#: Expected dimensions (energy, length, charge) of each label, in this module's convention.
DIMS = {
    "positions": (0, 1, 0),
    "energy": (1, 0, 0),
    "forces": (1, -1, 0),
    "hessian": (1, -2, 0),
    "dipole": (0, 1, 1),
    "quadrupole": (0, 2, 1),
    "dipole_derivatives": (0, 0, 1),
    "quadrupole_derivatives": (0, 1, 1),
    "polarizability": (0, 3, 0),
    "polarizability_derivatives": (0, 2, 0),
}


def parse_unit(spec: str) -> tuple[float, tuple[int, int, int]]:
    """``(factor to atomic units, dims)`` of a unit string."""
    s = spec.strip().lower().replace(" ", "")
    if s in ("au", "a.u.", "atomic"):
        return 1.0, None  # matches anything
    factor, dims = 1.0, [0, 0, 0]
    for sign, tok in re.findall(r"([*/]?)([^*/]+)", s):
        m = re.fullmatch(r"([a-z0-9.]+?)(?:\^(-?\d+))?", tok)
        if m is None or m.group(1) not in _TOKENS:
            raise ValueError(f"unknown unit token {tok!r} in {spec!r}; known: {sorted(_TOKENS)}")
        f, d = _TOKENS[m.group(1)]
        p = int(m.group(2) or 1) * (-1 if sign == "/" else 1)
        factor *= f ** p
        dims = [a + p * b for a, b in zip(dims, d)]
    return factor, tuple(dims)


def to_au(spec: str, quantity: str) -> float:
    """Factor that converts a value in ``spec`` units to atomic units, checked against
    the dimensions of ``quantity``."""
    f, d = parse_unit(spec)
    want = DIMS.get(quantity)
    if d is not None and want is not None and d != want:
        raise ValueError(f"unit {spec!r} has dimensions {d} (energy, length, charge) but "
                         f"{quantity} needs {want}")
    return f
