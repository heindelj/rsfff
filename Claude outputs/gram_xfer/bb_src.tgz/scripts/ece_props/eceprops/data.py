"""extxyz frames -> labelled molecules (atomic units) -> batches.

A frame is a standard extended-xyz block. Labels may be per frame (comment-line ``key=value``,
arrays as quoted whitespace-separated numbers) or per atom (``Properties=`` columns). Which key
holds which quantity, and in which units, comes from the ``data`` section of the config; the
defaults are the conventions of the fff_bonding exports (``data/sets/*/vacuum.xyz``):

==========================  ==================  =========================================  ==============
quantity                    default key         layout                                     default units
==========================  ==================  =========================================  ==============
energy                      energy              scalar                                     hartree
forces                      forces (Properties)  (N, 3)                                    hartree/bohr
hessian                     hessian             (3N)^2, atom-major ([a,i],[b,j])           hartree/bohr^2
dipole                      dipole              3                                          e*bohr
quadrupole                  quadrupole          6, order/convention from ``quadrupole``    e*bohr^2
dipole_derivatives          dipole_derivatives  N*3*3, [atom, dR, mu_k]                    e
quadrupole_derivatives      quadrupole_derivatives  N*3*6, [atom, dR, Q_k]                 e*bohr
polarizability              polarizability      9 row-major (or 6 in ``tensor6_order``)    bohr^3
polarizability_derivatives  polarizability_derivatives  N*3*9 (or N*3*6), [atom, dR, ij]   bohr^2
==========================  ==================  =========================================  ==============

Also read: ``bonds`` (flat 0-based pairs ``i j i j ...``; perceived from the frame's own
geometry with covalent radii if absent), ``charge`` (total charge, default 0) and positions
(``pos`` column; ``positions`` units, Angstrom by default).

Moments are about the origin named by ``data.origin`` (``coordinate``: the file's coordinate
origin; ``nuclear_charge`` / ``mass``: that frame's centre, held fixed when differentiating, as
analytic QC derivatives are). Derivative labels are with respect to the positions in bohr after
unit conversion.
"""

from __future__ import annotations

import random
import re
import warnings
from dataclasses import dataclass, field

import numpy as np
import torch

from .units import BOHR_ANG, to_au

QUANTITIES = (
    "energy", "forces", "hessian", "dipole", "quadrupole", "dipole_derivatives",
    "quadrupole_derivatives", "polarizability", "polarizability_derivatives",
)

DEFAULT_KEYS = {q: q for q in QUANTITIES}
DEFAULT_KEYS["quadrupole"] = "quadrupole"

DEFAULT_UNITS = {
    "positions": "angstrom",
    "energy": "hartree",
    "forces": "hartree/bohr",
    "hessian": "hartree/bohr^2",
    "dipole": "e*bohr",
    "quadrupole": "e*bohr^2",
    "dipole_derivatives": "e",
    "quadrupole_derivatives": "e*bohr",
    "polarizability": "bohr^3",
    "polarizability_derivatives": "bohr^2",
}

SYMBOLS = ["X", "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P",
           "S", "Cl", "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
           "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru",
           "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe"]
Z_OF = {s.lower(): z for z, s in enumerate(SYMBOLS)}
MASSES = [0.0, 1.008, 4.0026, 6.94, 9.0122, 10.81, 12.011, 14.007, 15.999, 18.998, 20.180, 22.990,
          24.305, 26.982, 28.085, 30.974, 32.06, 35.45, 39.948, 39.098, 40.078, 44.956, 47.867,
          50.942, 51.996, 54.938, 55.845, 58.933, 58.693, 63.546, 65.38, 69.723, 72.630, 74.922,
          78.971, 79.904, 83.798, 85.468, 87.62, 88.906, 91.224, 92.906, 95.95, 97.0, 101.07,
          102.91, 106.42, 107.87, 112.41, 114.82, 118.71, 121.76, 127.60, 126.90, 131.29]


# --------------------------------------------------------------------------------------------- #
# extxyz parsing (no ASE needed)
# --------------------------------------------------------------------------------------------- #
_KV = re.compile(r'([A-Za-z_][\w\-]*)\s*=\s*("([^"]*)"|\{([^}]*)\}|\'([^\']*)\'|\S+)')


def _value(s: str):
    toks = s.replace(",", " ").split()
    if not toks:
        return s
    try:
        vals = [float(t) for t in toks]
    except ValueError:
        if len(toks) == 1:
            if toks[0] in ("T", "True", "true"):
                return True
            if toks[0] in ("F", "False", "false"):
                return False
        return s
    return vals[0] if len(vals) == 1 else np.asarray(vals)


def parse_comment(line: str) -> dict:
    info = {}
    for m in _KV.finditer(line):
        key = m.group(1)
        raw = next(g for g in (m.group(3), m.group(4), m.group(5)) if g is not None) if \
            m.group(2)[0] in "\"{'" else m.group(2)
        info[key] = raw if key == "Properties" else _value(raw)
    return info


def read_extxyz(path) -> list[dict]:
    """Every frame of an extxyz file as ``{"symbols", "positions", "info", "arrays"}``."""
    frames = []
    with open(path) as fh:
        while True:
            line = fh.readline()
            if not line:
                break
            if not line.strip():
                continue
            n = int(line.split()[0])
            info = parse_comment(fh.readline())
            props = info.pop("Properties", "species:S:1:pos:R:3")
            cols = props.split(":")
            spec = [(cols[i], cols[i + 1], int(cols[i + 2])) for i in range(0, len(cols), 3)]
            rows = [fh.readline().split() for _ in range(n)]
            arrays, c = {}, 0
            for name, kind, width in spec:
                block = [r[c:c + width] for r in rows]
                c += width
                if kind == "S":
                    arrays[name] = [b[0] if width == 1 else b for b in block]
                elif kind == "R":
                    arrays[name] = np.asarray(block, dtype=float).reshape(n, width).squeeze(-1) \
                        if width == 1 else np.asarray(block, dtype=float)
                elif kind == "I":
                    arrays[name] = np.asarray(block, dtype=int).reshape(n, width).squeeze(-1) \
                        if width == 1 else np.asarray(block, dtype=int)
                elif kind == "L":
                    arrays[name] = np.asarray([[t in ("T", "True") for t in b] for b in block])
            symbols = arrays.pop("species", None) or arrays.pop("symbols")
            pos = arrays.pop("pos", None)
            if pos is None:
                pos = arrays.pop("positions")
            frames.append({"symbols": symbols, "positions": pos, "info": info, "arrays": arrays})
    return frames


# --------------------------------------------------------------------------------------------- #
# Conventions
# --------------------------------------------------------------------------------------------- #
_AX = {"x": 0, "y": 1, "z": 2}


def component_pairs(order) -> list[tuple[int, int]]:
    """``["xx", "xy", ...]`` -> ``[(0, 0), (0, 1), ...]``."""
    if isinstance(order, str):
        order = order.replace(",", " ").split()
    pairs = [(_AX[c[0]], _AX[c[1]]) for c in order]
    if len(pairs) != 6 or len({tuple(sorted(p)) for p in pairs}) != 6:
        raise ValueError(f"need the 6 distinct components of a symmetric tensor, got {order}")
    return pairs


def sym6_to_matrix(v: np.ndarray, pairs) -> np.ndarray:
    m = np.zeros(v.shape[:-1] + (3, 3))
    for k, (a, b) in enumerate(pairs):
        m[..., a, b] = v[..., k]
        m[..., b, a] = v[..., k]
    return m


def matrix_to_sym6(m: torch.Tensor, pairs) -> torch.Tensor:
    return torch.stack([m[..., a, b] for a, b in pairs], dim=-1)


@dataclass
class DataConventions:
    keys: dict = field(default_factory=lambda: dict(DEFAULT_KEYS))
    units: dict = field(default_factory=lambda: dict(DEFAULT_UNITS))
    charge_key: str = "charge"
    bonds_key: str = "bonds"
    quadrupole_convention: str = "primitive"      # primitive (sum q x_a x_b) | traceless (Buckingham)
    quadrupole_order: list = field(default_factory=lambda: ["xx", "xy", "yy", "xz", "yz", "zz"])
    tensor6_order: list = field(default_factory=lambda: ["xx", "xy", "yy", "xz", "yz", "zz"])
    origin: str = "coordinate"                    # coordinate | nuclear_charge | mass
    bond_scale: float = 1.2                       # covalent-radius factor when perceiving bonds

    @classmethod
    def from_config(cls, d: dict | None) -> "DataConventions":
        d = dict(d or {})
        out = cls()
        out.keys.update(d.pop("keys", {}) or {})
        out.units.update(d.pop("units", {}) or {})
        q = d.pop("quadrupole", {}) or {}
        out.quadrupole_convention = q.get("convention", out.quadrupole_convention)
        out.quadrupole_order = q.get("order", out.quadrupole_order)
        for k in ("charge_key", "bonds_key", "tensor6_order", "origin", "bond_scale"):
            if k in d:
                setattr(out, k, d.pop(k))
        if out.quadrupole_convention not in ("primitive", "traceless"):
            raise ValueError("quadrupole.convention must be 'primitive' or 'traceless'")
        if out.origin not in ("coordinate", "nuclear_charge", "mass"):
            raise ValueError("origin must be coordinate, nuclear_charge or mass")
        component_pairs(out.quadrupole_order)
        component_pairs(out.tensor6_order)
        return out


# --------------------------------------------------------------------------------------------- #
# Molecules
# --------------------------------------------------------------------------------------------- #
@dataclass
class Molecule:
    z: torch.Tensor            # (n,) long
    pos: torch.Tensor          # (n, 3) bohr
    bonds: torch.Tensor        # (b, 2) long
    charge: float
    origin: torch.Tensor       # (3,) bohr
    labels: dict               # quantity -> tensor (atomic units)
    name: str = ""


_warned_perceive = False
_warned_external = False


def _bonds(frame, conv: DataConventions, z, pos_ang):
    global _warned_perceive
    raw = frame["info"].get(conv.bonds_key)
    if raw is None:
        from bb.graph import covalent_bonds

        if not _warned_perceive:
            warnings.warn("no bonds in the extxyz; perceiving them from each frame's geometry "
                          "(stretched frames may lose bonds -- better to write `bonds=` in the file)")
            _warned_perceive = True
        return torch.as_tensor(covalent_bonds(pos_ang, z, conv.bond_scale), dtype=torch.long).reshape(-1, 2)
    b = np.atleast_1d(np.asarray(raw, dtype=float)).astype(np.int64)
    return torch.as_tensor(b.reshape(-1, 2), dtype=torch.long)


def frame_to_molecule(frame, conv: DataConventions, dtype=torch.float64) -> Molecule:
    z = np.array([Z_OF[s.lower()] if not str(s).isdigit() else int(s) for s in frame["symbols"]])
    n = len(z)
    pos_bohr = np.asarray(frame["positions"], float) * to_au(conv.units["positions"], "positions")
    pos = torch.as_tensor(pos_bohr, dtype=dtype)
    pos_ang = pos_bohr * BOHR_ANG
    info, arrays = frame["info"], frame["arrays"]
    labels = {}
    qpairs = component_pairs(conv.quadrupole_order)
    tpairs = component_pairs(conv.tensor6_order)

    def get(q):
        key = conv.keys.get(q)
        if key is None:
            return None
        v = arrays.get(key, info.get(key))
        if v is None or isinstance(v, str):
            return None
        return np.asarray(v, dtype=float) * to_au(conv.units[q], q)

    v = get("energy")
    if v is not None:
        labels["energy"] = torch.tensor(float(v), dtype=dtype)
    v = get("forces")
    if v is not None:
        labels["forces"] = torch.as_tensor(v.reshape(n, 3), dtype=dtype)
    v = get("hessian")
    if v is not None:
        labels["hessian"] = torch.as_tensor(v.reshape(3 * n, 3 * n), dtype=dtype)
    v = get("dipole")
    if v is not None:
        labels["dipole"] = torch.as_tensor(v.reshape(3), dtype=dtype)
    v = get("quadrupole")
    if v is not None:
        if v.size == 9:   # full matrix given: reduce to the configured 6
            m = v.reshape(3, 3)
            v = np.array([m[a, b] for a, b in qpairs])
        labels["quadrupole"] = torch.as_tensor(v.reshape(6), dtype=dtype)
    v = get("dipole_derivatives")
    if v is not None:
        labels["dipole_derivatives"] = torch.as_tensor(v.reshape(n, 3, 3), dtype=dtype)
    v = get("quadrupole_derivatives")
    if v is not None:
        labels["quadrupole_derivatives"] = torch.as_tensor(v.reshape(n, 3, 6), dtype=dtype)
    v = get("polarizability")
    if v is not None:
        m = v.reshape(3, 3) if v.size == 9 else sym6_to_matrix(v.reshape(6), tpairs)
        labels["polarizability"] = torch.as_tensor(0.5 * (m + m.T), dtype=dtype)
    v = get("polarizability_derivatives")
    if v is not None:
        if v.size == n * 27:
            m = v.reshape(n, 3, 3, 3)
        else:
            m = sym6_to_matrix(v.reshape(n, 3, 6), tpairs)
        labels["polarizability_derivatives"] = torch.as_tensor(m, dtype=dtype)

    global _warned_external
    if not _warned_external and any(k in info for k in ("ext_charges", "ext_field", "field", "efield")):
        warnings.warn("frames carry external charges/fields; this trainer treats every frame as an "
                      "isolated molecule in vacuum, so their labels include the external perturbation")
        _warned_external = True
    zt = torch.as_tensor(z, dtype=torch.long)
    if conv.origin == "coordinate":
        origin = torch.zeros(3, dtype=dtype)
    else:
        w = zt.to(dtype) if conv.origin == "nuclear_charge" else torch.tensor([MASSES[i] for i in z], dtype=dtype)
        origin = (w[:, None] * pos).sum(0) / w.sum()
    charge = float(info.get(conv.charge_key, 0.0) or 0.0)
    return Molecule(zt, pos, _bonds(frame, conv, z, pos_ang), charge, origin, labels,
                    str(info.get("name", "")))


def load_molecules(paths, conv: DataConventions, dtype=torch.float64, max_frames=None) -> list[Molecule]:
    if isinstance(paths, (str,)):
        paths = [paths]
    mols = []
    for p in paths:
        for fr in read_extxyz(p):
            mols.append(frame_to_molecule(fr, conv, dtype))
            if max_frames and len(mols) >= max_frames:
                return mols
    return mols


# --------------------------------------------------------------------------------------------- #
# Batches
# --------------------------------------------------------------------------------------------- #
@dataclass
class Batch:
    z: torch.Tensor            # (N,)
    pos: torch.Tensor          # (N, 3) bohr
    batch_idx: torch.Tensor    # (N,)
    bonds: torch.Tensor        # (B, 2) global atom indices
    bond_batch: torch.Tensor   # (B,)
    charge: torch.Tensor       # (M,)
    origin: torch.Tensor       # (M, 3)
    n_atoms: torch.Tensor      # (M,)
    labels: dict               # quantity -> (stacked/concatenated values, mask (M,) bool)
    n_systems: int

    def to(self, device):
        f = lambda t: t.to(device)  # noqa: E731
        lab = {k: (f(v), f(m)) for k, (v, m) in self.labels.items()}
        return Batch(f(self.z), f(self.pos), f(self.batch_idx), f(self.bonds), f(self.bond_batch),
                     f(self.charge), f(self.origin), f(self.n_atoms), lab, self.n_systems)


def collate(mols: list[Molecule]) -> Batch:
    dtype = mols[0].pos.dtype
    counts = [len(m.z) for m in mols]
    offs = np.concatenate([[0], np.cumsum(counts)[:-1]])
    z = torch.cat([m.z for m in mols])
    pos = torch.cat([m.pos for m in mols])
    batch_idx = torch.cat([torch.full((c,), i, dtype=torch.long) for i, c in enumerate(counts)])
    bonds = torch.cat([m.bonds + int(o) for m, o in zip(mols, offs)]) if mols else torch.zeros(0, 2, dtype=torch.long)
    bond_batch = torch.cat([torch.full((len(m.bonds),), i, dtype=torch.long) for i, m in enumerate(mols)])
    M = len(mols)
    nmax = max(counts)
    labels = {}
    for q in QUANTITIES:
        have = [q in m.labels for m in mols]
        if not any(have):
            continue
        mask = torch.tensor(have)
        ref = next(m.labels[q] for m in mols if q in m.labels)
        if q in ("forces", "dipole_derivatives", "quadrupole_derivatives", "polarizability_derivatives"):
            # per-atom: concatenate, zeros where absent; mask is per system
            parts = [m.labels[q] if q in m.labels else torch.zeros((len(m.z),) + ref.shape[1:], dtype=dtype)
                     for m in mols]
            labels[q] = (torch.cat(parts), mask)
        elif q == "hessian":
            h = torch.zeros(M, 3 * nmax, 3 * nmax, dtype=dtype)
            for i, m in enumerate(mols):
                if q in m.labels:
                    k = 3 * len(m.z)
                    h[i, :k, :k] = m.labels[q]
            labels[q] = (h, mask)
        else:
            labels[q] = (torch.stack([m.labels[q] if q in m.labels else torch.zeros_like(ref) for m in mols]), mask)
    return Batch(z, pos, batch_idx, bonds, bond_batch,
                 torch.tensor([m.charge for m in mols], dtype=dtype),
                 torch.stack([m.origin for m in mols]), torch.tensor(counts), labels, M)


class Loader:
    """Shuffled minibatches of molecules."""

    def __init__(self, mols, batch_size, shuffle=True, seed=0):
        self.mols, self.bs, self.shuffle = mols, int(batch_size), shuffle
        self.rng = random.Random(seed)

    def __len__(self):
        return (len(self.mols) + self.bs - 1) // self.bs

    def __iter__(self):
        idx = list(range(len(self.mols)))
        if self.shuffle:
            self.rng.shuffle(idx)
        for i in range(0, len(idx), self.bs):
            yield collate([self.mols[j] for j in idx[i:i + self.bs]])


def split(mols, val_fraction, seed=0, by="frame"):
    """Random train/val split by frame or by molecule ``name`` (whole molecules held out)."""
    rng = random.Random(seed)
    if by == "name":
        names = sorted({m.name for m in mols})
        rng.shuffle(names)
        n_val = max(1, int(round(val_fraction * len(names)))) if val_fraction > 0 else 0
        held = set(names[:n_val])
        return [m for m in mols if m.name not in held], [m for m in mols if m.name in held]
    idx = list(range(len(mols)))
    rng.shuffle(idx)
    n_val = int(round(val_fraction * len(mols)))
    val = set(idx[:n_val])
    return [m for i, m in enumerate(mols) if i not in val], [m for i, m in enumerate(mols) if i in val]
