"""ECE property models: data, units, the no-Coulomb SQE response solve, models and training helpers.

Used by ../train.py and ../evaluate.py; see ../README.md.
"""
