"""Config files: YAML (needs pyyaml), TOML (Python >= 3.11) or JSON, plus ``--set a.b=c`` overrides."""

from __future__ import annotations

import json
from pathlib import Path

from .models import DEFAULT_MODEL, merge
from .training import DEFAULT_LOSS, DEFAULT_REPORT_UNITS

DEFAULT_TRAIN = {
    "epochs": 200,
    "batch_size": 16,
    "val_batch_size": 32,
    "lr": 1.0e-3,
    "species_lr_factor": 10.0,   # per-species tables (E-ref-like offsets, alpha_Z, chi_Z, ...) learn faster
    "weight_decay": 0.0,
    "scheduler": {"kind": "plateau", "factor": 0.5, "patience": 10, "min_lr": 1.0e-6},
    "grad_clip": 10.0,
    "seed": 0,
    "device": "cpu",
    "dtype": "float64",
    "eval_every": 1,
    "out_dir": "runs/ece_props",
    "log_every": 0,             # print every n steps inside an epoch (0: once per epoch)
}

DEFAULT_DATA = {
    "train": None,             # path or list of paths
    "val": None,               # path(s); if absent, val_fraction of train is held out
    "test": None,              # path(s), evaluated with the best checkpoint at the end
    "val_fraction": 0.1,
    "split_by": "frame",       # frame | name (hold out whole molecules by the `name=` key)
    "max_frames": None,
}

KNOWN_TOP = {"data", "model", "loss", "report_units", "train"}


def _read(path):
    p = Path(path)
    text = p.read_text()
    if p.suffix in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError as e:
            raise SystemExit("YAML configs need pyyaml: pip install pyyaml (or use .toml / .json)") from e
        return yaml.safe_load(text) or {}
    if p.suffix == ".toml":
        import tomllib
        return tomllib.loads(text)
    return json.loads(text)


def _parse_scalar(v: str):
    try:
        import yaml
        return yaml.safe_load(v)
    except ImportError:
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            return v


def apply_overrides(cfg: dict, sets: list[str]) -> dict:
    for s in sets or []:
        key, _, val = s.partition("=")
        node = cfg
        parts = key.strip().split(".")
        for k in parts[:-1]:
            node = node.setdefault(k, {})
        node[parts[-1]] = _parse_scalar(val)
    return cfg


def load_config(path=None, sets=None) -> dict:
    raw = _read(path) if path else {}
    raw = apply_overrides(raw, sets)
    unknown = set(raw) - KNOWN_TOP
    if unknown:
        raise ValueError(f"unknown top-level config sections {sorted(unknown)}; expected {sorted(KNOWN_TOP)}")
    loss = {q: merge(v, raw.get("loss", {}).get(q)) for q, v in DEFAULT_LOSS.items()}
    bad = set(raw.get("loss", {})) - set(DEFAULT_LOSS)
    if bad:
        raise ValueError(f"unknown loss quantities {sorted(bad)}; expected {sorted(DEFAULT_LOSS)}")
    return {
        "data": merge(DEFAULT_DATA, raw.get("data")),
        "model": merge(DEFAULT_MODEL, raw.get("model")),
        "loss": loss,
        "report_units": merge(DEFAULT_REPORT_UNITS, raw.get("report_units")),
        "train": merge(DEFAULT_TRAIN, raw.get("train")),
    }


def dump(cfg: dict, path):
    path = Path(path)
    try:
        import yaml
        path.with_suffix(".yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    except ImportError:
        path.with_suffix(".json").write_text(json.dumps(cfg, indent=2))
