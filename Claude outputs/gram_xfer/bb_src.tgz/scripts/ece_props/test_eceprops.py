"""Checks for the ECE property scripts: python -m pytest scripts/ece_props/test_eceprops.py -q"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pytest  # noqa: E402
import torch  # noqa: E402

from eceprops.data import DataConventions, collate, frame_to_molecule, parse_comment  # noqa: E402
from eceprops.models import PropertyModel  # noqa: E402
from eceprops.response import ResponseParameters, field_energy, response  # noqa: E402
from eceprops.training import loss_terms, predict  # noqa: E402
from eceprops.units import parse_unit, to_au  # noqa: E402

torch.set_default_dtype(torch.float64)

# acetaldehyde-like, an ion and a diatomic, 0-based bonds
MOLS = [
    (["C", "C", "O", "H", "H", "H", "H"],
     [[0.0, 0.0, 0.0], [1.5, 0.1, 0.0], [2.2, 1.1, 0.1], [-0.4, 1.0, 0.2], [-0.3, -0.5, 0.9],
      [-0.35, -0.6, -0.85], [2.0, -0.85, -0.1]],
     [0, 1, 1, 2, 0, 3, 0, 4, 0, 5, 1, 6], 0),
    (["N", "H", "H", "H", "H"],
     [[0.0, 0.0, 0.0], [0.6, 0.6, 0.6], [-0.6, -0.6, 0.6], [-0.6, 0.6, -0.6], [0.62, -0.58, -0.6]],
     [0, 1, 0, 2, 0, 3, 0, 4], 1),
    (["O", "H"], [[0.0, 0.0, 0.0], [0.0, 0.1, 0.97]], [0, 1], -1),
]


def batch(origin="coordinate", shift=None):
    conv = DataConventions.from_config({"origin": origin})
    ms = []
    for sym, pos, bonds, q in MOLS:
        info = {"bonds": torch.tensor(bonds, dtype=torch.float64).numpy(), "charge": q}
        p = torch.tensor(pos)
        if shift is not None:
            p = shift(p)
        ms.append(frame_to_molecule({"symbols": sym, "positions": p.numpy(), "info": info, "arrays": {}}, conv))
    return collate(ms)


def random_model(kind, seed=0, **el):
    torch.manual_seed(seed)
    m = PropertyModel([1, 6, 7, 8], {"electrical": {"kind": kind, **el}})
    with torch.no_grad():
        for p in m.parameters():
            p.add_(0.05 * torch.randn_like(p))
    return m


def test_units():
    assert abs(to_au("kcal/mol", "energy") - 1 / 627.5094740631) < 1e-15
    assert abs(to_au("kcal/mol/angstrom", "forces") - 0.529177210903 / 627.5094740631) < 1e-15
    assert abs(to_au("debye", "dipole") - 0.3934303) < 1e-12
    assert parse_unit("au")[0] == 1.0
    with pytest.raises(ValueError):
        to_au("ev", "forces")


def test_comment_parsing():
    info = parse_comment('name=x energy=-1.5 dipole="1 2 3" bonds="0 1 1 2" pbc="F F F" Properties=species:S:1:pos:R:3')
    assert info["energy"] == -1.5 and list(info["dipole"]) == [1, 2, 3] and info["name"] == "x"


def test_response_closed_form_matches_explicit_minimization():
    torch.manual_seed(1)
    pos = torch.randn(7, 3)
    bonds = torch.tensor([[0, 1], [1, 2], [1, 3], [4, 5], [5, 6]])
    bi = torch.tensor([0, 0, 0, 0, 1, 1, 1])
    bb = torch.tensor([0, 0, 0, 1, 1])
    A = torch.randn(7, 3, 3)
    m2 = torch.randn(7, 3, 3)
    p = ResponseParameters(q0=torch.tensor([0, 0, 0, 0, -1 / 3, -1 / 3, -1 / 3.0]), chi=torch.randn(7),
                           eta=torch.rand(7) + 0.5, compliance=torch.rand(5), mu0=torch.randn(7, 3),
                           alpha=A @ A.transpose(1, 2), m2=m2 + m2.transpose(1, 2), c_quad=torch.rand(7))
    origin = torch.randn(2, 3)
    sol = response(p, pos, bonds, bi, bb, 2, origin)
    F = torch.zeros(2, 3, requires_grad=True)
    G = torch.zeros(2, 3, 3, requires_grad=True)
    e = field_energy(p, pos, bonds, bi, bb, 2, F, 0.5 * (G + G.transpose(1, 2)), origin)
    assert e.abs().max() < 1e-14
    gF, gG = torch.autograd.grad(e.sum(), (F, G), create_graph=True)
    torch.testing.assert_close(-gF, sol.dipole)
    torch.testing.assert_close(-2 * gG, sol.second_moment)
    al = torch.stack([torch.autograd.grad(-gF[:, k].sum(), F, retain_graph=True)[0] for k in range(3)], 1)
    torch.testing.assert_close(al, sol.polarizability)
    Ft, Gt = 0.1 * torch.randn(2, 3), 0.1 * torch.randn(2, 3, 3)
    Gt = Gt + Gt.transpose(1, 2)
    torch.testing.assert_close(sol.energy(Ft, Gt), field_energy(p, pos, bonds, bi, bb, 2, Ft, Gt, origin))
    assert torch.linalg.eigvalsh(sol.P).min() > -1e-12
    q = torch.zeros(2).index_add(0, bi, sol.charges)
    torch.testing.assert_close(q, torch.tensor([0.0, -1.0]))


@pytest.mark.parametrize("kind", ["sqe", "direct"])
def test_model_equivariance_and_charge(kind):
    m = random_model(kind)
    b = batch()
    o = m(b)
    Q, _ = torch.linalg.qr(torch.randn(3, 3))
    if torch.det(Q) > 0:
        Q = -Q                                   # improper rotation
    t = torch.randn(3)
    b2 = batch()
    b2.pos = b.pos @ Q.T + t
    b2.origin = b.origin @ Q.T + t
    o2 = m(b2)
    torch.testing.assert_close(o2["energy"], o["energy"])
    torch.testing.assert_close(o2["dipole"], o["dipole"] @ Q.T)
    torch.testing.assert_close(o2["second_moment"], Q @ o["second_moment"] @ Q.T)
    torch.testing.assert_close(o2["polarizability"], Q @ o["polarizability"] @ Q.T)
    torch.testing.assert_close(torch.zeros(3).index_add(0, b.batch_idx, o["charges"]), b.charge)
    assert torch.linalg.eigvalsh(o["polarizability"]).min() > 0


def test_model_field_derivatives_are_the_moments():
    m = random_model("sqe")
    b = batch()
    F = torch.zeros(3, 3, requires_grad=True)
    G = torch.zeros(3, 3, 3, requires_grad=True)
    o = m(b, field=F, field_gradient=0.5 * (G + G.transpose(1, 2)))
    torch.testing.assert_close(o["energy"], o["energy_pes"])          # zero-field subtracted
    gF, gG = torch.autograd.grad(o["energy"].sum(), (F, G), create_graph=True)
    torch.testing.assert_close(-gF, o["dipole"])
    torch.testing.assert_close(-2 * gG, o["second_moment"])


def _fd(f, pos, h=1e-5):
    cols = []
    for a in range(pos.shape[0]):
        for i in range(3):
            d = torch.zeros_like(pos)
            d[a, i] = h
            cols.append((f(pos + d) - f(pos - d)) / (2 * h))
    return torch.stack(cols)                     # (3N, ...)


@pytest.mark.parametrize("kind", ["sqe", "direct"])
def test_derivative_labels_layout(kind):
    """Labels built by finite differences in the documented layouts give ~zero residuals."""
    m = random_model(kind)
    b = batch()
    N = b.pos.shape[0]

    def outs(p):
        with torch.no_grad():
            return m(b, p)

    E = lambda p: outs(p)["energy"].sum()  # noqa: E731
    o0 = outs(b.pos)
    F_lab = -_fd(E, b.pos).reshape(N, 3)
    H_full = -_fd(lambda p: _forces(m, b, p).reshape(-1), b.pos)      # (3N, 3N), H = -dF/dx
    mu_d = _fd(lambda p: outs(p)["dipole"], b.pos)          # (3N, M, 3)
    q_d = _fd(lambda p: outs(p)["quadrupole"], b.pos)       # (3N, M, 6)
    a_d = _fd(lambda p: outs(p)["polarizability"], b.pos)   # (3N, M, 3, 3)
    labels = {}
    M = b.n_systems
    ones = torch.ones(M, dtype=torch.bool)
    labels["energy"] = (o0["energy"], ones)
    labels["forces"] = (F_lab, ones)
    nmax = int(b.n_atoms.max())
    H = torch.zeros(M, 3 * nmax, 3 * nmax)
    offs = [0] + torch.cumsum(b.n_atoms, 0).tolist()
    for s in range(M):
        k = slice(3 * offs[s], 3 * offs[s + 1])
        n3 = 3 * int(b.n_atoms[s])
        H[s, :n3, :n3] = H_full[k, k]
    labels["hessian"] = (H, ones)
    sysof = b.batch_idx
    rows = torch.arange(3 * N).reshape(N, 3)
    labels["dipole"] = (o0["dipole"], ones)
    labels["dipole_derivatives"] = (mu_d[rows, sysof[:, None]], ones)          # (N, 3, 3) [a, i, k]
    labels["quadrupole"] = (o0["quadrupole"], ones)
    labels["quadrupole_derivatives"] = (q_d[rows, sysof[:, None]], ones)
    labels["polarizability"] = (o0["polarizability"], ones)
    labels["polarizability_derivatives"] = (a_d[rows, sysof[:, None]], ones)
    b.labels = labels
    loss_cfg = {q: {"weight": 1.0, "scale": 1.0} for q in labels}
    report = {q: 1.0 for q in labels}
    for training, probes in ((False, {}), (True, {"hessian": 3, "dipole_derivatives": 2,
                                                   "quadrupole_derivatives": 2, "polarizability_derivatives": 2})):
        pred, _ = predict(m, b, set(labels), training=training, probes=probes)
        _, st = loss_terms(pred, b, loss_cfg, report)
        for q, (s2, s1, n) in st.items():
            lab = labels[q][0]
            rel = (s2 / n) ** 0.5 / float(lab.pow(2).mean().sqrt())
            assert rel < 1e-5, (q, training, rel)   # finite-difference labels


def _forces(m, b, p):
    p = p.detach().clone().requires_grad_(True)
    return -torch.autograd.grad(m(b, p)["energy"].sum(), p)[0]
