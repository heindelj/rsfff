# ECE property models for small molecules

Train edge-cluster-expansion (ECE) models of small molecules on any mix of

| quantity | symbol | from the model as |
|---|---|---|
| energy | E | sum of bond energies on the ECE + per-element references |
| forces | −∂E/∂R | autograd |
| Hessian | ∂²E/∂R² | autograd (Hessian-vector products in training) |
| dipole | μ | electrical head |
| quadrupole (second moment) | Θ / M₂ | electrical head |
| dipole derivatives (APT) | ∂μ/∂R | autograd |
| quadrupole derivatives | ∂Θ/∂R | autograd |
| dipole polarizability | α | electrical head |
| polarizability derivatives | ∂α/∂R | autograd |

from extxyz files, with one config file. Only `bb` is needed (plus `pyyaml` for YAML configs and
`matplotlib` for parity plots).

```bash
pip install -e '.[scripts]'          # in the bb checkout: bb + pyyaml + matplotlib
python scripts/ece_props/train.py scripts/ece_props/config.yaml
python scripts/ece_props/train.py scripts/ece_props/config.yaml --set model.electrical.kind=direct --set train.out_dir=runs/direct
python scripts/ece_props/evaluate.py runs/ece_sqe/best.pt data/test.xyz --plot
python -m pytest scripts/ece_props/test_eceprops.py -q
```

Everything runs in float64. Use `train.device: cuda` on a GPU; avoid MPS (no float64).

## Files

| file | what it is |
|---|---|
| `train.py` | the trainer (`config.yaml` + `--set key=value` overrides) |
| `evaluate.py` | errors, predictions (`predictions.npz`) and parity plots for a checkpoint on any extxyz files |
| `config.yaml` | annotated example with every option at its default (set up for the fff_bonding `pyscf-all` export) |
| `eceprops/data.py` | extxyz reader (no ASE), unit conversion, label layouts, batching |
| `eceprops/units.py` | unit strings → atomic units, with a dimension check |
| `eceprops/response.py` | the no-Coulomb split-charge (SQE) + atomic dipole/quadrupole response solve |
| `eceprops/models.py` | `PropertyModel`: ECE energy head + electrical head (`none` / `direct` / `sqe`) |
| `eceprops/training.py` | derivatives by autograd, losses, metrics, data-driven initialisation |
| `test_eceprops.py` | equivariance, charge conservation, closed-form vs explicit response, derivative layouts |

## Data

One extxyz frame per labelled geometry; files can mix molecules, and frames can carry different
subsets of labels (a frame without a label is simply left out of that loss term). Each frame needs:

- `species` and `pos` columns (positions in `data.units.positions`, Angstrom by default);
- `bonds="i j i j ..."`: the covalent topology as flat 0-based pairs. The ECE is a bonded model:
  the topology is fixed and every bond, angle and torsion it implies is described. If `bonds` is
  missing it is perceived from each frame's geometry (1.2 × covalent radii), which can drop bonds
  in stretched frames, so it is better to write it;
- `charge=` (total charge; default 0). Optional `name=` (used by `split_by: name` and the plots).

Labels (keys are configurable in `data.keys`; the defaults below are the quantity names):

| quantity | extxyz | layout | default unit |
|---|---|---|---|
| energy | comment | scalar | hartree |
| forces | `Properties` column | (N, 3) | hartree/bohr |
| hessian | comment | (3N)², atom-major: row `3a+i`, column `3b+j` | hartree/bohr^2 |
| dipole | comment | 3 | e*bohr |
| quadrupole | comment | 6 in `data.quadrupole.order` (or 9) | e*bohr^2 |
| dipole_derivatives | comment | N·3·3, `[atom a, direction i, component k]` = ∂μ_k/∂R_ai | e |
| quadrupole_derivatives | comment | N·3·6, `[a, i, k]`, k in the quadrupole order | e*bohr |
| polarizability | comment | 9 row-major (or 6 in `data.tensor6_order`) | bohr^3 |
| polarizability_derivatives | comment | N·3·9 `[a, i, jk]` (or N·3·6) | bohr^2 |

Unit strings combine `hartree ev mev kcal kj mol bohr angstrom e debye` with `*`, `/` and `^n`
(`kcal/mol/angstrom`, `debye*angstrom`, `ev/angstrom^2`); `au` means already atomic. They are
checked against each quantity's dimensions. Polarizabilities are volumes (`bohr^3`, `angstrom^3`).

**Quadrupoles.** `data.quadrupole.convention: primitive` means the raw second moment
Σ q x_a x_b (Q-Chem/PySCF "second moments", trace included; the fff_bonding exports);
`traceless` means Buckingham Θ = ½ Σ q (3 x_a x_b − r² δ_ab). The model compares in whichever
convention and component order the file uses, and the same for the derivatives.

**Origin.** Moments of ions depend on the origin. `data.origin: coordinate` (default) takes the
moments about the file's coordinate origin; `nuclear_charge` / `mass` about that frame's centre,
held fixed when differentiating (as in analytic QC derivatives, which are at a fixed origin).

The fff_bonding exports (`~/research/fff_bonding/cl/data/sets/pyscf-all/vacuum.xyz`) already
follow this format: point `data.train` at them and use the example config's key map
(`quadrupole: fragment_second_moments`, `quadrupole_derivatives: second_moment_derivatives`).
They have no polarizability derivatives; the loss just skips quantities a file does not have.

## Models

All three variants share the energy head:

    E(R) = Σ_i E0[Z_i] + s · Σ_bonds ε_b(R)

`ε_b` is a `bb.heads.EdgeScalarReadout` on `bb.features.EdgeClusterExpansion` features of the
bond graph (bond, near and far densities in the bond frame up to correlation order 2: bond
lengths, angles, torsions, impropers and their cross terms). `E0` is a least-squares fit of the
training energies on composition and `s` the residual spread per bond, both fixed before training.

`model.electrical.kind` picks the electrical head. Both non-trivial kinds read per-directed-edge
outputs of one `bb.heads.EdgeReadout` (built in each bond's frame and rotated back, so exactly
O(3)-equivariant) and sum them onto the edge's source atom; per-element tables give the
baselines. Both then go through the same `response()` function, so moments and polarizabilities
are always field derivatives of one field energy (below).

**`none`** — energy only (E, F, H).

**`direct`** — no solve. Charges `q = Q/n + Σ bond flows` (flows antisymmetric over the two
directions of a bond, so Σq = Q exactly), atomic dipoles (1o), atomic primitive second moments
(per-element trace + learned 0e + 2e), and PSD atomic polarizabilities
`α_i = α_Z (e^{a_i} I + T_i)²` (T_i traceless from the 2e outputs). μ = Σ q r + Σ μ_i,
M₂ = Σ q r r + Σ (μ r + r μ) + Σ M₂,i, α = Σ α_i.

**`sqe`** — the no-Coulomb split-charge response model (`eceprops/response.py`). The head
predicts electronegativities χ_i, hardnesses η_i > 0, bond compliances s_b ≥ 0 (s = 1/κ),
permanent atomic dipoles μ0_i and second moments M₂,i, PSD atomic polarizabilities α_i and
isotropic atomic quadrupole polarizabilities c_i ≥ 0. In a uniform field F and field gradient G
(potential φ(r) = −F·r − ½ r·G r) the energy of the three sectors is

    E_q = min_p Σ_i [χ_i q_i + ½ η_i q_i² + q_i φ_i] + ½ Σ_b p_b²/s_b,   q = q0 + B p
    E_μ = Σ_i [−μ0_i·E_i − ½ E_i·α_i E_i],   E_i = F + G r_i
    E_Q = Σ_i [−½ G:M₂,i − ¼ c_i G_T:G_T]

with **no Coulomb coupling** between sites (charge moves only along bonds, B is the bond
incidence matrix, and Σq is conserved for any transfers). The charge sector is one small dense
solve per molecule, `(L S + I) v = −Bᵀ(χ + η q0 + φ)`, `p = S v`, `L = Bᵀ diag(η) B`, which stays
well conditioned as s → 0 (a closed channel).

**Zero-field subtraction.** The model's field energy is `ΔE(F, G) = E(F, G) − E(0, 0)`, which is
identically zero without a field: the response sector never contributes to the PES, forces or
Hessian (those are the ECE energy head's alone), it only describes how the molecule answers a
field. Because nothing is coupled, ΔE is exactly quadratic,

    ΔE(h) = −h·M0 − ½ h·P h,     h = [F, ½ vec G]

where `M0 = [μ, vec M₂]` are the permanent moments and `P` (12×12, symmetric PSD) the
generalized polarizability: dipole polarizability `α = P[:3, :3]`, dipole–quadrupole
`A_a,bc = ∂μ_a/∂G_bc` and quadrupole polarizability `C_ab,cd = ∂M₂,ab/∂G_cd`
(`ResponseSolution.polarizability`, `.dipole_quadrupole_polarizability`,
`.quadrupole_polarizability`). All of them come in closed form from the same factorization
(13 right-hand sides); `field_energy()` does the minimize-at-F, minimize-at-0, subtract
construction literally, and the tests check that its field derivatives equal the closed form.
The charge-flow polarizability `Gᵀ S (LS + I)⁻¹ G` (G = Bᵀ[r, rr]) is translation invariant
(Bᵀ1 = 0).

Switches in `model.electrical`: `charge_flow` (sqe; false fixes q = Q/n), `atomic_dipoles`,
`atomic_polarizability`, `anisotropic_polarizability`, `atomic_quadrupoles`,
`quadrupole_polarizability` (sqe). Set `shared_ece: true` to let the electrical head read the
energy head's ECE instead of its own, and `electrical.ece: {...}` to give it different ECE
settings.

`PropertyModel.forward(batch, positions, field=F, field_gradient=G)` returns `energy` =
E(R) + ΔE(R; F, G) (and `energy_pes` = E(R)), so a trained model can be used directly in a
uniform field.

## Loss

    loss = Σ_q weight_q · mean(((pred − label) / scale_q)²)

with residuals in `report_units` (so `scale` reads as "the accuracy I'd be happy with", e.g.
0.5 kcal/mol). A quantity is trained on when its weight > 0 and the batch has its label; every
labelled quantity is reported in the validation metrics. Derivative quantities are autograd
Jacobians of the model's outputs with respect to the positions, with `create_graph` so the
loss trains through them:

- dipole / quadrupole / polarizability derivatives: one backward pass per component (3, 6, 6),
  for all molecules of the batch at once. `probes: k > 0` replaces the full Jacobian by k random
  projections per step (Σ_k w_k ∂y_k/∂R against the label contracted with the same w) — cheaper;
- Hessian: `probes: k` Gaussian Hessian-vector products per step against H_label·v (full
  Hessians, one batched column per coordinate, with `probes: 0`).

Validation and `evaluate.py` always use full Jacobians and full Hessians.

The polarizability derivatives of `sqe` differentiate through the linear solve; `direct` is the
cheaper baseline. Rough cost on 2 CPU cores, 16 molecules of ≤ 8 atoms, everything on: ~0.7 s
per step.

## Outputs

`train.out_dir/`: `config.yaml` (resolved), `log.csv` (per-epoch losses and val RMSE/MAE per
quantity), `best.pt` (lowest validation loss), `last.pt`, `metrics.json` (val/test errors of the
best model). Load a checkpoint in Python:

```python
import sys; sys.path.insert(0, "scripts/ece_props")
from evaluate import load_model
from eceprops.data import DataConventions, load_molecules, collate
model, cfg = load_model("runs/ece_sqe/best.pt")
mols = load_molecules("data/test.xyz", DataConventions.from_config(cfg["data"]))
out = model(collate(mols[:4]))       # energy, charges, dipole, second_moment, quadrupole, polarizability, solution
```
