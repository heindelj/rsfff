# Changelog

Changes to the default numerical path of an existing module are breaking (checkpoints depend on
exact numerics); they go behind a flag and are recorded here. See `docs/PLAN.md` §4.8.

## Unreleased

### Added
- Periodic boundary conditions (for the neural spin Hamiltonian). New paths only; every default
  is unchanged, so goldens and checkpoints are unaffected.
  - `bb.graph.build_periodic_graph` -> `PeriodicEdges(edge_index, shifts, offsets)`: brute force
    over the images that reach the cutoff, self-images kept, cap handled as `build_radius_graph`.
    Offsets attach to the row-1 atom: `vec(a -> b) = pos[b] + offset - pos[a]`.
  - `bb.graph.site_pair_graph` (pairs of caller-chosen sites), `bb.graph.pair_graph` ->
    `PairGraph` (the `BondGraph` layout: canonical edges then reverses, plus near / far
    environment pairs), `bb.graph.edge_offsets`.
  - `SOAPFeaturizer(..., cell=, pbc=)` / `EnergyModel(..., cell=, pbc=)`: periodic neighbor list;
    `IrrepFeatures.edge_offsets` carries the images to `EquivariantMessagePassing`, whose
    `refine` / `forward` take `edge_offsets=`. `DensityExpansion.edge_expansion(..., edge_offsets=)`.
  - `build_radius_graph` with a periodic cell still raises; the message now points at
    `build_periodic_graph`.
- `bb.features.PairClusterExpansion`: the ECE on a cutoff-based `PairGraph` (environment
  densities from a radius graph, Bessel-envelope radial bases, `EdgeFeatures.envelope`), so a
  readout vanishes smoothly at both cutoffs. Works with `EdgeScalarReadout` unchanged.
- `bb.tr`: time-reversal parity for a caller-supplied per-atom odd input (collinear moments):
  `TRFeatures`, `OddLinear`, `TREmbedding`, `TRMessagePassing`, `TRReadout`,
  `check_time_reversal`. Exact by construction (no bias or even activation on odd channels).
- Edge cluster expansion for bonded models (`docs/ece.md`). New modules only; no existing default
  path changes, so goldens and checkpoints are unaffected.
  - `bb.graph.bonded`: `bond_graph`, `line_graph`, `covalent_bonds`, `COVALENT_RADII`.
  - `bb.o3.frames`: `edge_frames`, `calibrate`, `frame_convention`, `wigner_d_recursive`,
    `rotation_about`, `MIndex`.
  - `bb.features.radial.MorseBasis`; `bb.features.edge.EdgeClusterExpansion`, `EdgeFeatures`.
  - `bb.heads.edge.EdgeScalarReadout` (sym / antisym over the two bond directions).
  - `bb.config.EdgeFeaturizerConfig`, `EdgeReadoutConfig`.
- `bb.features.edge_basis.EdgeBodyOrderBasis`: explicit, linear, body-ordered bond basis
  (`bb.config.EdgeBasisConfig`).
- `bb.heads.EdgeReadout` (equivariant per-bond outputs with the O(2) parity rule),
  `bond_to_atoms`, `flow_to_charges`; `EdgeScalarReadout(bond_basis=...)`.
- `bb.linear`: design rows for energies / forces / Hessians, ridge normal equations, nested solves.
- `EdgeFeatures.mblocks` (the SO(2)-covariant channels, for equivariant readouts).
- `bond_graph` takes a `(B, 2)` tensor and builds the graph vectorized on its device (cheap enough
  to rebuild per batch; `check=False` skips the host-side validation). The list path is unchanged.
- `EdgeClusterExpansion(..., bond_weight=)`: per-bond weights on the neighbour contributions
  (fractional bonds along a reactive blend). `None` is the old path exactly.
- `EdgeReadout(..., extra_dim=, compress=)`: caller-supplied invariant scalars per directed edge
  (`forward(ef, extra)`) and `asinh` compression of the ECE invariants. Defaults unchanged.

### Fixed
- `EdgeClusterExpansion` on a bond with no neighbours at either end (diatomics).
