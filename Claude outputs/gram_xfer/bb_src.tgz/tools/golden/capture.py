"""Capture reference ("golden") outputs from the pre-bb source repos.

Run once against snapshots of rsfff, pauli_fierz_pinn and hbq_qed, with the three importable as
``rsfff``, ``pf_pinn`` and ``hbq_qed``::

    mkdir refpkgs && cd refpkgs
    ln -s ~/dev/rsfff/src rsfff
    ln -s ~/dev/pauli_fierz_pinn/src pf_pinn
    ln -s ~/dev/hbq_qed/src/hbq_qed hbq_qed
    PYTHONPATH=refpkgs python tools/golden/capture.py --repos ~/dev --out tests/golden/data

Each case is a ``.pt`` file holding the module's constructor arguments, its state dict, the
inputs and the outputs, all in float64 on CPU. ``tests/golden`` rebuilds the bb equivalent,
loads the *same* state dict (strictly -- that is the checkpoint-compatibility test) and compares
outputs. Checkpoint cases extract the featurizer / message-passing submodules of real trained
models; ``models/`` cases record whole-model outputs for when each project is ported.
"""

from __future__ import annotations

import argparse
import math
import warnings
from pathlib import Path

import torch

warnings.filterwarnings("ignore")
torch.set_default_dtype(torch.float64)

OUT = Path("tests/golden/data")


def _detach(obj):
    """Deep-copy tensors so a view does not drag its whole storage into the file."""
    if isinstance(obj, torch.Tensor):
        return obj.detach().clone().contiguous()
    if isinstance(obj, dict):
        # cuequivariance's fx-graph constants (``...sc.f.m.graphs.N.graph.cK``) are rebuilt at
        # construction and are thousands of 0-d tensors; they are not model state worth keeping.
        return type(obj)(
            (k, _detach(v)) for k, v in obj.items() if not (isinstance(k, str) and ".graphs." in k)
        )
    if isinstance(obj, (list, tuple)):
        return type(obj)(_detach(v) for v in obj)
    return obj


def save(name: str, **payload) -> None:
    payload = _detach(payload)
    path = OUT / f"{name}.pt"
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, path)
    print(f"  wrote {path} ({path.stat().st_size / 1024:.0f} KB)")


# ----------------------------------------------------------------------------- geometry
def molecules(seed: int = 0, sizes=(4, 6, 9), types=(1, 6, 8), box: float = 3.2):
    """A flat batch of random, non-overlapping 'molecules' (min distance 0.95 A)."""
    g = torch.Generator().manual_seed(seed)
    pos, z, b = [], [], []
    for m, n in enumerate(sizes):
        pts: list[torch.Tensor] = []
        while len(pts) < n:
            p = (torch.rand(3, generator=g) - 0.5) * 2 * box * (n / 9) ** (1 / 3)
            if all((p - q).norm() > 0.95 for q in pts):
                pts.append(p)
        pos.append(torch.stack(pts) + 50.0 * m)        # far apart: no cross-molecule edges
        z.append(torch.tensor(types)[torch.randint(len(types), (n,), generator=g)])
        b.append(torch.full((n,), m, dtype=torch.long))
    return torch.cat(pos), torch.cat(z), torch.cat(b)


class B:
    """Duck-typed batch the source featurizers accept."""

    def __init__(self, positions, atomic_numbers, batch_idx):
        self.positions = positions
        self.atomic_numbers = atomic_numbers
        self.batch_idx = batch_idx
        self.n_systems = int(batch_idx.max()) + 1


def lam_out(feats) -> dict:
    return {
        "inv": feats.inv_feats, "equiv": feats.equiv_feats, "vec": feats.vec_feats,
        "species_idx": feats.species_idx, "batch_idx": feats.batch_idx,
        "edge_index": feats.edge_index,
    }


def randomize_(module: torch.nn.Module, seed: int, scale: float = 0.3) -> None:
    """Overwrite every parameter with seeded noise (zero-initialized readouts included)."""
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for _, p in sorted(module.named_parameters()):
            p.copy_(torch.randn(p.shape, generator=g, dtype=p.dtype) * scale)


# ----------------------------------------------------------------------------- featurizers
FEATURIZER_CASES = [
    # name, kwargs
    ("plain_l3", dict(cutoff=4.0, n_max=3, l_max=3, selected_lambdas=(0, 1, 2, 3))),
    ("plain_02", dict(cutoff=4.5, n_max=4, l_max=2, selected_lambdas=(0, 2))),
    ("compress", dict(cutoff=4.0, n_max=3, l_max=3, selected_lambdas=(0, 1, 2), density_channels=5)),
    ("bis", dict(cutoff=4.0, n_max=2, l_max=2, selected_lambdas=(0, 1, 2),
                 bispectrum=dict(implementation="sym_contraction", per_species_weights=False))),
    ("bis_compress_species", dict(cutoff=4.0, n_max=3, l_max=2, selected_lambdas=(0, 2), density_channels=4,
                                  bispectrum=dict(implementation="sym_contraction", per_species_weights=True))),
]


class Cfg:
    def __init__(self, **kw):
        self.__dict__.update(kw)


def capture_featurizers(repo: str, Featurizer) -> None:
    pos, z, b = molecules(1)
    for name, kw in FEATURIZER_CASES:
        for backend in ("e3nn", "cue"):
            kwargs = dict(kw, neighbor_types=(1, 6, 8), backend=backend)
            if "bispectrum" in kwargs:
                kwargs["bispectrum"] = Cfg(**kwargs["bispectrum"])
            torch.manual_seed(7)
            try:
                f = Featurizer(**kwargs)
            except Exception as exc:  # pragma: no cover
                print(f"  skip {repo}/{name}/{backend}: {exc}")
                continue
            f = f.double()
            out = f(B(pos, z, b))
            save(
                f"features/{repo}_{name}_{backend}",
                kwargs={**kw, "neighbor_types": (1, 6, 8), "backend": backend},
                state_dict=f.state_dict(), inputs=dict(positions=pos, atomic_numbers=z, batch_idx=b),
                outputs=lam_out(out),
            )


def capture_rsfff_partitions() -> None:
    from rsfff.features.features import (
        FlatLambdaSOAPFeaturizer, FlatStateSOAPFeaturizer, _build_cross_power_spectrum_specs,
        cross_equivariant_power_spectrum,
    )

    pos, z, b = molecules(2, sizes=(6, 8))
    # two fragments per molecule
    frag = torch.cat([torch.tensor([0] * 3 + [1] * 3), torch.tensor([2] * 4 + [3] * 4)])
    for backend in ("e3nn", "cue"):
        kw = dict(cutoff=4.0, n_max=3, l_max=2, selected_lambdas=(0, 1, 2), density_channels=4,
                  neighbor_types=(1, 6, 8), backend=backend)
        torch.manual_seed(3)
        f = FlatLambdaSOAPFeaturizer(**kw).double()
        batch = B(pos, z, b)
        grouped = f(batch, frag)
        g_c, cross = f(batch, frag, also_cross=True)
        g_u, full = f(batch, frag, also_ungrouped=True)
        gen = torch.Generator().manual_seed(11)

        def weight_fn(edge_index, gen=gen):
            # deterministic per-edge soft weight from the endpoints' fragment ids
            same = (frag[edge_index[0]] == frag[edge_index[1]]).double()
            return 0.15 + 0.7 * same
        s_in, s_env = f(batch, frag, also_cross=True, edge_weight=weight_fn)

        # cross spectrum on the soft densities
        species = f._species_lut[z]
        ei = f._build_edges(pos, b)
        RY = f.density.edge_expansion(pos, ei)
        w = weight_fn(ei)
        A_in = f._compress(f.density.scatter_species(RY, ei, species, len(z), edge_weight=w))
        A_env = f._compress(f.density.scatter_species(RY, ei, species, len(z), edge_weight=1 - w))
        specs, bufs = _build_cross_power_spectrum_specs(
            l_max=2, selected_lambdas=(0, 2), n_channels_a=4, n_channels_b=4, backend=f.backend)
        xc = cross_equivariant_power_spectrum(A_in, A_env, 2, (0, 2), specs_by_lam=specs, cg_lookup=bufs)
        save(
            f"features/rsfff_partition_{backend}",
            kwargs=kw, state_dict=f.state_dict(),
            inputs=dict(positions=pos, atomic_numbers=z, batch_idx=b, fragment_idx=frag),
            outputs=dict(
                grouped=lam_out(grouped), cross_grouped=lam_out(g_c), cross=lam_out(cross),
                ungrouped_grouped=lam_out(g_u), full=lam_out(full),
                soft_in=lam_out(s_in), soft_env=lam_out(s_env), soft_edge_weight=w, soft_edges=ei,
                x_cross={k: v for k, v in xc.items()},
            ),
        )

        # state featurizer
        kws = dict(cutoff=4.0, n_max=3, l_max=2, neighbor_types=(1, 6, 8), weight_channels=4,
                   selected_lambdas=(0, 1, 2), backend=backend)
        torch.manual_seed(5)
        fs = FlatStateSOAPFeaturizer(**kws).double()
        aw = torch.randn(len(z), 4, generator=torch.Generator().manual_seed(9))
        out = fs(batch, aw, frag)
        save(
            f"features/rsfff_state_{backend}",
            kwargs=kws, state_dict=fs.state_dict(),
            inputs=dict(positions=pos, atomic_numbers=z, batch_idx=b, fragment_idx=frag, atom_weights=aw),
            outputs=lam_out(out),
        )


# ----------------------------------------------------------------------------- message passing
def capture_mp(repo: str, MP) -> None:
    from rsfff.features.features import FlatLambdaSOAPFeaturizer

    pos, z, b = molecules(4)
    for backend in ("e3nn", "cue"):
        torch.manual_seed(1)
        f = FlatLambdaSOAPFeaturizer(cutoff=4.0, n_max=2, l_max=2, neighbor_types=(1, 6, 8),
                                     selected_lambdas=(0, 2), backend=backend).double()
        feats = f(B(pos, z, b))
        emb = torch.randn(len(z), 5, generator=torch.Generator().manual_seed(2))
        for name, kw in [
            ("l2", dict(layers=2, channels=6, lmax=2, num_basis=5, radial_hidden=7, avg_num_neighbors=6.5)),
            ("l4_3layers", dict(layers=3, channels=4, lmax=4, num_basis=6, radial_hidden=8, avg_num_neighbors=3.0)),
            ("legacy_avg", dict(layers=1, channels=5, lmax=2, num_basis=4, radial_hidden=6, avg_num_neighbors=None)),
        ]:
            torch.manual_seed(4)
            mp = MP(p0=feats.inv_feats.shape[1], p2=feats.equiv_feats.shape[2], emb_dim=5,
                    cutoff=4.0, backend=f.backend, **kw).double()
            randomize_(mp, 12)
            inv, equiv = mp(feats.inv_feats, feats.equiv_feats, pos, feats.edge_index, emb)
            save(
                f"mp/{repo}_{name}_{backend}",
                kwargs=dict(p0=feats.inv_feats.shape[1], p2=feats.equiv_feats.shape[2], emb_dim=5,
                            cutoff=4.0, backend=backend, **kw),
                state_dict=mp.state_dict(),
                inputs=dict(inv=feats.inv_feats, equiv=feats.equiv_feats, positions=pos,
                            edge_index=feats.edge_index, emb=emb),
                outputs=dict(inv=inv, equiv=equiv),
            )


# ----------------------------------------------------------------------------- heads
def head_inputs(n=17, p0=11, p1=7, p2=9, emb=4, seed=0):
    g = torch.Generator().manual_seed(seed)
    return dict(
        inv=torch.randn(n, p0, generator=g), emb=torch.randn(n, emb, generator=g),
        vec=torch.randn(n, 3, p1, generator=g), equiv=torch.randn(n, 5, p2, generator=g),
    )


def capture_heads() -> None:
    from pf_pinn.models import heads as ph
    from hbq_qed.ml import heads as hh
    from rsfff.mlip import response_heads as rh, heads as rmh
    from rsfff.ff.multipole import irrep2_to_spherical
    from rsfff.features import get_backend

    x = head_inputs()
    n, p0, p1, p2, e = x["inv"].shape[0], x["inv"].shape[1], x["vec"].shape[2], x["equiv"].shape[2], x["emb"].shape[1]
    cases = []

    def add(name, ctor, kwargs, call):
        torch.manual_seed(0)
        m = ctor(**kwargs).double()
        randomize_(m, hash(name) % 1000)
        out = call(m)
        cases.append(name)
        save(f"heads/{name}", kwargs={k: v for k, v in kwargs.items() if not isinstance(v, torch.Tensor)},
             state_dict=m.state_dict(), inputs=x, outputs=out)

    for pos_iso in (False, True):
        for own in (True, False):
            kw = dict(p0=p0, p2=p2 if own else 6, emb_dim=e, hidden=8, depth=2, equiv_channels=6,
                      positive_isotropic=pos_iso, own_reduce=own)
            eq = x["equiv"] if own else x["equiv"][..., :6]
            add(f"pf_alpha_iso{int(pos_iso)}_own{int(own)}", ph.AtomicAlphaHead, kw,
                lambda m, eq=eq: {"out": m(x["inv"], x["emb"], eq)})
    add("pf_response", ph.AtomicResponseHead, dict(p0=p0, kin=p2, emb_dim=e, channels=3, hidden=8, depth=2),
        lambda m: {"out": m(x["inv"], x["emb"], x["equiv"])})
    add("pf_vector", ph.AtomicVectorHead, dict(p0=p0, p1=p1, emb_dim=e, hidden=8, depth=2, equiv_channels=5),
        lambda m: {"out": m(x["inv"], x["emb"], x["vec"])})
    for pos_ in (True, False):
        add(f"pf_scalar_pos{int(pos_)}", ph.AtomicScalarHead,
            dict(p0=p0, emb_dim=e, hidden=8, depth=2, positive=pos_, floor=0.2, init_value=1.3),
            lambda m: {"out": m(x["inv"], x["emb"])})
    add("pf_ratio", ph.AtomicRatioHead, dict(p0=p0, emb_dim=e, hidden=8, depth=1, v_min=0.2, v_max=1.4, v_init=0.6),
        lambda m: {"out": m(x["inv"], x["emb"])})

    add("hbq_vector", hh.AtomicVectorHead, dict(p0=p0, p1=p1, emb_dim=e, hidden=8, depth=2, equiv_channels=5),
        lambda m: {"out": m(x["inv"], x["emb"], x["vec"])})
    add("hbq_scalar", hh.AtomicScalarHead, dict(p0=p0, emb_dim=e, hidden=8, depth=2),
        lambda m: {"out": m(x["inv"], x["emb"])})
    pos = torch.randn(n, 3, generator=torch.Generator().manual_seed(5)) * 2 + 3.0
    bidx = torch.tensor([0] * 6 + [1] * 5 + [2] * 6)
    tq = torch.tensor([0.0, 1.0, -1.0])
    add("hbq_dipole", hh.MolecularDipoleHead,
        dict(p0=p0, p1=p1, emb_dim=e, hidden=8, depth=2, equiv_channels=5),
        lambda m: dict(zip(("dipole", "charges", "atom_dipoles"),
                           m(x["inv"], x["emb"], x["vec"], pos, bidx, 3, tq))) | {"positions": pos, "batch_idx": bidx, "total_charge": tq})
    species = torch.tensor([0, 1, 2, 3] * 4 + [1])
    add("hbq_energy", hh.MolecularEnergyHead, dict(p0=p0, emb_dim=e, n_species=4, hidden=8, depth=2, reference=-3.5),
        lambda m: dict(zip(("energy", "atomic"), m(x["inv"], x["emb"], species, bidx, 3))) | {"species_idx": species, "batch_idx": bidx})

    v2s = get_backend("e3nn").irrep6_to_voigt()
    for p_env in (0, 3):
        kw = dict(p0=p0 - p_env, p2=p2 - p_env, emb_dim=e, irrep6_to_voigt=v2s, p_env=p_env, p2_env=p_env,
                  hidden=8, depth=2, equiv_channels=6)
        add(f"rsfff_alpha_env{p_env}", rh.AtomicAlphaHead, kw, lambda m: {"out": m(x["inv"], x["emb"], x["equiv"])})
        kw = dict(p0=p0 - p_env, p1=p1 - p_env, emb_dim=e, p_env=p_env, p1_env=p_env, hidden=8, depth=2, equiv_channels=4)
        add(f"rsfff_vector_env{p_env}", rh.AtomicVectorHead, kw, lambda m: {"out": m(x["inv"], x["emb"], x["vec"])})
        kw = dict(p0=p0 - p_env, p2=p2 - p_env, emb_dim=e, irrep2_to_spherical=irrep2_to_spherical(v2s),
                  p_env=p_env, p2_env=p_env, hidden=8, depth=2, equiv_channels=4)
        add(f"rsfff_quad_env{p_env}", rh.AtomicQuadrupoleHead, kw, lambda m: {"out": m(x["inv"], x["emb"], x["equiv"])})
    sp = torch.tensor([0, 1, 2] * 5 + [1, 2])
    add("rsfff_energy", rmh.AtomicEnergyHead, dict(p0=p0, n_species=3, emb_dim=4, hidden=8, depth=2),
        lambda m: {"out": m(x["inv"], sp), "species_idx": sp})


def capture_coupling() -> None:
    from pf_pinn.models import heads as ph
    from rsfff.ff.state_invariants import state_invariants
    from rsfff.ff.multipole import irrep2_to_spherical
    from rsfff.features import get_backend

    g = torch.Generator().manual_seed(21)
    n, k = 9, 4
    lam = torch.randn(n, 3, generator=g)
    vec_k = torch.randn(n, 3, k, generator=g)
    equiv = torch.randn(n, 5, 6, generator=g)
    inv = torch.randn(n, 7, generator=g)
    v2i = ph.voigt_to_irrep6_matrix()[:, 1:]
    pf = dict(
        lambda_2e=ph.lambda_2e(lam, v2i), lambda_invariant=ph.lambda_invariant(lam),
        vec_lambda_0e=ph.vec_lambda_0e(vec_k, lam), vec_lambda_2e=ph.vec_lambda_2e(vec_k, lam, v2i),
        augment_inv=ph.augment_inv(inv, lam), augment_equiv=ph.augment_equiv(equiv, lam, v2i),
        irrep6_to_voigt=ph.irrep6_to_voigt_matrix(), voigt_to_irrep6=ph.voigt_to_irrep6_matrix(),
    )
    v2s = get_backend("e3nn").irrep6_to_voigt()
    to_sph = irrep2_to_spherical(v2s)
    st_in = dict(
        q=torch.randn(n, generator=g), mu=torch.randn(n, 3, generator=g), quad_s=torch.randn(n, 5, generator=g),
        potential=torch.randn(n, generator=g), field=torch.randn(n, 3, generator=g),
        field_gradient=torch.randn(n, 5, generator=g), vec_feats=torch.randn(n, 3, 5, generator=g),
        equiv_feats=torch.randn(n, 5, 6, generator=g), vec_reduce=torch.randn(5, k, generator=g),
        equiv_reduce=torch.randn(6, k, generator=g),
    )
    st = state_invariants(equiv_channels=k, to_spherical=to_sph, **st_in)
    save("coupling/pf_and_rsfff", inputs=dict(lam=lam, vec_k=vec_k, equiv=equiv, inv=inv, **{f"st_{a}": b for a, b in st_in.items()}),
         outputs=dict(**pf, state_invariants=st, irrep2_to_spherical=to_sph))


# ----------------------------------------------------------------------------- checkpoints
def capture_checkpoints(repos: Path) -> None:
    from hbq_qed.ml.train import load_model as hbq_load
    from pf_pinn.calculator import load_pf_model

    pos, z, b = molecules(8, sizes=(5, 9))
    batch = B(pos, z, b)

    def sub(name, model, ntypes):
        f = model.featurizer
        zz = torch.tensor(ntypes)[torch.randint(len(ntypes), (len(z),), generator=torch.Generator().manual_seed(1))]
        bt = B(pos, zz, b)
        feats = f(bt)
        payload = dict(
            featurizer_state=f.state_dict(),
            inputs=dict(positions=pos, atomic_numbers=zz, batch_idx=b),
            features=lam_out(feats),
        )
        mp = getattr(model, "mp", None)
        if mp is not None:
            emb = model.species_emb(feats.species_idx)
            inv, equiv = mp(feats.inv_feats, feats.equiv_feats, pos, feats.edge_index, emb)
            payload.update(mp_state=mp.state_dict(), emb=emb, mp_out=dict(inv=inv, equiv=equiv),
                           mp_kwargs=dict(p0=mp.p0, p2=mp.p2, emb_dim=emb.shape[1], cutoff=mp.cutoff,
                                          layers=len(mp.convs), channels=mp.channels, lmax=mp.lmax,
                                          num_basis=mp.num_basis,
                                          radial_hidden=mp.convs[0].radial_mlp[0].out_features,
                                          avg_num_neighbors=mp.avg_num_neighbors))
        fk = dict(cutoff=f.cutoff, n_max=f.n_max, l_max=f.l_max, neighbor_types=tuple(ntypes),
                  selected_lambdas=f.selected_lambdas, backend=f.backend.name,
                  density_channels=f.density_channels,
                  max_num_neighbors=getattr(f, "max_num_neighbors", getattr(f, "max_neighbors", None)))
        bis = getattr(f, "bispectrum", None)
        payload["featurizer_kwargs"] = fk
        payload["has_bispectrum"] = bis is not None
        if bis is not None:
            bk = dict(out_mul=bis.out_mul, per_species_weights=bis.num_elements > 1)
            if hasattr(bis, "sc"):
                bk.update(implementation="sym_contraction", contraction_degree=bis.sc.contraction_degree)
            elif hasattr(bis, "poly"):
                bk.update(implementation="descriptor")
            payload["bispectrum_kwargs"] = bk
        save(f"checkpoints/{name}", **payload)
        return model, bt

    path = repos / "hbq_qed/checkpoints/dipole_e3nn/best.pt"
    model, cfg = hbq_load(path)
    model = model.double()
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    payload_cfg = ckpt["config"]["model"]
    m, bt = sub("hbq_dipole_e3nn", model, ckpt["neighbor_types"])
    torch.save(dict(model_config=payload_cfg), OUT / "checkpoints/hbq_dipole_e3nn_config.pt")

    pf_dir = repos / "pauli_fierz_pinn/qed_roundtrip/training/checkpoints"
    for name in ("qed_fluctuation_e3nn_member00_seed0", "qed_fluctuation_cue_member00_seed0",
                 "qed_fluctuation_mp2_bis_l1_e3nn_member00_seed0", "qed_fluctuation_mp2_bis_l1_cue_member00_seed0",
                 "qed_fluctuation_mp1_nobis_e3nn_member00_seed0"):
        p = pf_dir / name / "best.pt"
        if not p.exists():
            print(f"  missing {p}")
            continue
        model, config, ntypes = load_pf_model(p, dtype=torch.float64)
        sub(f"pf_{name}", model, ntypes)


def main() -> None:
    global OUT
    ap = argparse.ArgumentParser()
    ap.add_argument("--repos", type=Path, required=True, help="directory holding the three repos")
    ap.add_argument("--out", type=Path, default=OUT)
    args = ap.parse_args()
    OUT = args.out

    import e3nn  # noqa: F401  (import before cuequivariance_torch: see bb.o3.backend)
    from rsfff.features.features import FlatLambdaSOAPFeaturizer as RF
    from pf_pinn.features_native import FlatLambdaSOAPFeaturizer as PF
    from pf_pinn.models.message_passing import EquivariantMessagePassing as PMP

    # hbq_qed's featurizer and message passing are byte-identical copies of pauli_fierz_pinn's
    # (checked when this was written), so only pf's are captured.
    print("featurizers"); capture_featurizers("rsfff", RF); capture_featurizers("pf", PF)
    print("partitions"); capture_rsfff_partitions()
    print("message passing"); capture_mp("pf", PMP)
    print("heads"); capture_heads()
    print("coupling"); capture_coupling()
    print("checkpoints"); capture_checkpoints(args.repos)


if __name__ == "__main__":
    main()
