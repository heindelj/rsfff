"""The neighbor-list cap: explicit everywhere, and loud when it is reached."""

import inspect
import warnings

import pytest
import torch

from bb.features import SOAPFeaturizer, StateSOAPFeaturizer
from bb.graph import (
    CAP_EVENTS,
    DEFAULT_MAX_NUM_NEIGHBORS,
    NeighborCapExceeded,
    build_radius_graph,
    config_max_num_neighbors,
    radius_graph_torch,
    reset_cap_events,
    set_strict,
)


@pytest.fixture(autouse=True)
def _clean_state():
    reset_cap_events()
    yield
    reset_cap_events()
    set_strict(False)


def _dense_blob(n=200, box=3.0, seed=0):
    torch.manual_seed(seed)
    return torch.rand(n, 3) * box, torch.zeros(n, dtype=torch.long)


def _edges(edge):
    return set(map(tuple, edge.t().tolist()))


def test_truncation_warns_and_is_counted():
    pos, batch = _dense_blob()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        build_radius_graph(pos, 5.0, batch, context="unit", max_num_neighbors=16)
    msgs = [str(c.message) for c in caught if "max_num_neighbors" in str(c.message)]
    assert len(msgs) == 1 and "max_num_neighbors=16" in msgs[0]
    assert CAP_EVENTS["unit"] == 1


def test_untruncated_list_is_silent():
    pos, batch = _dense_blob(n=40)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        edge = build_radius_graph(pos, 5.0, batch, context="unit")
    assert edge.shape[1] == 40 * 39
    assert not [c for c in caught if "max_num_neighbors" in str(c.message)]
    assert CAP_EVENTS == {}


def test_strict_mode_raises():
    pos, batch = _dense_blob()
    set_strict(True)
    with pytest.raises(NeighborCapExceeded, match="max_num_neighbors=16"):
        build_radius_graph(pos, 5.0, batch, context="unit", max_num_neighbors=16)


def test_warning_fires_once_per_context():
    pos, batch = _dense_blob()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        for _ in range(5):
            build_radius_graph(pos, 5.0, batch, context="unit", max_num_neighbors=16)
    assert len([c for c in caught if "max_num_neighbors" in str(c.message)]) == 1
    assert CAP_EVENTS["unit"] == 5


def test_featurizers_default_cap_is_bb_default():
    assert SOAPFeaturizer(cutoff=4.0, n_max=2, l_max=1, neighbor_types=(1,)).max_num_neighbors == DEFAULT_MAX_NUM_NEIGHBORS
    default = inspect.signature(StateSOAPFeaturizer.__init__).parameters["max_num_neighbors"].default
    assert default >= DEFAULT_MAX_NUM_NEIGHBORS


def test_featurizer_passes_its_cap_through_and_alias():
    feat = SOAPFeaturizer(cutoff=5.0, n_max=3, l_max=2, neighbor_types=(1, 8), max_neighbors=16)
    assert feat.max_num_neighbors == 16 == feat.max_neighbors
    pos, batch = _dense_blob()
    with warnings.catch_warnings(record=True):
        warnings.simplefilter("always")
        feat.build_edges(pos, batch)
    assert CAP_EVENTS["SOAPFeaturizer"] == 1


def test_config_cap_reads_both_spellings():
    assert config_max_num_neighbors({"max_neighbors": 64}) == 64
    assert config_max_num_neighbors({"max_num_neighbors": 99}) == 99
    assert config_max_num_neighbors({}) == DEFAULT_MAX_NUM_NEIGHBORS


def _random_system(seed, max_graphs=3, max_size=25):
    torch.manual_seed(seed)
    sizes = [int(torch.randint(1, max_size, (1,))) for _ in range(int(torch.randint(1, max_graphs + 1, (1,))))]
    batch = torch.cat([torch.full((n,), g, dtype=torch.long) for g, n in enumerate(sizes)])
    return torch.randn(sum(sizes), 3, dtype=torch.float64) * 2.5, batch


@pytest.mark.parametrize("seed", range(4))
@pytest.mark.parametrize("r", [1.0, 2.5, 5.0])
def test_fallback_matches_brute_force(seed, r):
    pos, batch = _random_system(seed)
    d = torch.cdist(pos, pos)
    ref = (d < r) & (batch[:, None] == batch[None, :]) & ~torch.eye(len(pos), dtype=torch.bool)
    i, j = ref.nonzero(as_tuple=True)
    mine = radius_graph_torch(pos, r=r, batch=batch, max_num_neighbors=256)
    assert _edges(mine) == set(zip(j.tolist(), i.tolist()))


def test_chunked_and_padded_paths_agree(monkeypatch):
    import bb.graph.neighbors as nb

    pos, batch = _random_system(3, max_size=40)
    padded = radius_graph_torch(pos, r=3.0, batch=batch)
    monkeypatch.setattr(nb, "_PADDED_BLOCK_BYTES", 0)
    chunked = radius_graph_torch(pos, r=3.0, batch=batch, chunk=7)
    assert torch.equal(padded, chunked)


def test_cutoff_is_strict():
    pos = torch.tensor([[0.0, 0, 0], [1.0, 0, 0], [3.0, 0, 0]], dtype=torch.float64)
    assert _edges(radius_graph_torch(pos, r=1.0, max_num_neighbors=32)) == set()
    assert _edges(radius_graph_torch(pos, r=1.001, max_num_neighbors=32)) == {(0, 1), (1, 0)}


def test_truncation_keeps_nearest():
    pos, batch = _dense_blob(n=60)
    edge = radius_graph_torch(pos, r=10.0, batch=batch, max_num_neighbors=5)
    deg = torch.bincount(edge[1], minlength=60)
    assert int(deg.max()) == 5
    d = torch.cdist(pos, pos) + torch.eye(60) * 1e9
    nearest = d.topk(5, largest=False).indices
    for q in range(60):
        kept = set(edge[0][edge[1] == q].tolist())
        assert kept == set(nearest[q].tolist())


def test_periodic_cell_is_refused_not_ignored():
    pos, batch = _dense_blob(n=10)
    with pytest.raises(NotImplementedError):
        build_radius_graph(pos, 2.0, batch, context="unit", cell=torch.eye(3)[None] * 10, pbc=torch.ones(1, 3, dtype=torch.bool))
    # a non-periodic declaration is fine
    build_radius_graph(pos, 2.0, batch, context="unit", pbc=torch.zeros(1, 3, dtype=torch.bool))


def test_index_truncation_keeps_the_first_by_index():
    g = torch.Generator().manual_seed(2)
    pos = torch.rand(60, 3, generator=g) * 3.0     # dense: most atoms > 32 neighbors
    bidx = torch.zeros(60, dtype=torch.long)
    full = radius_graph_torch(pos, 4.0, bidx, max_num_neighbors=None)
    capped = radius_graph_torch(pos, 4.0, bidx, max_num_neighbors=32, truncation="index")
    for q in range(60):
        all_nb = sorted(full[0, full[1] == q].tolist())
        kept = sorted(capped[0, capped[1] == q].tolist())
        assert kept == all_nb[:32]


def test_index_truncation_same_on_chunked_path(monkeypatch):
    import bb.graph.neighbors as nb

    pos, batch = _random_system(5, max_size=40)
    padded = radius_graph_torch(pos, 4.0, batch, max_num_neighbors=6, truncation="index")
    monkeypatch.setattr(nb, "_PADDED_BLOCK_BYTES", 0)
    chunked = radius_graph_torch(pos, 4.0, batch, max_num_neighbors=6, truncation="index", chunk=7)
    assert _edges(padded) == _edges(chunked)
