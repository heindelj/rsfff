import warnings

import pytest
import torch

from bb.compat import register_legacy_keys, remap_state_dict
from bb.config import BispectrumConfig, FeaturizerConfig, MessagePassingConfig, ReadoutConfig
from bb.ensemble import Ensemble
from bb.models import EnergyModel, EnergyModelConfig
from bb.nn import (
    ConditionedTrunk, TwoSlotLinear, env_parameters, mlp, parameter_groups, two_slot_mlp, zero_init_readout,
)

from conftest import BACKENDS, molecules

CFG = {
    "featurizer": {"cutoff": 3.5, "n_max": 2, "l_max": 2, "density_channels": 3},
    "message_passing": {"channels": 4, "avg_num_neighbors": 3.0, "hidden_irreps": "0e+1o+2e"},
    "readout": {"irreps_out": "1x0e", "zero_init": False, "species_bias": True},
    "emb_dim": 4,
}


# ------------------------------------------------------------------------- configs
def test_config_roundtrip_and_strictness():
    cfg = EnergyModelConfig.from_dict(CFG)
    assert isinstance(cfg.featurizer, FeaturizerConfig) and isinstance(cfg.message_passing, MessagePassingConfig)
    again = EnergyModelConfig.from_dict(cfg.to_dict())
    assert again == cfg
    with pytest.raises(ValueError, match="unknown config keys"):
        FeaturizerConfig.from_dict({"cutof": 4.0})


def test_legacy_featurizer_keys():
    raw = {"cutoff_radius": 6.0, "max_angular": 3, "max_radial": 4, "max_neighbors": 128, "use_lambda1": True,
           "density_channels": 8, "bispectrum": {"implementation": "sym_contraction", "degrees": [3]}}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        cfg = FeaturizerConfig.from_dict(raw)
    assert (cfg.cutoff, cfg.l_max, cfg.n_max, cfg.max_num_neighbors) == (6.0, 3, 4, 128)
    assert cfg.selected_lambdas == (0, 1, 2)
    assert isinstance(cfg.bispectrum, BispectrumConfig) and cfg.bispectrum.degrees == (3,)
    with pytest.raises(ValueError, match="both"):
        FeaturizerConfig.from_dict({"cutoff": 5.0, "cutoff_radius": 6.0})


# ------------------------------------------------------------------------- energy model
@pytest.mark.parametrize("backend", BACKENDS)
def test_energy_model_invariance_and_forces(float64, backend):
    cfg = EnergyModelConfig.from_dict(CFG)
    cfg.featurizer.backend = backend
    torch.manual_seed(0)
    m = EnergyModel.from_config(cfg, (1, 6, 8), atomic_energies={1: -0.5, 6: -37.8, 8: -75.0})
    pos, z, b = molecules(0)
    out = m(positions=pos, atomic_numbers=z, batch_idx=b, compute_forces=True)
    from bb.testing import random_rotation
    R = random_rotation()
    out_r = m(positions=pos @ R.T + 1.3, atomic_numbers=z, batch_idx=b, compute_forces=True)
    assert torch.allclose(out["energy"], out_r["energy"], atol=1e-10)
    assert torch.allclose(out["forces"] @ R.T, out_r["forces"], atol=1e-9)
    # finite-difference force check on one coordinate
    h = 1e-5
    p1, p2 = pos.clone(), pos.clone()
    p1[3, 1] += h
    p2[3, 1] -= h
    fd = -(m(positions=p1, atomic_numbers=z, batch_idx=b)["energy"].sum()
           - m(positions=p2, atomic_numbers=z, batch_idx=b)["energy"].sum()) / (2 * h)
    assert float(fd.detach()) == pytest.approx(float(out["forces"][3, 1].detach()), rel=1e-5, abs=1e-8)


# ------------------------------------------------------------------------- ensemble
def members(n=3, cfg=CFG):
    out = []
    for s in range(n):
        torch.manual_seed(s)
        out.append(EnergyModel.from_config(cfg, (1, 6, 8), atomic_energies={1: -0.5, 6: -37.8, 8: -75.0}))
    return out


@pytest.mark.parametrize("mode", ["vmap", "loop"])
def test_ensemble_matches_members(float64, mode):
    ms = members()
    pos, z, b = molecules(1)
    ens = Ensemble(ms, mode=mode)
    out = ens(positions=pos, atomic_numbers=z, batch_idx=b)
    ref = torch.stack([m(positions=pos, atomic_numbers=z, batch_idx=b)["energy"] for m in ms])
    assert out["energy"].shape == (3, 2)
    assert torch.allclose(out["energy"], ref, atol=1e-12)
    e, f = ens.energy_and_forces(pos, atomic_numbers=z, batch_idx=b)
    fref = torch.stack([m(positions=pos, atomic_numbers=z, batch_idx=b, compute_forces=True)["forces"] for m in ms])
    assert torch.allclose(e, ref, atol=1e-12) and torch.allclose(f, fref, atol=1e-10)
    mean, std = ens.mean_std(e)
    assert mean.shape == (2,) and (std > 0).all()


def test_ensemble_with_bispectrum_vmaps(float64):
    cfg = dict(CFG, featurizer=dict(CFG["featurizer"], bispectrum={"out_mul": 2}))
    ms = members(2, cfg)
    pos, z, b = molecules(2)
    ens = Ensemble(ms, mode="vmap")
    out = ens(positions=pos, atomic_numbers=z, batch_idx=b)["energy"]
    ref = torch.stack([m(positions=pos, atomic_numbers=z, batch_idx=b)["energy"] for m in ms])
    assert torch.allclose(out, ref, atol=1e-12)


def test_ensemble_rejects_mismatched_members():
    a = members(1)[0]
    cfg = dict(CFG, emb_dim=5)
    torch.manual_seed(0)
    b = EnergyModel.from_config(cfg, (1, 6, 8))
    with pytest.raises(ValueError, match="different architecture"):
        Ensemble([a, b])


# ------------------------------------------------------------------------- nn utilities
def test_film_trunk_is_plain_mlp_at_init():
    torch.manual_seed(0)
    t = ConditionedTrunk(6, 8, 2, d_c=3, mode="film")
    x, c = torch.randn(5, 6), torch.randn(5, 3)
    plain = x
    for layer in t.layers:
        plain = layer(plain)
    assert torch.allclose(t(x, c), plain)
    with pytest.raises(NotImplementedError):
        ConditionedTrunk(6, 8, 2, d_c=3, mode="low_rank")


def test_two_slot_isolated_is_zeroed_environment():
    torch.manual_seed(0)
    lin = TwoSlotLinear(4, 3, 5, p_tail=2)
    with torch.no_grad():
        lin.w_env.normal_()
    h, eta, tail = torch.randn(7, 4), torch.randn(7, 3), torch.randn(7, 2)
    iso = lin(torch.cat((h, tail), -1))
    zero = lin(torch.cat((h, torch.zeros_like(eta), tail), -1))
    assert torch.equal(iso, zero)
    assert [n for n, _ in env_parameters(lin)] == ["w_env"]
    # p_env = 0 is exactly the plain mlp (same parameter names)
    assert set(two_slot_mlp(4, 0, 8, 2, 1, p_tail=2).state_dict()) == set(mlp(6, 8, 2, 1).state_dict())


def test_parameter_groups_honor_exemptions():
    torch.manual_seed(0)
    model = torch.nn.ModuleDict({"a": mlp(3, 4, 1, 2), "b": zero_init_readout(mlp(3, 4, 1, 2)), "c": TwoSlotLinear(2, 2, 3)})
    groups = parameter_groups(model, 1e-3)
    decayed = {id(p) for p in groups[0]["params"]}
    exempt = {id(p) for p in groups[1]["params"]}
    assert all(id(p) in decayed for p in model["a"].parameters())
    assert all(id(p) in exempt for p in model["b"].parameters())
    assert id(model["c"].w_env) in exempt and id(model["c"].w_frag) in decayed


def test_legacy_key_hook():
    from bb.heads import IrrepsReadout

    torch.manual_seed(0)
    r = IrrepsReadout("4x0e + 3x1o", "1x1o", hidden=4, depth=1, reduce_channels=2, zero_init=False)
    old = {k.replace("mlp.", "gate_mlp.").replace("reduce.1o", "equiv_reduce"): v.clone() + 1
           for k, v in r.state_dict().items()}
    rules = [("gate_mlp.", "mlp."), ("equiv_reduce", "reduce.1o")]
    holder = torch.nn.Module()
    holder.head = register_legacy_keys(r, rules)
    holder.load_state_dict({f"head.{k}": v for k, v in old.items()})
    assert torch.equal(r.reduce["1o"], old["equiv_reduce"])
    assert set(remap_state_dict(old, rules)) == set(r.state_dict())


def test_upgrade_state_dict_renames_without_loading():
    """For code that matches checkpoint keys by name itself (a padding / filtering warm start)."""
    from bb.compat import upgrade_state_dict
    from bb.heads import IrrepsReadout

    torch.manual_seed(0)
    r = IrrepsReadout("4x0e + 3x1o", "1x1o", hidden=4, depth=1, reduce_channels=2)
    register_legacy_keys(r, [("gate_mlp.", "mlp."), ("equiv_reduce", "reduce.1o")])
    model = torch.nn.Module()
    model.trunk = torch.nn.Linear(2, 2)
    model.heads = torch.nn.ModuleDict({"vec": r})
    old = {"trunk.weight": torch.zeros(2, 2), "heads.vec.gate_mlp.0.weight": torch.zeros(4, 4),
           "heads.vec.equiv_reduce": torch.zeros(3, 2), "heads.vec.mlp.2.bias": torch.zeros(2)}
    new = upgrade_state_dict(model, old)
    assert set(new) == {"trunk.weight", "heads.vec.mlp.0.weight", "heads.vec.reduce.1o", "heads.vec.mlp.2.bias"}
    assert set(new) <= set(model.state_dict())


@pytest.mark.parametrize("mode", ["vmap", "loop"])
def test_ensemble_custom_call_and_outputs(float64, mode):
    """Members with their own signature (a batch object), extra outputs from the same pass."""
    from bb.graph import SimpleBatch

    ms = members(2)
    pos, z, b = molecules(3)
    batch = SimpleBatch(pos, z, b)

    def call(model, positions):
        out = model(SimpleBatch(positions, batch.atomic_numbers, batch.batch_idx))
        return {"energy": out["energy"], "atomic": out["atomic_energies"]}

    ens = Ensemble(ms, mode=mode)
    e, f, outs = ens.energy_and_forces(pos, call=call, return_outputs=True)
    ref = [m(positions=pos, atomic_numbers=z, batch_idx=b, compute_forces=True) for m in ms]
    assert torch.allclose(e, torch.stack([r["energy"] for r in ref]), atol=1e-12)
    assert torch.allclose(f, torch.stack([r["forces"] for r in ref]), atol=1e-10)
    assert torch.allclose(outs["atomic"], torch.stack([r["atomic_energies"].detach() for r in ref]), atol=1e-12)
    assert ens.mode == mode
