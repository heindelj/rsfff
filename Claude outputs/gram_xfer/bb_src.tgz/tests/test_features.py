import pytest
import torch

from bb.features import (
    PartitionedFeaturizer, SOAPFeaturizer, StateSOAPFeaturizer, cross_power_spectrum,
    equivariant_power_spectrum,
)
from bb.o3 import Irrep, IrrepFeatures
from bb.testing import assert_equivariant

from conftest import BACKENDS, molecules


def featurizer(backend="e3nn", **kw):
    args = dict(cutoff=3.5, n_max=3, l_max=3, neighbor_types=(1, 6, 8), selected_lambdas=(0, 1, 2, 3), backend=backend)
    args.update(kw)
    torch.manual_seed(0)
    return SOAPFeaturizer(**args).double()


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("extra", [{}, {"density_channels": 4}, {"bispectrum": {"out_mul": None}}])
def test_featurizer_equivariant(float64, backend, extra):
    if "bispectrum" in extra and backend == "cue":
        extra = {"bispectrum": {"implementation": "sym_contraction"}, "l_max": 2, "selected_lambdas": (0, 1, 2)}
    f = featurizer(backend, **extra)
    pos, z, b = molecules()
    err = assert_equivariant(lambda p: f(positions=p, atomic_numbers=z, batch_idx=b), pos, atol=1e-9)
    assert err < 1e-9


def test_output_irreps_have_natural_parity(float64):
    f = featurizer()
    pos, z, b = molecules()
    out = f(positions=pos, atomic_numbers=z, batch_idx=b)
    assert [str(ir) for ir in out] == ["0e", "1o", "2e", "3o"]
    assert out.irreps == f.irreps_out
    assert out.feature_dims == f.feature_dims


@pytest.mark.parametrize("backend", BACKENDS)
def test_backends_agree_on_nu2(float64, backend):
    pos, z, b = molecules(1)
    ref = featurizer("e3nn")(positions=pos, atomic_numbers=z, batch_idx=b)
    out = featurizer(backend)(positions=pos, atomic_numbers=z, batch_idx=b)
    for ir in ref:
        assert torch.allclose(ref[ir], out[ir], atol=1e-12)


def test_partition_isolated_group_has_exact_zero_environment(float64):
    f = featurizer(selected_lambdas=(0, 2), l_max=2)
    pos, z, b = molecules(2, sizes=(6, 6))
    group = b.clone()                                   # each molecule its own group
    pf = PartitionedFeaturizer(f, cross_lambdas=(0, 2))
    part = pf(positions=pos, atomic_numbers=z, batch_idx=b, group_idx=group)
    for ir, t in part.x_env.items():
        assert torch.count_nonzero(t) == 0
    assert all(torch.count_nonzero(t) == 0 for t in part.x_cross.values())
    assert torch.count_nonzero(part.a_env) == 0
    # and the internal block is the ordinary descriptor
    full = f(positions=pos, atomic_numbers=z, batch_idx=b)
    for ir in full:
        assert torch.allclose(part.x_in[ir], full[ir], atol=1e-14)


def test_partition_soft_weights_sum_to_full_density(float64):
    f = featurizer(selected_lambdas=(0,), l_max=2)
    pos, z, b = molecules(3, sizes=(9,))
    species = f.species_index(z)
    ei = f.build_edges(pos, b)
    RY = f.expand(pos, ei)
    w = torch.rand(ei.shape[1], dtype=torch.float64)
    A = f.scatter(RY, ei, species, len(z))
    A_s = f.scatter(RY, ei, species, len(z), edge_weight=w)
    A_t = f.scatter(RY, ei, species, len(z), edge_weight=1 - w)
    assert torch.allclose(A_s + A_t, A, atol=1e-13)


def test_partition_equivariant(float64):
    f = featurizer(selected_lambdas=(0, 1, 2), l_max=2)
    pf = PartitionedFeaturizer(f, cross_lambdas=(0, 1, 2))
    pos, z, b = molecules(4, sizes=(8,))
    group = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2])

    def fn(p):
        part = pf(positions=p, atomic_numbers=z, batch_idx=b, group_idx=group)
        return {"in": part.x_in, "env": part.x_env, "cross": {"0e": part.x_cross[0], "1o": part.x_cross[1], "2e": part.x_cross[2]}}

    assert_equivariant(fn, pos, out_irreps={"in": None, "env": None, "cross": None}, atol=1e-9)


@pytest.mark.parametrize("backend", BACKENDS)
def test_state_featurizer_equivariant_and_reduces_to_species(float64, backend):
    torch.manual_seed(0)
    f = StateSOAPFeaturizer(cutoff=3.5, n_max=3, l_max=2, neighbor_types=(1, 6, 8), weight_channels=3,
                            backend=backend).double()
    pos, z, b = molecules(5)
    # one-hot weights reproduce the species-resolved featurizer exactly
    onehot = torch.nn.functional.one_hot(f.species_index(z), 3).double()
    ref = SOAPFeaturizer(cutoff=3.5, n_max=3, l_max=2, neighbor_types=(1, 6, 8), selected_lambdas=(0, 1, 2),
                         backend=backend).double()
    a = f(positions=pos, atomic_numbers=z, batch_idx=b, atom_weights=onehot)
    r = ref(positions=pos, atomic_numbers=z, batch_idx=b)
    for ir in r:
        assert torch.allclose(a[ir], r[ir], atol=1e-12)
    w = torch.randn(len(z), 3, dtype=torch.float64)
    assert_equivariant(lambda p: f(positions=p, atomic_numbers=z, batch_idx=b, atom_weights=w), pos, atol=1e-9)


def test_cross_spectrum_of_identical_densities_matches_power_spectrum(float64):
    f = featurizer(selected_lambdas=(0, 2), l_max=2)
    pos, z, b = molecules(6, sizes=(7,))
    species = f.species_index(z)
    ei = f.build_edges(pos, b)
    A = f.scatter(f.expand(pos, ei), ei, species, len(z))
    ps = equivariant_power_spectrum(A, 2, (0,))[0]
    cs = cross_power_spectrum(A, A, 2, (0,))[0]
    # the cross spectrum keeps the full ordered square; its diagonal blocks are the spectrum
    C = A.shape[1] * A.shape[2]
    first = cs[:, 0, : C * C].reshape(len(z), C, C)
    iu = torch.triu_indices(C, C)
    assert torch.allclose(first[:, iu[0], iu[1]], ps[:, 0, : iu.shape[1]], atol=1e-13)


def test_irrep_features_container():
    n = 4
    f = IrrepFeatures(inv_feats=torch.randn(n, 3), equiv_feats=torch.randn(n, 5, 2), vec_feats=torch.randn(n, 3, 6))
    assert str(f.irreps) == "3x0e + 6x1o + 2x2e"
    assert f[0].shape == (n, 1, 3) and f["1o"].shape == (n, 3, 6) and f[Irrep(2, 1)].shape == (n, 5, 2)
    g = f.cat({"1o": torch.randn(n, 3, 1), "1e": torch.randn(n, 3, 2)})
    assert g.widths[Irrep(1, -1)] == 7 and g.widths[Irrep(1, 1)] == 2
    with pytest.raises(KeyError):
        g[1]                                   # ambiguous: 1o and 1e
    assert g.get(5) is None
    h = g.select(["0e", "1e"])
    assert set(map(str, h)) == {"0e", "1e"}
    f.vec_feats = None
    assert f.vec_feats is None and "1o" not in f
    flat = g.flatten()
    assert flat.shape == (n, sum(t.shape[1] * t.shape[2] for _, t in g.items()))


def test_irrep_features_replace_takes_the_old_field_names():
    """``feats.replace(inv_feats=...)`` stands in for ``dataclasses.replace`` on LambdaFeatures."""
    import copy

    from bb.o3 import IrrepFeatures

    f = IrrepFeatures(inv_feats=torch.randn(4, 3), vec_feats=torch.randn(4, 3, 2),
                      equiv_feats=torch.randn(4, 5, 2), species_idx=torch.arange(4))
    g = f.replace(inv_feats=torch.ones(4, 6), vec_feats=None)
    assert g.inv_feats.shape == (4, 6) and g.vec_feats is None
    assert torch.equal(g.equiv_feats, f.equiv_feats) and g.species_idx is f.species_idx
    if hasattr(copy, "replace"):    # Python >= 3.13
        h = copy.replace(f, edge_index=None, batch_idx=torch.zeros(4, dtype=torch.long))
        assert torch.equal(h.inv_feats, f.inv_feats) and h.batch_idx.shape == (4,)
    with pytest.raises(TypeError):
        f.replace(not_a_field=1)
