"""Body-ordered bond basis: explicit values, invariances, no duplicate columns, derivatives."""

import math

import numpy as np
import pytest
import torch
from e3nn import o3

from bb.features import EdgeBodyOrderBasis
from bb.features.edge_basis import Factor
from bb.graph import bond_graph
from bb.o3 import get_backend


@pytest.fixture(autouse=True)
def _f64(float64):
    yield


SPECIES = [1, 6, 8]


def ethanol_like():
    """H3C-CH2-OH topology with a jittered geometry (C0 C1 O2, H on each)."""
    rng = np.random.default_rng(3)
    pos = np.array([[0, 0, 0], [1.52, 0, 0], [2.0, 1.35, 0], [-0.4, 1.0, 0.1], [-0.4, -0.5, 0.9],
                    [-0.4, -0.5, -0.9], [1.9, -0.5, 0.9], [1.9, -0.5, -0.9], [2.95, 1.3, 0.1]], float)
    pos += 0.05 * rng.normal(size=pos.shape)
    z = [6, 6, 8, 1, 1, 1, 1, 1, 1]
    bonds = [(0, 1), (1, 2), (0, 3), (0, 4), (0, 5), (1, 6), (1, 7), (2, 8)]
    return torch.tensor(pos), torch.tensor([SPECIES.index(x) for x in z]), bonds


def make(max_nu=2, degree=(3, 5, 5), **kw):
    pos, sp, bonds = ethanol_like()
    B = EdgeBodyOrderBasis(SPECIES, n_max=3, l_max=3, n_bond=3, max_nu=max_nu,
                           one_particle_degree=3, degree=degree, **kw)
    B.register([(sp, bond_graph(bonds, len(sp)))])
    return B, pos, sp, bonds


def test_registration_and_orders():
    B, *_ = make()
    lab = B.labels()
    assert set(lab.tolist()) == {-1, 0, 1, 2}
    assert B.bond_types == [(0, 1), (0, 2), (1, 1), (1, 2)]   # H-C, H-O, C-C, C-O
    for bf in B.functions:
        assert sum(f.signed_m for f in bf.factors) == 0
        assert bf.degree <= B.degree[bf.nu]


def test_no_duplicate_columns():
    """Every geometry-dependent column is distinct, except neighbour self-products (k = k'),
    which coincide with lower orders when a side has a single neighbour of that species."""
    B, pos, sp, bonds = make()
    g = bond_graph(bonds, len(sp))
    gen = torch.Generator().manual_seed(0)
    X = torch.stack([B(pos + 0.08 * torch.randn(pos.shape, generator=gen), sp, g)[0] for _ in range(40)])
    cols = ((X - X.mean(0)).abs().amax(0) > 1e-12).nonzero().squeeze(-1)
    Xn = X[:, cols] / X[:, cols].norm(dim=0)
    C = Xn.T @ Xn
    C.fill_diagonal_(0)

    def self_product(c):
        fs = B.functions[int(cols[c])].factors
        keys = [(f.side, f.s) for f in fs]
        return len(keys) != len(set(keys))

    for a, b in (C.abs() > 1 - 1e-9).nonzero().tolist():
        assert self_product(a) or self_product(b), (B.functions[int(cols[a])], B.functions[int(cols[b])])


@pytest.mark.parametrize("improper", [False, True])
def test_o3_and_translation_invariance(improper):
    B, pos, sp, bonds = make(max_nu=3, degree=(3, 4, 4, 4))
    g = bond_graph(bonds, len(sp))
    x0 = B(pos, sp, g)
    R = o3.rand_matrix()
    if improper:
        R = -R
    x1 = B(pos @ R.T + torch.tensor([0.3, -2.0, 1.0]), sp, g)
    assert torch.allclose(x0, x1, atol=1e-11)


def test_orientation_order_and_permutation_invariance():
    B, pos, sp, bonds = make()
    x0 = B(pos, sp, bond_graph(bonds, len(sp)))
    rng = np.random.default_rng(0)
    b2 = [bonds[i][::-1] if rng.random() < 0.5 else bonds[i] for i in rng.permutation(len(bonds))]
    assert torch.allclose(B(pos, sp, bond_graph(b2, len(sp))), x0, atol=1e-12)
    perm = torch.as_tensor(rng.permutation(len(sp)))
    inv = torch.argsort(perm)
    b3 = [(int(inv[i]), int(inv[j])) for i, j in bonds]
    assert torch.allclose(B(pos[perm], sp[perm], bond_graph(b3, len(sp))), x0, atol=1e-12)


def _reference(B, bf, pos, sp, bonds):
    """Direct evaluation of one basis function from its definition."""
    be = get_backend("e3nn")
    from bb.o3.frames import E3NN, edge_frames

    nb = [[] for _ in range(len(sp))]
    for a, b in bonds:
        nb[a].append(b)
        nb[b].append(a)
    total = 0.0
    for a, b in bonds:
        t = tuple(sorted((int(sp[a]), int(sp[b]))))
        if t != bf.bond_type:
            continue
        dirs = [(a, b), (b, a)] if t[0] == t[1] else [(a, b) if int(sp[a]) <= int(sp[b]) else (b, a)]
        for i, j in dirs:
            u = (pos[j] - pos[i]) / (pos[j] - pos[i]).norm()
            R = edge_frames(u[None], E3NN)[0]
            rij = (pos[j] - pos[i]).norm()
            val = B.radial(rij[None], sp[i:i + 1], sp[j:j + 1])[0, bf.q]
            prod = complex(1.0, 0.0)
            for f in bf.factors:
                c, other = (i, j) if f.side == 0 else (j, i)
                zsum = complex(0.0, 0.0)
                for k in nb[c]:
                    if k == other or int(sp[k]) != f.s:
                        continue
                    v = pos[k] - pos[c]
                    y = be.spherical_harmonics((R @ (v / v.norm()))[None], B.l_max)[0]
                    rad = B.radial(v.norm()[None], sp[c:c + 1], sp[k:k + 1])[0, f.n]
                    l, m = f.l, f.m
                    zz = complex(y[l * l + l + m], y[l * l + l - m] if m else 0.0) * float(rad)
                    zsum += zz.conjugate() if f.conj else zz
                prod *= zsum
            total += float(val) * prod.real
    return total


def test_values_match_definition():
    B, pos, sp, bonds = make()
    x = B(pos, sp, bond_graph(bonds, len(sp)))[0]
    rng = np.random.default_rng(1)
    for col in rng.choice(len(B.functions), 60, replace=False):
        bf = B.functions[col]
        assert abs(float(x[col]) - _reference(B, bf, pos, sp, bonds)) < 1e-10, bf


def test_torsion_function_is_cos_omega():
    """m = 1, l = 1, n = 0 cross-bond product = 3 sin(t1) sin(t2) cos(omega) (component norm)."""
    sp = torch.tensor([1, 1, 0, 0])            # C C H H : H2-C0-C1-H3
    bonds = [(0, 1), (0, 2), (1, 3)]
    B = EdgeBodyOrderBasis(SPECIES, n_max=1, l_max=1, n_bond=1, max_nu=2, one_particle_degree=1,
                           degree=(0, 1, 2), element_counts=False)
    B.register([(sp, bond_graph(bonds, 4))])
    target = [c for c, bf in enumerate(B.functions) if bf.nu == 2 and bf.factors[0].side != bf.factors[1].side
              and bf.factors[0].m == 1]
    assert len(target) == 1
    col = target[0]

    def geom(t1, t2, w):
        i, j = np.zeros(3), np.array([1.5, 0, 0])
        k = i + 1.1 * np.array([-math.cos(math.pi - t1), math.sin(math.pi - t1), 0])
        l = j + 1.1 * np.array([math.cos(math.pi - t2), math.sin(math.pi - t2) * math.cos(w),
                                math.sin(math.pi - t2) * math.sin(w)])
        return torch.tensor(np.stack([i, j, k, l]))

    g = bond_graph(bonds, 4)
    ratios = []
    for t1, t2, w in [(1.9, 2.1, 0.3), (1.7, 2.4, 2.0), (2.0, 1.95, -1.1), (2.2, 1.8, 2.9)]:
        v = float(B(geom(t1, t2, w), sp, g)[0, col])
        # summed over the two directions of the homonuclear bond; component-normalized Y_1
        ratios.append(v / (math.sin(t1) * math.sin(t2) * math.cos(w)))
    assert all(abs(abs(r) - 6.0) < 1e-10 for r in ratios) and len({round(r, 8) for r in ratios}) == 1


def test_batched_equals_separate_and_forces():
    B, pos, sp, bonds = make()
    n = len(sp)
    g1 = bond_graph(bonds, n)
    x1 = B(pos, sp, g1)
    pos2 = torch.cat([pos, pos @ o3.rand_matrix().T + 20.0])
    g2 = bond_graph(bonds + [(i + n, j + n) for i, j in bonds], 2 * n)
    bi = torch.cat([torch.zeros(n, dtype=torch.long), torch.ones(n, dtype=torch.long)])
    x2 = B(pos2, torch.cat([sp, sp]), g2, batch_idx=bi)
    assert torch.allclose(x2, torch.cat([x1, x1]), atol=1e-11)

    w = torch.randn(B.n_features, generator=torch.Generator().manual_seed(0)) / B.n_features**0.5
    E = lambda p: (B(p, sp, g1)[0] * w).sum()  # noqa: E731
    p = pos.clone().requires_grad_(True)
    (gr,) = torch.autograd.grad(E(p), p)
    h = 1e-5
    fd = torch.zeros_like(pos)
    for a in range(n):
        for c in range(3):
            d = torch.zeros_like(pos)
            d[a, c] = h
            fd[a, c] = (E(pos + d) - E(pos - d)) / (2 * h)
    assert torch.allclose(gr, fd, atol=1e-7, rtol=1e-6)


def test_canonical_factor_helpers():
    f = Factor(0, 1, 2, 2, 1, False)
    assert f.flipped().conj and f.swapped().side == 1 and f.signed_m == 1 and f.degree == 4
