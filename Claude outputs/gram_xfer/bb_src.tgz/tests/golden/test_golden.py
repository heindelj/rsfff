"""bb reproduces the source repos (rsfff, pauli_fierz_pinn, hbq_qed).

Every case in ``tests/golden/data`` was captured from the original code by
``tools/golden/capture.py``: constructor arguments, the module's state dict, inputs and outputs.
Here the bb equivalent is built from the same arguments, loads the *same* state dict -- strictly,
apart from cuequivariance's rebuilt graph constants, so this is also the checkpoint-compatibility
test -- and must give the same outputs.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import torch

import e3nn  # noqa: F401  -- import before cuequivariance_torch (see bb.o3.backend)

from bb.compat import load_state_dict_lenient, remap_state_dict
from bb.features import PartitionedFeaturizer, SOAPFeaturizer, StateSOAPFeaturizer
from bb.graph import SimpleBatch
from bb.heads import (
    IrrepsReadout, bounded, constrain_sum, first_moment, pool, psd_symmetric, softplus_floor, to_voigt,
)
from bb.nn import EquivariantMessagePassing

DATA = Path(__file__).parent / "data"
pytestmark = pytest.mark.golden

ATOL = 1e-10


def cases(sub: str, exclude: tuple[str, ...] = ()):
    files = sorted((DATA / sub).glob("*.pt"))
    return [pytest.param(f, id=f.stem) for f in files if not any(e in f.stem for e in exclude)]


def load(path):
    return torch.load(path, map_location="cpu", weights_only=False)


@pytest.fixture(autouse=True)
def _float64():
    prev = torch.get_default_dtype()
    torch.set_default_dtype(torch.float64)
    yield
    torch.set_default_dtype(prev)


def close(a, b, atol=ATOL):
    assert a.shape == b.shape, (a.shape, b.shape)
    err = (a - b).abs().max().item() if a.numel() else 0.0
    scale = max(b.abs().max().item(), 1.0) if b.numel() else 1.0
    assert err <= atol * scale, f"max abs err {err:.3e} (scale {scale:.3e})"


def same_edges(a, b):
    sa = {tuple(e) for e in a.t().tolist()}
    sb = {tuple(e) for e in b.t().tolist()}
    assert sa == sb


def check_features(out, ref, *, exact_edges=True):
    close(out.inv_feats, ref["inv"])
    close(out.equiv_feats, ref["equiv"])
    if ref["vec"] is None:
        assert out.vec_feats is None
    else:
        close(out.vec_feats, ref["vec"])
    assert torch.equal(out.species_idx, ref["species_idx"])
    if exact_edges:
        assert torch.equal(out.edge_index, ref["edge_index"])
    else:
        same_edges(out.edge_index, ref["edge_index"])


def build_featurizer(kwargs) -> SOAPFeaturizer:
    torch.manual_seed(0)
    return SOAPFeaturizer(**kwargs).double()


# ------------------------------------------------------------------------- featurizers
@pytest.mark.parametrize("path", cases("features", exclude=("partition", "state")))
def test_featurizer(path):
    d = load(path)
    f = build_featurizer(d["kwargs"])
    load_state_dict_lenient(f, d["state_dict"])
    out = f(SimpleBatch(**d["inputs"]))
    # rsfff used the same pure-torch neighbor list bb does (identical edge order); pf/hbq had their
    # own fallback, which lists the same edges in a different order.
    check_features(out, d["outputs"], exact_edges=path.stem.startswith("rsfff"))
    # the dict-free keyword form gives the same thing
    out2 = f(**d["inputs"])
    close(out2.inv_feats, out.inv_feats, atol=0)


@pytest.mark.parametrize("backend", ["e3nn", "cue"])
def test_rsfff_partition_modes(backend):
    d = load(DATA / "features" / f"rsfff_partition_{backend}.pt")
    f = build_featurizer(d["kwargs"])
    load_state_dict_lenient(f, d["state_dict"])
    inp = d["inputs"]
    batch = SimpleBatch(inp["positions"], inp["atomic_numbers"], inp["batch_idx"])
    frag = inp["fragment_idx"]
    ref = d["outputs"]

    check_features(f(batch, frag), ref["grouped"])
    g, c = f(batch, frag, also_cross=True)
    check_features(g, ref["cross_grouped"])
    check_features(c, ref["cross"])
    g, full = f(batch, frag, also_ungrouped=True)
    check_features(g, ref["ungrouped_grouped"])
    check_features(full, ref["full"])

    def weight_fn(edge_index):
        same = (frag[edge_index[0]] == frag[edge_index[1]]).double()
        return 0.15 + 0.7 * same

    s_in, s_env = f(batch, frag, also_cross=True, edge_weight=weight_fn)
    check_features(s_in, ref["soft_in"])
    check_features(s_env, ref["soft_env"])

    # the same thing through the module API, plus the cross spectrum
    pf = PartitionedFeaturizer(f, cross_lambdas=(0, 2))
    part = pf(batch, edge_weight=weight_fn)
    check_features(part.x_in, ref["soft_in"])
    check_features(part.x_env, ref["soft_env"])
    close(part.edge_weight, ref["soft_edge_weight"], atol=0)
    for lam, t in ref["x_cross"].items():
        close(part.x_cross[lam], t)


@pytest.mark.parametrize("backend", ["e3nn", "cue"])
def test_rsfff_state_featurizer(backend):
    d = load(DATA / "features" / f"rsfff_state_{backend}.pt")
    torch.manual_seed(0)
    f = StateSOAPFeaturizer(**d["kwargs"]).double()
    load_state_dict_lenient(f, d["state_dict"])
    inp = d["inputs"]
    batch = SimpleBatch(inp["positions"], inp["atomic_numbers"], inp["batch_idx"])
    out = f(batch, inp["atom_weights"], inp["fragment_idx"])
    check_features(out, d["outputs"])


# ------------------------------------------------------------------------- message passing
@pytest.mark.parametrize("path", cases("mp"))
def test_message_passing(path):
    d = load(path)
    torch.manual_seed(0)
    mp = EquivariantMessagePassing(**d["kwargs"]).double()
    mp.load_state_dict(d["state_dict"])          # strict: same parameter names
    x = d["inputs"]
    with pytest.warns(RuntimeWarning) if d["kwargs"]["avg_num_neighbors"] is None else _nullcontext():
        inv, equiv = mp(x["inv"], x["equiv"], x["positions"], x["edge_index"], x["emb"])
    close(inv, d["outputs"]["inv"])
    close(equiv, d["outputs"]["equiv"])
    # the irreps-dict form is the same computation
    out = mp({"0e": x["inv"].unsqueeze(1), "2e": x["equiv"]}, x["positions"], x["edge_index"], x["emb"])
    close(out["0e"][:, 0], inv, atol=0)
    close(out["2e"], equiv, atol=0)


class _nullcontext:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


# ------------------------------------------------------------------------- heads
def readout(irreps_in, irreps_out, sd, rules, transforms=None, **kw):
    torch.manual_seed(0)
    r = IrrepsReadout(irreps_in, irreps_out, **kw).double()
    r.load_state_dict(remap_state_dict(sd, rules, transforms=transforms))
    return r


def test_pf_alpha_heads():
    for pos_iso in (0, 1):
        for own in (0, 1):
            d = load(DATA / "heads" / f"pf_alpha_iso{pos_iso}_own{own}.pt")
            k, x = d["kwargs"], d["inputs"]
            eq = x["equiv"] if own else x["equiv"][..., :6]
            r = readout(
                {"0e": k["p0"], "2e": eq.shape[-1]}, "1x0e + 1x2e", d["state_dict"],
                [("base_mlp.", "mlp."), ("equiv_reduce", "reduce.2e")],
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"],
                reduce_channels=k["equiv_channels"], reduce=bool(own), zero_init=False,
            )
            y = r({"0e": x["inv"].unsqueeze(1), "2e": eq}, x["emb"])
            y0, y2 = y["0e"][:, 0, :], y["2e"][..., 0]
            out = psd_symmetric(y0, y2, floor=1e-4, smooth=0.05) if pos_iso else to_voigt(y0, y2)
            close(out, d["outputs"]["out"])


def test_pf_response_head():
    d = load(DATA / "heads" / "pf_response.pt")
    k, x = d["kwargs"], d["inputs"]
    C = k["channels"]
    r = readout(
        {"0e": k["p0"], "2e": k["kin"]}, f"{C}x0e + {C}x2e", d["state_dict"], [("base_mlp.", "mlp.")],
        scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], reduce=False,
        zero_init=False, gate_layout="interleaved",
    )
    y = r({"0e": x["inv"].unsqueeze(1), "2e": x["equiv"]}, x["emb"])
    out = to_voigt(y["0e"].transpose(1, 2), y["2e"].transpose(1, 2))     # (N, C, 6)
    close(out, d["outputs"]["out"])


@pytest.mark.parametrize("name", ["pf_vector", "hbq_vector"])
def test_vector_heads(name):
    d = load(DATA / "heads" / f"{name}.pt")
    k, x = d["kwargs"], d["inputs"]
    r = readout(
        {"0e": k["p0"], "1o": k["p1"]}, "1x1o", d["state_dict"],
        [("gate_mlp.", "mlp."), ("equiv_reduce", "reduce.1o")],
        scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], reduce_channels=k["equiv_channels"],
    )
    y = r({"0e": x["inv"].unsqueeze(1), "1o": x["vec"]}, x["emb"])
    close(y["1o"][..., 0], d["outputs"]["out"])


@pytest.mark.parametrize("name", ["pf_scalar_pos1", "pf_scalar_pos0", "hbq_scalar", "pf_ratio"])
def test_scalar_heads(name):
    d = load(DATA / "heads" / f"{name}.pt")
    k, x = d["kwargs"], d["inputs"]
    r = readout({"0e": k["p0"]}, "1x0e", d["state_dict"], [],
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"])
    y = r({"0e": x["inv"].unsqueeze(1)}, x["emb"])["0e"][:, 0, 0]
    if name == "pf_ratio":
        y = bounded(y, k["v_min"], k["v_max"])
    elif name == "pf_scalar_pos1":
        y = softplus_floor(y, k["floor"])
    close(y, d["outputs"]["out"])


def test_hbq_dipole_head():
    d = load(DATA / "heads" / "hbq_dipole.pt")
    k, x, o = d["kwargs"], d["inputs"], d["outputs"]
    sd_q = {kk.replace("charge_head.", ""): v for kk, v in d["state_dict"].items() if kk.startswith("charge_head.")}
    q_r = readout({"0e": k["p0"]}, "1x0e", sd_q, [],
                  scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"])
    sd_v = {kk.replace("vector_head.", ""): v for kk, v in d["state_dict"].items() if kk.startswith("vector_head.")}
    v_r = readout({"0e": k["p0"], "1o": k["p1"]}, "1x1o", sd_v,
                  [("gate_mlp.", "mlp."), ("equiv_reduce", "reduce.1o")],
                  scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], reduce_channels=k["equiv_channels"])
    feats = {"0e": x["inv"].unsqueeze(1), "1o": x["vec"]}
    q = constrain_sum(q_r(feats, x["emb"])["0e"][:, 0, 0], o["batch_idx"], o["total_charge"], 3)
    p = v_r(feats, x["emb"])["1o"][..., 0]
    mu = first_moment(o["positions"], o["batch_idx"], q, p, 3)
    close(q, o["charges"])
    close(p, o["atom_dipoles"])
    close(mu, o["dipole"])


def test_hbq_energy_head():
    d = load(DATA / "heads" / "hbq_energy.pt")
    k, x, o = d["kwargs"], d["inputs"], d["outputs"]
    sd = {kk: v for kk, v in d["state_dict"].items() if kk != "reference"}
    r = readout({"0e": k["p0"]}, "1x0e", sd, [("bias", "species_bias")],
                transforms={"species_bias": lambda b: b.reshape(-1, 1)},
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], species_bias=k["n_species"])
    atomic = r({"0e": x["inv"].unsqueeze(1)}, x["emb"], species_idx=o["species_idx"])["0e"][:, 0, 0]
    energy = pool(atomic, o["batch_idx"], 3) + d["state_dict"]["reference"]
    close(atomic, o["atomic"])
    close(energy, o["energy"])


@pytest.mark.parametrize("p_env", [0, 3])
def test_rsfff_heads(p_env):
    from bb.o3 import irrep6_to_voigt

    x = None
    # polarizability (positive isotropic, hard PSD shift)
    d = load(DATA / "heads" / f"rsfff_alpha_env{p_env}.pt")
    k, x = d["kwargs"], d["inputs"]
    p0, p2 = x["inv"].shape[1], x["equiv"].shape[2]
    rules = [("base_mlp.", "mlp."), ("equiv_reduce_env", "reduce_env.2e"), ("equiv_reduce", "reduce.2e")]
    r = readout({"0e": p0, "2e": p2}, "1x0e + 1x2e", d["state_dict"], rules,
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], reduce_channels=k["equiv_channels"],
                zero_init=False, env_widths={"0e": p_env, "2e": p_env} if p_env else None)
    y = r({"0e": x["inv"].unsqueeze(1), "2e": x["equiv"]}, x["emb"])
    out = psd_symmetric(y["0e"][:, 0, :], y["2e"][..., 0], floor=1e-4, smooth=None, irrep6_to_voigt_matrix=irrep6_to_voigt())
    close(out, d["outputs"]["out"])
    if p_env:
        # isolated evaluation: drop the environment channels, bit-identical to zeroing them
        y_iso = r({"0e": x["inv"][:, : p0 - p_env].unsqueeze(1), "2e": x["equiv"][..., : p2 - p_env]}, x["emb"])
        xz = {"0e": torch.cat((x["inv"][:, : p0 - p_env], torch.zeros(len(x["inv"]), p_env)), -1).unsqueeze(1),
              "2e": torch.cat((x["equiv"][..., : p2 - p_env], torch.zeros(len(x["inv"]), 5, p_env)), -1)}
        y_zero = r(xz, x["emb"])
        close(y_iso["2e"], y_zero["2e"], atol=0)
        close(y_iso["0e"], y_zero["0e"], atol=0)

    # vector
    d = load(DATA / "heads" / f"rsfff_vector_env{p_env}.pt")
    k = d["kwargs"]
    p1 = x["vec"].shape[2]
    rules = [("gate_mlp.", "mlp."), ("equiv_reduce_env", "reduce_env.1o"), ("equiv_reduce", "reduce.1o")]
    r = readout({"0e": p0, "1o": p1}, "1x1o", d["state_dict"], rules,
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], reduce_channels=k["equiv_channels"],
                env_widths={"0e": p_env, "1o": p_env} if p_env else None)
    y = r({"0e": x["inv"].unsqueeze(1), "1o": x["vec"]}, x["emb"])
    close(y["1o"][..., 0], d["outputs"]["out"])

    # quadrupole (spherical convention applied by the caller)
    d = load(DATA / "heads" / f"rsfff_quad_env{p_env}.pt")
    k = d["kwargs"]
    rules = [("gate_mlp.", "mlp."), ("equiv_reduce_env", "reduce_env.2e"), ("equiv_reduce", "reduce.2e")]
    r = readout({"0e": p0, "2e": p2}, "1x2e", d["state_dict"], rules,
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"], reduce_channels=k["equiv_channels"],
                env_widths={"0e": p_env, "2e": p_env} if p_env else None)
    y = r({"0e": x["inv"].unsqueeze(1), "2e": x["equiv"]}, x["emb"])
    coupling = load(DATA / "coupling" / "pf_and_rsfff.pt")
    close(y["2e"][..., 0] @ coupling["outputs"]["irrep2_to_spherical"], d["outputs"]["out"])


def test_rsfff_energy_head():
    d = load(DATA / "heads" / "rsfff_energy.pt")
    k, x, o = d["kwargs"], d["inputs"], d["outputs"]
    sd = d["state_dict"]
    emb = torch.nn.functional.embedding(o["species_idx"], sd["species_emb.weight"])
    r = readout({"0e": k["p0"]}, "1x0e", {kk: v for kk, v in sd.items() if kk.startswith("mlp.")}, [],
                scalar_dim=k["emb_dim"], hidden=k["hidden"], depth=k["depth"])
    y = r({"0e": x["inv"].unsqueeze(1)}, emb)["0e"][:, 0, 0]
    close(y, o["out"])


# ------------------------------------------------------------------------- coupling
def test_pf_lambda_coupling():
    from bb.inputs import couple, self_couple
    from bb.o3 import irrep6_to_voigt, voigt_to_irrep6

    d = load(DATA / "coupling" / "pf_and_rsfff.pt")
    x, o = d["inputs"], d["outputs"]
    lam, vec_k = x["lam"], x["vec_k"]
    close(3 ** 0.5 * couple(vec_k, lam, 0)[:, 0], o["vec_lambda_0e"])
    close(couple(vec_k, lam, 2), o["vec_lambda_2e"])
    close(self_couple(lam, 2), o["lambda_2e"])
    close(3 ** 0.5 * self_couple(lam, 0), o["lambda_invariant"])
    close(irrep6_to_voigt(), o["irrep6_to_voigt"], atol=1e-14)
    close(voigt_to_irrep6(), o["voigt_to_irrep6"], atol=1e-14)


# ------------------------------------------------------------------------- real checkpoints
@pytest.mark.parametrize("path", cases("checkpoints", exclude=("_config",)))
def test_checkpoint_submodules(path):
    d = load(path)
    kw = dict(d["featurizer_kwargs"])
    if d["has_bispectrum"]:
        kw["bispectrum"] = d["bispectrum_kwargs"]
    f = build_featurizer(kw)
    load_state_dict_lenient(f, d["featurizer_state"])
    feats = f(SimpleBatch(**d["inputs"]))
    check_features(feats, d["features"], exact_edges=False)
    if "mp_state" in d:
        torch.manual_seed(0)
        mp = EquivariantMessagePassing(backend=kw["backend"], **d["mp_kwargs"]).double()
        mp.load_state_dict(d["mp_state"])
        ref = d["features"]
        with pytest.warns(RuntimeWarning) if d["mp_kwargs"]["avg_num_neighbors"] is None else _nullcontext():
            inv, equiv = mp(ref["inv"], ref["equiv"], d["inputs"]["positions"], ref["edge_index"], d["emb"])
        close(inv, d["mp_out"]["inv"])
        close(equiv, d["mp_out"]["equiv"])


def test_porting_template_loads_old_checkpoint_keys():
    """The wrapper pattern in docs/porting.md: old keys load through register_legacy_keys."""
    from bb.compat import register_legacy_keys

    class AtomicAlphaHead(torch.nn.Module):
        def __init__(self, p0, p2, emb_dim, *, hidden, depth, equiv_channels, positive_isotropic):
            super().__init__()
            self.positive_isotropic = positive_isotropic
            self.r = IrrepsReadout({"0e": p0, "2e": p2}, "1x0e + 1x2e", scalar_dim=emb_dim, hidden=hidden,
                                   depth=depth, reduce_channels=equiv_channels, zero_init=False)
            register_legacy_keys(self, [("base_mlp.", "r.mlp."), ("equiv_reduce", "r.reduce.2e")])

        def forward(self, inv, emb, equiv):
            y = self.r({"0e": inv.unsqueeze(1), "2e": equiv}, emb)
            y0, y2 = y["0e"][:, 0, :], y["2e"][..., 0]
            return psd_symmetric(y0, y2, floor=1e-4, smooth=0.05) if self.positive_isotropic else to_voigt(y0, y2)

    d = load(DATA / "heads" / "pf_alpha_iso1_own1.pt")
    k, x = d["kwargs"], d["inputs"]
    model = torch.nn.Module()
    model.heads = torch.nn.ModuleDict({"alpha": AtomicAlphaHead(
        k["p0"], k["p2"], k["emb_dim"], hidden=k["hidden"], depth=k["depth"],
        equiv_channels=k["equiv_channels"], positive_isotropic=True).double()})
    model.load_state_dict({f"heads.alpha.{kk}": v for kk, v in d["state_dict"].items()})
    close(model.heads["alpha"](x["inv"], x["emb"], x["equiv"]), d["outputs"]["out"])
