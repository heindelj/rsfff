import math

import torch

from bb.features import PairClusterExpansion
from bb.graph import build_periodic_graph, pair_graph, site_pair_graph
from bb.heads import EdgeScalarReadout

torch.set_default_dtype(torch.float64)


def _system(seed=0, n=10):
    g = torch.Generator().manual_seed(seed)
    cell = torch.tensor([[5.0, 0.2, 0.0], [0.4, 5.5, 0.1], [0.0, -0.3, 6.0]])
    pos = torch.rand(n, 3, generator=g) @ cell
    species = torch.tensor([0, 1] * (n // 2))  # 0 = Fe-like site, 1 = ligand
    return pos, cell, species


def _graph(pos, cell, species, r_pair=4.5, r_env=2.6):
    pairs = site_pair_graph(pos, r_pair, species == 0, cell)
    env = build_periodic_graph(pos, r_env, cell, context="env")
    return pair_graph(pairs, env, pos.shape[0])


def _model(seed=0):
    torch.manual_seed(seed)
    ece = PairClusterExpansion([26, 8], env_cutoff=2.6, pair_cutoff=4.5, n_env=4, n_max=6, l_max=3, channels=4)
    head = EdgeScalarReadout.from_ece(ece, hidden=16, depth=2, bond_basis=6)
    return ece, head


def _energy(ece, head, pos, cell, species, twist=False):
    g = _graph(pos, cell, species)
    tw = torch.rand(g.n_edges) * 6.0 if twist else None
    ef = ece(pos, species, g, twist=tw)
    return head(ef)["total"].sum()


def _rot(seed):
    q, _ = torch.linalg.qr(torch.randn(3, 3, generator=torch.Generator().manual_seed(seed)))
    return q * torch.sign(torch.det(q))


def test_invariances():
    ece, head = _model()
    pos, cell, sp = _system()
    e = _energy(ece, head, pos, cell, sp)
    assert e.abs() > 0
    R = _rot(3)
    assert torch.allclose(_energy(ece, head, pos @ R.T, cell @ R.T, sp), e, atol=1e-10)
    assert torch.allclose(_energy(ece, head, pos + 1.7, cell, sp), e, atol=1e-10)
    assert torch.allclose(_energy(ece, head, pos, cell, sp, twist=True), e, atol=1e-10)
    wrapped = pos.clone(); wrapped[2] -= cell[0]
    assert torch.allclose(_energy(ece, head, wrapped, cell, sp), e, atol=1e-10)
    # inversion: with odd="symmetrize" the readout is O(3) invariant
    assert torch.allclose(_energy(ece, head, -pos, -cell, sp), e, atol=1e-10)


def test_pseudoscalars_flip_under_inversion():
    ece, _ = _model()
    pos, cell, sp = _system(1)
    a = ece(pos, sp, _graph(pos, cell, sp))
    b = ece(-pos, sp, _graph(-pos, -cell, sp))
    assert torch.allclose(a.inv0e, b.inv0e, atol=1e-10)
    assert torch.allclose(a.inv0o, -b.inv0o, atol=1e-10)


def test_supercell_extensive():
    ece, head = _model()
    pos, cell, sp = _system(2)
    e1 = _energy(ece, head, pos, cell, sp)
    sc = cell.clone(); sc[1] *= 2
    e2 = _energy(ece, head, torch.cat([pos, pos + cell[1]]), sc, torch.cat([sp, sp]))
    assert torch.allclose(e2, 2 * e1, atol=1e-9)


def test_smooth_at_cutoffs():
    """A ligand crossing the env cutoff and a site crossing the pair cutoff change the energy by
    O(delta^3) (the envelope vanishes with two derivatives), not by a jump."""
    ece, head = _model()
    cell = torch.eye(3) * 40.0
    sp = torch.tensor([0, 0, 1])
    delta = 1e-3
    # ligand on the far side of site 0, outside site 1's environment
    es = [_energy(ece, head, torch.tensor([[0.0, 0, 0], [3.0, 0, 0], [-d, 0, 0]]), cell, sp).detach()
          for d in (2.6 - delta, 2.6 + delta)]
    assert abs(float(es[1] - es[0])) < 1e-7
    # two sites crossing the pair cutoff, a ligand near site 0
    es = [_energy(ece, head, torch.tensor([[0.0, 0, 0], [d, 0, 0], [-1.9, 0.3, 0]]), cell, sp).detach()
          for d in (4.5 - delta, 4.5 + delta)]
    assert abs(float(es[1] - es[0])) < 1e-7
    assert abs(float(es[1])) < 1e-12  # beyond the pair cutoff there is no pair
