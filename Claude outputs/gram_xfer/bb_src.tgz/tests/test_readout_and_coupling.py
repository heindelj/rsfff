import pytest
import torch

from bb.features import SOAPFeaturizer
from bb.heads import (
    IrrepsReadout, bounded, constrain_sum, first_moment, inverse_softplus_floor, logit_bounded, pool,
    psd_symmetric, softplus_floor, to_voigt,
)
from bb.inputs import IrrepCoupling, couple, self_couple
from bb.o3 import Irrep, min_eig_sym3x3, voigt_to_matrix
from bb.testing import assert_equivariant

from conftest import molecules


def feats_fn(lambdas=(0, 1, 2)):
    torch.manual_seed(0)
    f = SOAPFeaturizer(cutoff=3.5, n_max=2, l_max=2, neighbor_types=(1, 6, 8), selected_lambdas=lambdas).double()
    pos, z, b = molecules(0)
    return f, pos, z, b


def nonzero_(module, seed=0):
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for _, p in sorted(module.named_parameters()):
            p.copy_(torch.randn(p.shape, generator=g, dtype=p.dtype) * 0.3)


def test_readout_any_irreps_is_equivariant(float64):
    f, pos, z, b = feats_fn()
    r = IrrepsReadout(f.irreps_out, "3x0e + 2x1o + 4x2e", scalar_dim=2, hidden=8, depth=2, reduce_channels=5).double()
    nonzero_(r)
    s = torch.randn(len(z), 2, dtype=torch.float64)
    out = r(f(positions=pos, atomic_numbers=z, batch_idx=b), s)
    assert str(out.irreps) == "3x0e + 2x1o + 4x2e"
    assert_equivariant(lambda p: r(f(positions=p, atomic_numbers=z, batch_idx=b), s), pos, atol=1e-9)


def test_readout_zero_init_and_decay_exemption():
    r = IrrepsReadout("4x0e + 3x1o", "1x0e + 1x1o", hidden=4, depth=1, reduce_channels=2)
    x = {"0e": torch.randn(5, 1, 4), "1o": torch.randn(5, 3, 3)}
    out = r(x)
    assert torch.count_nonzero(out["0e"]) == 0 and torch.count_nonzero(out["1o"]) == 0
    assert getattr(r, "no_weight_decay", False)
    r.set_scalar_bias(0.7)
    assert torch.allclose(r(x)["0e"], torch.full((5, 1, 1), 0.7))


def test_readout_species_bias_and_interleaved_layout(float64):
    r = IrrepsReadout("4x0e + 3x2e", "2x0e + 2x2e", hidden=4, depth=1, reduce=False, gate_layout="interleaved",
                      species_bias=3, zero_init=False)
    nonzero_(r)
    x = {"0e": torch.randn(6, 1, 4), "2e": torch.randn(6, 5, 3)}
    sp = torch.tensor([0, 1, 2, 0, 1, 2])
    out = r(x, species_idx=sp)
    assert out["0e"].shape == (6, 1, 2) and out["2e"].shape == (6, 5, 2)
    with pytest.raises(ValueError):
        IrrepsReadout("4x0e + 3x2e", "2x0e + 1x2e", gate_layout="interleaved")


def test_transforms(float64):
    b = torch.tensor([0, 0, 0, 1, 1])
    q = torch.randn(5)
    qc = constrain_sum(q, b, torch.tensor([1.0, -2.0]))
    assert torch.allclose(pool(qc, b), torch.tensor([1.0, -2.0]))
    assert torch.allclose(pool(torch.ones(5, 2), b, reduce="mean"), torch.ones(2, 2))
    # PSD: every eigenvalue >= floor, both shift modes
    x0, x2 = torch.randn(50, 1) - 3.0, torch.randn(50, 5) * 3.0
    for smooth in (None, 0.05):
        v = psd_symmetric(x0, x2, floor=1e-3, smooth=smooth)
        assert float(torch.linalg.eigvalsh(voigt_to_matrix(v)).min()) >= 1e-3 - 1e-12
    assert torch.allclose(min_eig_sym3x3(voigt_to_matrix(to_voigt(x0, x2))),
                          torch.linalg.eigvalsh(voigt_to_matrix(to_voigt(x0, x2)))[:, 0], atol=1e-8)
    assert softplus_floor(torch.tensor(inverse_softplus_floor(1.3, 0.2)), 0.2) == pytest.approx(1.3)
    assert bounded(torch.tensor(logit_bounded(0.6, 0.2, 1.4)), 0.2, 1.4) == pytest.approx(0.6)
    # first moment of a neutral distribution is origin independent
    pos = torch.randn(5, 3)
    qn = constrain_sum(q, b)
    assert torch.allclose(first_moment(pos, b, qn), first_moment(pos + 7.0, b, qn), atol=1e-12)


def test_coupling_conventions(float64):
    x = torch.randn(7, 3, 4)
    y = torch.randn(7, 3)
    # 0e: dot / sqrt(3); 2e: symmetric traceless part in the irrep6 basis
    assert torch.allclose(couple(x, y, 0)[:, 0], torch.einsum("nmk,nm->nk", x, y) / 3 ** 0.5)
    assert torch.allclose(self_couple(y, 0)[:, 0], (y * y).sum(-1) / 3 ** 0.5)
    # 1e: the cross product (up to the CG normalization)
    c = couple(x[..., :1], y, 1)[..., 0]
    cross = torch.cross(x[..., 0], y, dim=-1)
    ratio = c / cross
    assert torch.allclose(ratio, ratio[0, 0].expand_as(ratio), atol=1e-10)


@pytest.mark.parametrize("ext", ["1o", "1e", "2e"])
def test_coupling_module_equivariant_with_parity(float64, ext):
    f, pos, z, b = feats_fn()
    ext_ir = Irrep.parse(ext)
    out_l = [l for l in range(0, 4) if abs(1 - ext_ir.l) <= l <= 1 + ext_ir.l]
    cpl = IrrepCoupling("1o", ext, out_l=out_l, in_width=f.feature_dims[1], channels=3).double()
    e = torch.randn(len(z), ext_ir.dim, dtype=torch.float64)
    out = cpl(f(positions=pos, atomic_numbers=z, batch_idx=b), e)
    # parity of the outputs is the product of the inputs'
    assert all(ir.p == -1 * ext_ir.p for ir in out)

    def fn(p, field):
        return cpl(f(positions=p, atomic_numbers=z, batch_idx=b), field)

    assert_equivariant(fn, pos, inputs={"field": (e, ext)}, atol=1e-9)


def test_external_input_through_message_passing_and_readout(float64):
    """An applied field enters as a coupled feature block and as an invariant scalar."""
    from bb.nn import EquivariantMessagePassing

    f, pos, z, b = feats_fn()
    cpl = IrrepCoupling("1o", "1o", out_l=(0, 2), in_width=f.feature_dims[1], channels=2).double()
    widths = dict(f.feature_dims)
    irreps_in = {"0e": widths[0] + 2, "1o": widths[1], "2e": widths[2] + 2}
    mp = EquivariantMessagePassing(irreps_in=irreps_in, emb_dim=1, cutoff=3.5, channels=3, avg_num_neighbors=3.0).double()
    nonzero_(mp, 1)
    r = IrrepsReadout(irreps_in, "1x0e + 1x1o + 1x2e", scalar_dim=1, hidden=6, depth=1, reduce_channels=3).double()
    nonzero_(r, 2)
    E = torch.randn(len(z), 3, dtype=torch.float64)

    def model(p, field):
        x = f(positions=p, atomic_numbers=z, batch_idx=b)
        x = x.cat(cpl(x, field))
        e2 = (field * field).sum(-1, keepdim=True)
        x = mp(x, p, emb=e2)
        return r(x, e2)

    assert_equivariant(model, pos, inputs={"field": (E, "1o")}, atol=1e-9)
