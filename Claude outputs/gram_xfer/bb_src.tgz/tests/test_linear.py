"""bb.linear: rows of a linear model, normal equations, nested truncations."""

import pytest
import torch

from bb.features import EdgeBodyOrderBasis
from bb.graph import bond_graph
from bb.linear import NormalEquations, active_columns, design_rows, hessian_upper, nested_solve


@pytest.fixture(autouse=True)
def _f64(float64):
    yield


def _setup():
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from test_edge_basis import SPECIES, ethanol_like

    pos, sp, bonds = ethanol_like()
    g = bond_graph(bonds, len(sp))
    B = EdgeBodyOrderBasis(SPECIES, n_max=3, l_max=2, n_bond=3, max_nu=2, one_particle_degree=2,
                           degree=(2, 3, 4)).register([(sp, g)])
    phi = lambda x: B(x.reshape(-1, 3), sp, g)[0]  # noqa: E731
    return B, phi, pos.reshape(-1)


def test_rows_match_autograd():
    B, phi, x = _setup()
    w = torch.randn(B.n_features, generator=torch.Generator().manual_seed(0))
    E = lambda z: phi(z) @ w  # noqa: E731
    rows = design_rows(phi, x, hessian=True)
    H = torch.autograd.functional.hessian(E, x)
    g = torch.autograd.functional.jacobian(E, x)
    assert torch.allclose(rows["energy"] @ w, E(x)[None], atol=1e-12)
    assert torch.allclose(rows["forces"] @ w, -g, atol=1e-10)
    assert torch.allclose(rows["hessian"] @ w, hessian_upper(H), atol=1e-9)
    assert torch.allclose(hessian_upper(H).norm(), H.norm())


def test_recovers_a_model_and_columns_path():
    B, phi, x = _setup()
    cols = active_columns(phi, x)
    gen = torch.Generator().manual_seed(1)
    w_true = torch.zeros(B.n_features)
    w_true[cols] = torch.randn(len(cols), generator=gen)
    full, sub = NormalEquations(B.n_features), NormalEquations(B.n_features)
    for k in range(30):
        xk = x + 0.05 * torch.randn(x.shape, generator=gen)
        r = design_rows(phi, xk, hessian=(k % 15 == 0))
        rc = design_rows(phi, xk, hessian=(k % 15 == 0), columns=cols)
        for key in r:
            y = r[key] @ w_true
            full.add(r[key], y, sigma=0.5)
            sub.add(rc[key], y, sigma=0.5, columns=cols)
    assert torch.allclose(full.G, sub.G, atol=1e-8) and torch.allclose(full.b, sub.b, atol=1e-8)
    w = full.solve(ridge=1e-14)
    # the data determine the predictions, not necessarily w (dependent columns): compare predictions
    xt = x + 0.05 * torch.randn(x.shape, generator=gen)
    rt = design_rows(phi, xt, hessian=True)
    for key in rt:
        assert torch.allclose(rt[key] @ w, rt[key] @ w_true, atol=1e-6 * (rt[key] @ w_true).abs().max()), key
    assert full.loss(w) < 1e-10 * full.yy


def test_nested_truncations_are_monotone():
    B, phi, x = _setup()
    gen = torch.Generator().manual_seed(2)
    ne = NormalEquations(B.n_features)
    w_true = torch.randn(B.n_features, generator=gen)
    for _ in range(40):
        r = design_rows(phi, x + 0.05 * torch.randn(x.shape, generator=gen))
        for key in r:
            ne.add(r[key], r[key] @ w_true)
    ws = nested_solve(ne, B.labels(), [0, 1, 2], ridge=1e-12)
    losses = [ne.loss(ws[k]) for k in (0, 1, 2)]
    assert losses[0] >= losses[1] >= losses[2] and losses[2] < 1e-8 * ne.yy
    lab = B.labels()
    assert (ws[0][lab > 0] == 0).all() and (ws[1][lab > 1] == 0).all()


def test_per_column_ridge():
    from bb.linear import order_ridge

    gen = torch.Generator().manual_seed(3)
    A = torch.randn(50, 6, generator=gen)
    y = torch.randn(50, generator=gen)
    ne = NormalEquations(6)
    ne.add(A, y)
    lab = torch.tensor([0, 0, 1, 1, 2, -1])
    lam = order_ridge(lab, 1e-6, 10.0)
    assert torch.allclose(lam, torch.tensor([1e-6, 1e-6, 1e-5, 1e-5, 1e-4, 1e-6]))
    w_vec = ne.solve(lam)
    w_num = ne.solve(1e-6)
    assert torch.isfinite(w_vec).all() and (w_vec - w_num).abs().max() < 1e-3
    big = ne.solve(torch.tensor([0, 0, 0, 0, 1e12, 0], dtype=torch.float64))
    assert big[4].abs() < 1e-8
