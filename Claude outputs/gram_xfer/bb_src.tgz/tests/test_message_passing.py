import pytest
import torch

from bb.features import SOAPFeaturizer
from bb.graph import average_num_neighbors
from bb.nn import EquivariantMessagePassing, message_paths
from bb.o3 import Irrep, IrrepFeatures
from bb.testing import assert_equivariant

from conftest import BACKENDS, molecules


def setup(backend="e3nn", lambdas=(0, 1, 2), seed=0, sizes=(6, 8)):
    torch.manual_seed(0)
    f = SOAPFeaturizer(cutoff=3.5, n_max=2, l_max=2, neighbor_types=(1, 6, 8), selected_lambdas=lambdas,
                       backend=backend).double()
    pos, z, b = molecules(seed, sizes=sizes)
    return f, pos, z, b


def randomize(mp, seed=3):
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for _, p in sorted(mp.named_parameters()):
            p.copy_(torch.randn(p.shape, generator=g, dtype=p.dtype) * 0.3)


def test_noop_at_init(float64):
    f, pos, z, b = setup()
    feats = f(positions=pos, atomic_numbers=z, batch_idx=b)
    mp = EquivariantMessagePassing(irreps_in=feats.irreps, emb_dim=0, cutoff=3.5, hidden_irreps="0e+1o+2e",
                                   avg_num_neighbors=4.0).double()
    out = mp(feats, pos)
    for ir in feats:
        assert torch.equal(out[ir], feats[ir])


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("hidden,lmax", [("0e+2e", 2), ("0e+1o+2e", 2), ("0e+1o+2e+3o", 3)])
def test_equivariant_any_hidden_irreps(float64, backend, hidden, lmax):
    f, pos, z, b = setup(backend)
    emb = torch.randn(len(z), 3, dtype=torch.float64)
    feats0 = f(positions=pos, atomic_numbers=z, batch_idx=b)
    mp = EquivariantMessagePassing(irreps_in=feats0.irreps, emb_dim=3, cutoff=3.5, backend=backend,
                                   hidden_irreps=hidden, lmax=lmax, channels=4, layers=2,
                                   avg_num_neighbors=4.0).double()
    randomize(mp)

    def fn(p):
        feats = f(positions=p, atomic_numbers=z, batch_idx=b)
        return mp(feats, p, emb=emb)

    assert_equivariant(fn, pos, atol=1e-9)


def test_creates_blocks_absent_from_the_input(float64):
    f, pos, z, b = setup(lambdas=(0, 2))
    feats0 = f(positions=pos, atomic_numbers=z, batch_idx=b)
    mp = EquivariantMessagePassing(irreps_in=feats0.irreps, cutoff=3.5, hidden_irreps="0e+1o+2e",
                                   irreps_out={"1o": 5}, channels=4, lmax=1, avg_num_neighbors=4.0).double()
    randomize(mp)

    def fn(p):
        return mp(f(positions=p, atomic_numbers=z, batch_idx=b), p)

    out = fn(pos)
    assert out["1o"].shape == (len(z), 3, 5)
    assert out["1o"].abs().max() > 0
    assert_equivariant(fn, pos, atol=1e-9)


def test_pseudovector_hidden_irrep_keeps_parity(float64):
    paths = message_paths([Irrep(0, 1), Irrep(1, 1), Irrep(1, -1)], 2)
    for ir_in, l_sh, ir_out in paths:
        assert ir_in.p * (-1) ** l_sh == ir_out.p
    # 0e can reach 1e only through... nothing (1e needs an odd-parity partner with l_sh=1)
    assert not any(i == Irrep(0, 1) and o == Irrep(1, 1) for i, _, o in paths)


@pytest.mark.parametrize("backend", BACKENDS)
def test_backend_parity(float64, backend):
    f, pos, z, b = setup("e3nn")
    feats = f(positions=pos, atomic_numbers=z, batch_idx=b)
    outs = []
    for be in ("e3nn", backend):
        torch.manual_seed(1)
        mp = EquivariantMessagePassing(irreps_in=feats.irreps, cutoff=3.5, backend=be, hidden_irreps="0e+1o+2e",
                                       channels=4, avg_num_neighbors=4.0).double()
        randomize(mp)
        outs.append(mp(feats, pos))
    for ir in outs[0]:
        assert torch.allclose(outs[0][ir], outs[1][ir], atol=1e-12)


def test_a_structure_does_not_feel_its_batch(float64):
    f, pos, z, b = setup(sizes=(6, 8, 5))
    mp = EquivariantMessagePassing(irreps_in=f.irreps_out, cutoff=3.5, channels=4, avg_num_neighbors=3.0).double()
    randomize(mp)
    full = mp(f(positions=pos, atomic_numbers=z, batch_idx=b), pos)
    m = b == 0
    alone = mp(f(positions=pos[m], atomic_numbers=z[m], batch_idx=b[m]), pos[m])
    for ir in alone:
        assert torch.allclose(full[ir][m], alone[ir], atol=1e-12)


def test_legacy_normalisation_warns_once(float64):
    f, pos, z, b = setup(lambdas=(0, 2))
    feats = f(positions=pos, atomic_numbers=z, batch_idx=b)
    mp = EquivariantMessagePassing(p0=feats.widths[Irrep(0, 1)], p2=feats.widths[Irrep(2, 1)], emb_dim=0,
                                   cutoff=3.5, channels=4).double()
    with pytest.warns(RuntimeWarning):
        mp(feats.inv_feats, feats.equiv_feats, pos, feats.edge_index, None)


def test_average_num_neighbors_matches_graph(float64):
    f, pos, z, b = setup()
    ei = f.build_edges(pos, b)
    avg = average_num_neighbors([(pos, b)], cutoff=3.5)
    assert avg == pytest.approx(max(ei.shape[1] / len(z), 1.0))


def test_original_parameter_names():
    mp = EquivariantMessagePassing(p0=10, p2=6, emb_dim=4, cutoff=3.0, channels=4, layers=1)
    keys = set(mp.state_dict())
    for k in ["lin_in0.weight", "lin_in2", "lin_out0.weight", "lin_out2", "convs.0.self_0.weight", "convs.0.self_2",
              "convs.0.path_mix.000", "convs.0.path_mix.022", "convs.0.path_mix.220", "convs.0.path_mix.202",
              "convs.0.path_mix.222", "convs.0.radial_mlp.2.weight"]:
        assert k in keys, k


def test_radial_basis_smooth_at_cutoff(float64):
    from bb.features import bessel_envelope_basis

    r = torch.tensor([3.0 - 1e-4, 3.0], requires_grad=True)
    basis = bessel_envelope_basis(r, 3.0, 8)
    assert basis[1].abs().max() < 1e-12          # value -> 0 at the cutoff
    basis[0].sum().backward()
    assert r.grad[0].abs() < 1e-2                # derivative -> 0 approaching the cutoff


def test_edge_order_is_irrelevant(float64):
    f, pos, z, b = setup()
    feats = f(positions=pos, atomic_numbers=z, batch_idx=b)
    mp = EquivariantMessagePassing(irreps_in=feats.irreps, cutoff=3.5, channels=4, avg_num_neighbors=3.0).double()
    randomize(mp)
    perm = torch.randperm(feats.edge_index.shape[1], generator=torch.Generator().manual_seed(5))
    a = mp(feats, pos)
    c = mp(feats, pos, edge_index=feats.edge_index[:, perm])
    for ir in a:
        assert torch.allclose(a[ir], c[ir], atol=1e-12)


def test_receptive_field_grows_with_layers(float64):
    """With 2 layers, atom 0 feels a perturbation two hops away (beyond the cutoff)."""
    pos = torch.tensor([[0.0, 0, 0], [3.0, 0, 0], [6.0, 0, 0]])
    edges = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
    g = torch.Generator().manual_seed(7)
    blocks = {"0e": torch.randn(3, 1, 5, generator=g), "2e": torch.randn(3, 5, 4, generator=g)}
    for layers, should_see in ((1, False), (2, True)):
        torch.manual_seed(0)
        mp = EquivariantMessagePassing(irreps_in={"0e": 5, "2e": 4}, cutoff=4.0, layers=layers,
                                       channels=4, avg_num_neighbors=2.0).double()
        randomize(mp)
        base = mp(blocks, pos, edges)["0e"][0]
        moved_blocks = {"0e": blocks["0e"].clone(), "2e": blocks["2e"]}
        moved_blocks["0e"][2] += 1.0
        moved = mp(moved_blocks, pos, edges)["0e"][0]
        assert bool((base - moved).abs().max() > 1e-8) == should_see, f"layers={layers}"
