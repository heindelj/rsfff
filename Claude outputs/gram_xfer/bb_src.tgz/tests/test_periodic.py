import numpy as np
import pytest
import torch

from bb.graph import build_periodic_graph, build_radius_graph, pair_graph, site_pair_graph


def _random_cell(seed, n=7):
    g = torch.Generator().manual_seed(seed)
    cell = torch.tensor([[4.0, 0.0, 0.0], [1.0, 3.5, 0.0], [0.5, -0.7, 5.0]], dtype=torch.float64)
    cell = cell + 0.3 * torch.randn(3, 3, generator=g, dtype=torch.float64)
    frac = torch.rand(n, 3, generator=g, dtype=torch.float64)
    return frac @ cell, cell


def _edge_set(pe, positions):
    vec = pe.vectors(positions)
    a, b = pe.edge_index
    return sorted((int(i), int(j), *np.round(v.tolist(), 6)) for i, j, v in zip(a, b, vec))


def test_matches_ase_neighbor_list():
    ase_nl = pytest.importorskip("ase.neighborlist")
    import ase

    pos, cell = _random_cell(0)
    r = 4.5
    pe = build_periodic_graph(pos, r, cell, context="test")
    atoms = ase.Atoms("H7", positions=pos.numpy(), cell=cell.numpy(), pbc=True)
    i, j, D = ase_nl.neighbor_list("ijD", atoms, r)
    ref = sorted((int(a), int(b), *np.round(d, 6)) for a, b, d in zip(i, j, D))
    assert _edge_set(pe, pos) == ref


def test_self_images_and_symmetry():
    pos, cell = _random_cell(1, n=2)
    pe = build_periodic_graph(pos, 6.0, cell, context="test")
    a, b = pe.edge_index
    assert bool((a == b).any())  # an atom sees its own images
    fwd = {(int(i), int(j), *pe.shifts[k].tolist()) for k, (i, j) in enumerate(zip(a, b))}
    assert all((j, i, -x, -y, -z) in fwd for (i, j, x, y, z) in fwd)


def test_nonperiodic_matches_radius_graph():
    pos, cell = _random_cell(2, n=12)
    batch = torch.zeros(12, dtype=torch.long)
    pe = build_periodic_graph(pos, 3.0, cell, torch.zeros(3, dtype=torch.bool), batch, context="test")
    ref = build_radius_graph(pos, 3.0, batch, context="test")
    assert sorted(map(tuple, pe.edge_index.T.tolist())) == sorted(map(tuple, ref.T.tolist()))
    assert bool((pe.shifts == 0).all())


def test_unwrapped_positions_and_batches():
    pos, cell = _random_cell(3)
    shifted = pos + torch.tensor([2.0, -1.0, 3.0], dtype=torch.float64) @ cell  # outside the cell
    ref = _edge_set(build_periodic_graph(pos, 4.0, cell, context="t"), pos)
    pe = build_periodic_graph(shifted, 4.0, cell, context="t")
    got = _edge_set(pe, shifted)
    assert [g[:2] for g in got] == [r[:2] for r in ref]
    assert np.allclose([g[2:] for g in got], [r[2:] for r in ref])
    both = torch.cat([pos, pos])
    batch = torch.repeat_interleave(torch.arange(2), 7)
    pe2 = build_periodic_graph(both, 4.0, torch.stack([cell, cell]), batch=batch, context="t")
    assert pe2.n_edges == 2 * len(ref)
    assert bool((batch[pe2.edge_index[0]] == batch[pe2.edge_index[1]]).all())


def test_offsets_carry_cell_gradient():
    pos, cell = _random_cell(4)
    cell = cell.clone().requires_grad_(True)
    pe = build_periodic_graph(pos, 4.0, cell, context="t")
    pe.vectors(pos).norm(dim=-1).sum().backward()
    assert cell.grad is not None and cell.grad.abs().sum() > 0


def test_site_pairs_and_pair_graph_layout():
    pos, cell = _random_cell(5, n=9)
    sites = torch.tensor([1, 0, 1, 1, 0, 0, 1, 0, 1], dtype=torch.bool)
    pairs = site_pair_graph(pos, 5.0, sites, cell)
    assert bool(sites[pairs.edge_index].all())
    env = build_periodic_graph(pos, 2.5, cell, context="env")
    pg = pair_graph(pairs, env, 9)
    nb = pg.n_bonds
    assert pg.n_edges == 2 * nb == pairs.n_edges
    a, b = pg.edge_index
    assert torch.equal(a[nb:], b[:nb]) and torch.equal(b[nb:], a[:nb])
    assert torch.equal(pg.shifts[nb:], -pg.shifts[:nb])
    vec = pg.vectors(pos)
    assert torch.allclose(vec[nb:], -vec[:nb])
    # near pairs: env edge centred on the pair's first atom, never the pair itself
    e, m = pg.near
    assert torch.equal(env.edge_index[0, m], a[e])
    e, m = pg.far
    assert torch.equal(env.edge_index[0, m], b[e])
    back = (env.edge_index[1, m] == a[e]) & (env.shifts[m] == -pg.shifts[e]).all(-1)
    assert not bool(back.any())


def _periodic_model():
    from bb.config import MessagePassingConfig
    from bb.features import SOAPFeaturizer
    from bb.models import EnergyModel

    torch.manual_seed(0)
    feat = SOAPFeaturizer(cutoff=3.0, n_max=3, l_max=2, neighbor_types=(1, 8), selected_lambdas=(0, 1, 2))
    mp = MessagePassingConfig(hidden_irreps="0e + 1o", avg_num_neighbors=10.0)
    model = EnergyModel(feat, message_passing=mp).double()
    with torch.no_grad():  # message passing and readout start as no-ops; make them count
        for prm in model.parameters():
            prm.add_(0.1 * torch.randn_like(prm))
    return model


def test_periodic_energy_model_supercell_and_forces():
    model = _periodic_model()
    g = torch.Generator().manual_seed(7)
    cell = torch.diag(torch.tensor([3.4, 3.1, 3.7], dtype=torch.float64))
    pos = torch.rand(4, 3, generator=g, dtype=torch.float64) @ cell
    z = torch.tensor([8, 1, 1, 8])
    e1 = model(positions=pos, atomic_numbers=z, cell=cell[None])["energy"]
    # a 2x1x1 supercell has twice the energy
    sc = cell.clone(); sc[0] *= 2
    pos2 = torch.cat([pos, pos + cell[0]])
    e2 = model(positions=pos2, atomic_numbers=torch.cat([z, z]), cell=sc[None])["energy"]
    assert torch.allclose(e2, 2 * e1, atol=1e-10)
    # wrapping an atom by a lattice vector changes nothing
    pw = pos.clone(); pw[1] += cell[1]
    assert torch.allclose(model(positions=pw, atomic_numbers=z, cell=cell[None])["energy"], e1, atol=1e-10)
    # forces are -dE/dx, finite differences
    out = model(positions=pos, atomic_numbers=z, cell=cell[None], compute_forces=True)
    h = 1e-5
    for (a, k) in [(0, 0), (2, 1), (3, 2)]:
        p, m = pos.clone(), pos.clone()
        p[a, k] += h; m[a, k] -= h
        fd = -(model(positions=p, atomic_numbers=z, cell=cell[None])["energy"]
               - model(positions=m, atomic_numbers=z, cell=cell[None])["energy"]) / (2 * h)
        assert torch.allclose(out["forces"][a, k], fd[0], atol=1e-6)
