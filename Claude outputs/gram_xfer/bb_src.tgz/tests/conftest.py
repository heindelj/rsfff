import warnings

import pytest
import torch

import e3nn  # noqa: F401  -- import before cuequivariance_torch (see bb.o3.backend)

try:
    import cuequivariance_torch  # noqa: F401
    HAVE_CUE = True
except ImportError:  # pragma: no cover
    HAVE_CUE = False

warnings.filterwarnings("ignore", message="torch_cluster is not installed")

needs_cue = pytest.mark.skipif(not HAVE_CUE, reason="cuequivariance not installed")
BACKENDS = ["e3nn", pytest.param("cue", marks=needs_cue)]


@pytest.fixture
def float64():
    prev = torch.get_default_dtype()
    torch.set_default_dtype(torch.float64)
    yield
    torch.set_default_dtype(prev)


def molecules(seed=0, sizes=(5, 7), types=(1, 6, 8), box=2.6):
    """Random non-overlapping clusters, far apart (no cross-structure edges)."""
    g = torch.Generator().manual_seed(seed)
    pos, z, b = [], [], []
    for m, n in enumerate(sizes):
        pts = []
        while len(pts) < n:
            p = (torch.rand(3, generator=g, dtype=torch.float64) - 0.5) * 2 * box
            if all((p - q).norm() > 0.9 for q in pts):
                pts.append(p)
        pos.append(torch.stack(pts) + 40.0 * m)
        z.append(torch.tensor(types)[torch.randint(len(types), (n,), generator=g)])
        b.append(torch.full((n,), m, dtype=torch.long))
    return torch.cat(pos), torch.cat(z), torch.cat(b)
