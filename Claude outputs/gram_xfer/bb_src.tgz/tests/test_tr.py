import torch

from bb.features import PairClusterExpansion
from bb.graph import build_periodic_graph, pair_graph, site_pair_graph
from bb.tr import TREmbedding, TRMessagePassing, TRReadout, check_time_reversal

torch.set_default_dtype(torch.float64)


def _setup(seed=0):
    torch.manual_seed(seed)
    g = torch.Generator().manual_seed(seed)
    cell = torch.eye(3) * 6.0
    pos = torch.rand(12, 3, generator=g) @ cell
    species = torch.tensor([0, 1] * 6)
    pairs = site_pair_graph(pos, 5.0, species == 0, cell)
    env = build_periodic_graph(pos, 2.5, cell, context="env")
    pgraph = pair_graph(pairs, env, 12)
    ece = PairClusterExpansion([26, 8], env_cutoff=2.5, pair_cutoff=5.0, n_env=3, n_max=4, l_max=2, channels=3)
    ef = ece(pos, species, pgraph)
    edge_feat = torch.cat([ef.inv0e, ef.inv0o.square(), ef.bond_radial], dim=-1)
    emb = TREmbedding(2, 8, 6)
    mp = TRMessagePassing(8, 6, edge_feat.shape[1], layers=2, hidden=16, avg_num_neighbors=4.0)
    ro = TRReadout(8, 6, n_even=1, n_odd=1, hidden=16, zero_init=False)
    with torch.no_grad():
        for p in mp.parameters():
            p.add_(0.2 * torch.randn_like(p))
    m = torch.randn(12, generator=g) * (species == 0)

    def fn(mm):
        x = mp(emb(species, mm, vector=mm.dim() == 2), pgraph.edge_index, edge_feat)
        return ro(x)

    return fn, m, species


def test_time_reversal_exact():
    fn, m, _ = _setup()
    e, o = check_time_reversal(fn, m)
    assert e.abs().sum() > 0 and o.abs().sum() > 0


def test_spin_pattern_matters_for_even_outputs():
    fn, m, species = _setup(1)
    flipped_one = m.clone()
    i = int((species == 0).nonzero()[0])
    flipped_one[i] = -flipped_one[i]
    e1, _ = fn(m)
    e2, _ = fn(flipped_one)
    assert not torch.allclose(e1, e2)  # relative orientation is seen, a global flip is not


def test_zero_moments_give_zero_odd():
    fn, m, _ = _setup(2)
    _, o = fn(torch.zeros_like(m))
    assert torch.allclose(o, torch.zeros_like(o))


def _rotation(seed):
    q, _ = torch.linalg.qr(torch.randn(3, 3, generator=torch.Generator().manual_seed(seed)))
    return q * torch.sign(torch.det(q))


def test_vector_lift_of_collinear_is_exact():
    fn, m, _ = _setup(3)
    e_s, o_s = fn(m)
    mv = torch.zeros(len(m), 3)
    mv[:, 2] = m
    e_v, o_v = fn(mv @ _rotation(0).T)          # collinear along any axis
    assert torch.allclose(e_s, e_v, atol=1e-12)
    assert torch.allclose(o_v @ _rotation(0), torch.stack([torch.zeros_like(o_s), torch.zeros_like(o_s), o_s], -1), atol=1e-12)


def test_vector_spin_rotation_and_time_reversal():
    fn, m, species = _setup(4)
    mv = torch.randn(len(m), 3, generator=torch.Generator().manual_seed(5)) * (species == 0)[:, None]
    R = _rotation(1)
    e1, o1 = fn(mv)
    e2, o2 = fn(mv @ R.T)
    e3, o3 = fn(-mv)
    assert torch.allclose(e1, e2, atol=1e-12) and torch.allclose(o1 @ R.T, o2, atol=1e-12)
    assert torch.allclose(e1, e3, atol=1e-12) and torch.allclose(o1, -o3, atol=1e-12)
