"""Edge cluster expansion: frames, bond graphs, invariant features and the edge readout."""

import math

import numpy as np
import pytest
import torch

import e3nn  # noqa: F401  -- import before cuequivariance_torch (see bb.o3.backend)
from e3nn import o3

from conftest import BACKENDS
from bb.config import EdgeFeaturizerConfig, EdgeReadoutConfig
from bb.features import EdgeClusterExpansion, MorseBasis
from bb.graph import bond_graph, covalent_bonds, line_graph
from bb.heads import EdgeScalarReadout
from bb.o3 import E3NN, MIndex, calibrate, edge_frames, get_backend, wigner_d_recursive


@pytest.fixture(autouse=True)
def _f64(float64):
    yield


# --------------------------------------------------------------------------- #
# Frames
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("backend", BACKENDS)
def test_calibrate(backend):
    assert calibrate(backend, l_max=4) == E3NN


def _units():
    u = torch.randn(200, 3, generator=torch.Generator().manual_seed(0))
    axis = torch.tensor(E3NN.axis)
    special = torch.stack([axis, -axis, -axis + 1e-9 * torch.tensor([1.0, 0, 0]),
                           torch.tensor([1.0, 0, 0]), torch.tensor([0, 0, 1.0])])
    u = torch.cat([u, special])
    return u / u.norm(dim=-1, keepdim=True)


def test_frames_align_and_orthonormal():
    u = _units()
    R = edge_frames(u)
    axis = torch.tensor(E3NN.axis)
    assert torch.allclose(torch.einsum("eij,ej->ei", R, u), axis.expand_as(u), atol=1e-12)
    assert torch.allclose(R @ R.transpose(1, 2), torch.eye(3).expand_as(R), atol=1e-12)
    assert torch.allclose(torch.linalg.det(R), torch.ones(len(u)), atol=1e-12)


def test_frames_gradient_finite_everywhere():
    u = _units().requires_grad_(True)
    R = edge_frames(u / u.norm(dim=-1, keepdim=True))
    (g,) = torch.autograd.grad(R.square().sum() + R[:, 0, 1].sum(), u)
    assert torch.isfinite(g).all()


@pytest.mark.parametrize("backend", BACKENDS)
def test_sh_in_edge_frame_is_pure_m0(backend):
    L = 6 if backend == "e3nn" else 4  # cue's CPU ("naive") harmonics stop below l = 6
    u = _units()
    y = get_backend(backend).spherical_harmonics(torch.einsum("eij,ej->ei", edge_frames(u), u), L)
    mask = torch.ones(y.shape[-1], dtype=torch.bool)
    mask[MIndex.build(L).zero] = False
    assert y[:, mask].abs().max() < 1e-12


@pytest.mark.parametrize("backend", BACKENDS)
def test_wigner_recursive_matches_e3nn(backend):
    R = o3.rand_matrix(50)
    for l, D in enumerate(wigner_d_recursive(R, 6, backend)):
        ref = o3.Irrep(l, (-1) ** l).D_from_matrix(R)
        assert torch.allclose(D, ref, atol=1e-12), l


@pytest.mark.parametrize("backend", BACKENDS)
def test_wigner_rotates_sh(backend):
    be = get_backend(backend)
    R = o3.rand_matrix(20)
    v = torch.randn(20, 3)
    y, yr = be.spherical_harmonics(v, 5), be.spherical_harmonics(torch.einsum("eij,ej->ei", R, v), 5)
    for l, D in enumerate(wigner_d_recursive(R, 5, be)):
        s = slice(l * l, (l + 1) ** 2)
        assert torch.allclose(torch.einsum("eij,ej->ei", D, y[:, s]), yr[:, s], atol=1e-12)


# --------------------------------------------------------------------------- #
# Graphs
# --------------------------------------------------------------------------- #
def random_tree(n_heavy=5, n_h=8, seed=0):
    """A random bonded tree (C/O backbone + H) with plausible bond lengths."""
    rng = np.random.default_rng(seed)
    z = [6] * (n_heavy - 1) + [8] + [1] * n_h
    pos = [np.zeros(3)]
    bonds = []
    for a in range(1, len(z)):
        parent = a - 1 if a < n_heavy else int(rng.integers(0, n_heavy))
        d = rng.normal(size=3)
        d /= np.linalg.norm(d)
        pos.append(pos[parent] + (1.1 if z[a] == 1 else 1.5) * d)
        bonds.append((parent, a))
    species_list = [1, 6, 8]
    species = torch.tensor([species_list.index(x) for x in z])
    return torch.tensor(np.array(pos)), species, bonds, species_list


def test_graph_bookkeeping():
    g = bond_graph([(0, 1), (1, 2), (2, 3), (1, 4)], 5)
    src, dst = g.edge_index
    assert torch.equal(src[g.rev], dst) and torch.equal(dst[g.rev], src)
    e, e2 = g.near
    assert torch.equal(src[e], src[e2]) and not (e == e2).any()
    e, e2 = g.far
    assert torch.equal(dst[e], src[e2]) and not (e2 == g.rev[e]).any()
    with pytest.raises(ValueError):
        bond_graph([(0, 1), (1, 0)], 2)
    with pytest.raises(ValueError):
        bond_graph([(0, 3)], 2)


def test_line_graph_sign_flips_with_orientation():
    lg1 = line_graph(bond_graph([(0, 1), (1, 2)], 3))
    lg2 = line_graph(bond_graph([(1, 0), (1, 2)], 3))
    assert torch.equal(lg1.pairs, lg2.pairs) and torch.equal(lg1.shared, lg2.shared)
    assert lg1.sigma[0, 0] == -lg2.sigma[0, 0] and lg1.sigma[1, 0] == lg2.sigma[1, 0]


def test_covalent_bonds_recovers_tree():
    pos, species, bonds, sl = random_tree()
    z = torch.tensor(sl)[species]
    found = {tuple(sorted(b)) for b in covalent_bonds(pos, z).tolist()}
    # the random tree can place non-bonded atoms close; every true bond must be found
    assert {tuple(sorted(b)) for b in bonds} <= found


def test_morse_basis():
    mb = MorseBasis([1, 6], n_basis=3, a=2.0)
    r0 = 0.76 + 0.31
    out = mb(torch.tensor([r0, 10.0]), torch.tensor([1, 1]), torch.tensor([0, 0]))
    assert torch.allclose(out[0], torch.ones(3))                 # y = 1 at r0
    assert out[1, 1:].abs().max() < 1e-6 and out[1, 0] == 1.0   # bounded, decays
    with pytest.raises(KeyError):
        MorseBasis([1, 118])


# --------------------------------------------------------------------------- #
# Features and readout
# --------------------------------------------------------------------------- #
@pytest.fixture
def mol():
    return random_tree()


def build(species_list, l_max=4, seed=0, backend="e3nn", **readout):
    torch.manual_seed(seed)
    ece = EdgeClusterExpansion(species_list, n_max=4, l_max=l_max, channels=8, species_dim=3,
                               backend=backend)
    head = EdgeScalarReadout.from_ece(ece, hidden=32, **readout)
    return ece, head


def energy(ece, head, pos, species, g, twist=None):
    return head(ece(pos, species, g, twist))["total"].sum()


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("odd", ["symmetrize", "square"])
def test_o3_invariance(mol, backend, odd):
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, head = build(sl, backend=backend, odd=odd)
    f0 = ece(pos, species, g)
    e0 = head(f0)["total"]
    for improper in (False, True):
        R = o3.rand_matrix()
        if improper:
            R = -R
        p = pos @ R.T + torch.randn(3)
        f = ece(p, species, g)
        assert torch.allclose(f.inv0e, f0.inv0e, atol=1e-10)
        sign = -1.0 if improper else 1.0
        assert torch.allclose(f.inv0o, sign * f0.inv0o, atol=1e-10)
        assert torch.allclose(head(f)["total"], e0, atol=1e-10)
    assert f0.inv0o.abs().max() > 1e-3  # the 0o block is not trivially zero


def test_symmetrized_odd_part_cancels_exactly(mol):
    """With odd="symmetrize" a term linear in a pseudoscalar averages to exactly zero."""
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, _ = build(sl)
    f = ece(pos, species, g)
    head = EdgeScalarReadout.from_ece(ece, depth=0)           # linear: o enters as +o and -o
    with torch.no_grad():
        head.mlp[0].weight.zero_()
        head.mlp[0].bias.zero_()
        head.mlp[0].weight[0, ece.dim_0e] = 1.0
    assert head.edge_values(f).abs().max() < 1e-14            # odd part averages out exactly


@pytest.mark.parametrize("backend", BACKENDS)
def test_gauge_invariance(mol, backend):
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, _ = build(sl, backend=backend)
    f0 = ece(pos, species, g)
    f1 = ece(pos, species, g, twist=torch.rand(g.n_edges) * 2 * math.pi)
    assert torch.allclose(f0.inv0e, f1.inv0e, atol=1e-11)
    assert torch.allclose(f0.inv0o, f1.inv0o, atol=1e-11)


def test_backends_agree(mol):
    pytest.importorskip("cuequivariance_torch")
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    a, _ = build(sl, backend="e3nn")
    b, _ = build(sl, backend="cue")
    b.load_state_dict(a.state_dict())
    fa, fb = a(pos, species, g), b(pos, species, g)
    assert torch.allclose(fa.inv0e, fb.inv0e, atol=1e-12)
    assert torch.allclose(fa.inv0o, fb.inv0o, atol=1e-12)


def test_bond_orientation_order_and_atom_permutation(mol):
    pos, species, bonds, sl = mol
    ece, head = build(sl)
    out0 = head(ece(pos, species, bond_graph(bonds, len(pos))))
    rng = np.random.default_rng(1)
    order = rng.permutation(len(bonds))
    b2 = [bonds[i][::-1] if rng.random() < 0.5 else bonds[i] for i in order]
    out1 = head(ece(pos, species, bond_graph(b2, len(pos))))
    assert torch.allclose(out1["bond"], out0["bond"][order], atol=1e-11)
    perm = torch.as_tensor(rng.permutation(len(pos)))
    inv = torch.argsort(perm)
    b3 = [(int(inv[i]), int(inv[j])) for i, j in bonds]
    out2 = head(ece(pos[perm], species[perm], bond_graph(b3, len(pos))))
    assert torch.allclose(out2["total"], out0["total"], atol=1e-11)


def test_antisymmetric_readout_flips_with_bond_orientation(mol):
    pos, species, bonds, sl = mol
    ece, head = build(sl, symmetry="antisym", n_out=2)
    out0 = head(ece(pos, species, bond_graph(bonds, len(pos))))
    flipped = [b[::-1] for b in bonds]
    out1 = head(ece(pos, species, bond_graph(flipped, len(pos))))
    assert "total" not in out0
    assert torch.allclose(out1["bond"], -out0["bond"], atol=1e-11)
    assert out0["bond"].abs().max() > 1e-6


def test_batched_totals(mol):
    pos, species, bonds, sl = mol
    n = len(pos)
    ece, head = build(sl)
    single = head(ece(pos, species, bond_graph(bonds, n)))["total"]
    pos2 = torch.cat([pos, pos @ o3.rand_matrix().T + 30.0])
    sp2 = torch.cat([species, species])
    b2 = bonds + [(i + n, j + n) for i, j in bonds]
    batch_idx = torch.cat([torch.zeros(n, dtype=torch.long), torch.ones(n, dtype=torch.long)])
    tot = head(ece(pos2, sp2, bond_graph(b2, 2 * n)), batch_idx)["total"]
    assert tot.shape == (2, 1)
    assert torch.allclose(tot, single.expand(2, 1), atol=1e-10)


def test_forces_match_finite_differences(mol):
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, head = build(sl)
    p = pos.clone().requires_grad_(True)
    (grad,) = torch.autograd.grad(energy(ece, head, p, species, g), p)
    h = 1e-5
    fd = torch.zeros_like(pos)
    for a in range(len(pos)):
        for c in range(3):
            d = torch.zeros_like(pos)
            d[a, c] = h
            fd[a, c] = (energy(ece, head, pos + d, species, g)
                        - energy(ece, head, pos - d, species, g)) / (2 * h)
    assert torch.allclose(grad, fd, atol=1e-7, rtol=1e-6)


def _chain(theta, omega=0.7):
    """k-i-j-l with angle k-i-j = theta (pi = linear) and dihedral omega."""
    i, j = np.zeros(3), np.array([1.5, 0, 0])
    k = i + 1.1 * np.array([-math.cos(math.pi - theta), math.sin(math.pi - theta), 0])
    l = j + 1.1 * np.array([math.cos(1.2), math.sin(1.2) * math.cos(omega),
                            math.sin(1.2) * math.sin(omega)])
    return torch.tensor(np.stack([i, j, k, l]))


def test_linear_angle_is_smooth():
    sl = [1, 6, 8]
    species = torch.tensor([1, 1, 2, 0])
    g = bond_graph([(0, 1), (2, 0), (1, 3)], 4)
    ece, head = build(sl)
    pts, vals, grads = [], [], []
    for th in [math.pi - 1e-3, math.pi - 1e-6, math.pi]:
        p = _chain(th).requires_grad_(True)
        e = energy(ece, head, p, species, g)
        (gr,) = torch.autograd.grad(e, p)
        assert torch.isfinite(gr).all()
        pts.append(p.detach())
        vals.append(e.detach())
        grads.append(gr)
    taylor = vals[2] + (grads[2] * (pts[1] - pts[2])).sum()
    assert abs(float(vals[1] - taylor)) < 1e-11
    assert torch.allclose(grads[1], grads[2], atol=1e-5)


def test_torsion_is_pure_fourier_mode():
    """Cross-end product at l = m is exactly A sin^m(t1) sin^m(t2) cos(m w)."""
    sl = [1, 6, 8]
    species = torch.tensor([1, 1, 2, 0])
    g = bond_graph([(0, 1), (2, 0), (1, 3)], 4)
    L = 4
    ece, _ = build(sl, l_max=L)
    mi = MIndex.build(L)
    n_w = 64
    omegas = torch.arange(n_w) * 2 * math.pi / n_w

    def products(theta):
        re, im = [], []
        for w in omegas:
            with torch.no_grad():
                a_n, a_f = ece.densities(_chain(theta, float(w)), species, g)
            row_r, row_i = [], []
            for m in range(1, L + 1):
                p = complex(a_n[0, 0, mi.plus[m][0]], a_n[0, 0, mi.minus[m][0]])
                q = complex(a_f[0, 0, mi.plus[m][0]], a_f[0, 0, mi.minus[m][0]])
                z = p * q.conjugate()
                row_r.append(z.real)
                row_i.append(z.imag)
            re.append(row_r)
            im.append(row_i)
        return np.array(re), np.array(im)

    t1, t2 = 1.9, 2.3
    re1, im1 = products(t1)
    re2, _ = products(t2)
    for m in range(1, L + 1):
        for series in (re1[:, m - 1], im1[:, m - 1]):
            spec = np.abs(np.fft.rfft(series))
            other = np.delete(spec, m)
            assert other.max() < 1e-10 * spec[m], (m, other.max(), spec[m])
        amp1 = np.abs(np.fft.rfft(re1[:, m - 1]))[m]
        amp2 = np.abs(np.fft.rfft(re2[:, m - 1]))[m]
        expect = (math.sin(math.pi - t1) / math.sin(math.pi - t2)) ** m
        assert abs(amp1 / amp2 - expect) < 1e-10 * expect


def test_configs_build_and_roundtrip(mol):
    pos, species, bonds, sl = mol
    fc = EdgeFeaturizerConfig.from_dict({"l_max": 3, "channels": 4})
    rc = EdgeReadoutConfig.from_dict({"symmetry": "sym", "hidden": 16})
    assert EdgeFeaturizerConfig.from_dict(fc.to_dict()) == fc
    with pytest.raises(ValueError):
        EdgeFeaturizerConfig.from_dict({"lmax": 3})
    ece = fc.build(sl)
    head = rc.build(ece)
    out = head(ece(pos, species, bond_graph(bonds, len(pos))))
    assert out["bond"].shape == (len(bonds), 1)


@pytest.mark.parametrize("backend", BACKENDS)
def test_dense_route_matches_direct_route(mol, backend):
    """Rotating whole atomic densities (the TACE / ECENet construction) gives bb's near / far
    densities plus an on-axis self term that is pure m = 0 and depends on r_ij only."""
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, _ = build(sl, backend=backend)
    be = get_backend(backend)
    L = ece.l_max
    with torch.no_grad():
        a_near, a_far = ece.densities(pos, species, g)
        src, dst = g.edge_index
        vec = pos[dst] - pos[src]
        r = vec.norm(dim=-1)
        rad = ece.radial(r, species[src], species[dst])
        f = (rad[:, :, None] * ece.nbr_emb(species[dst])[:, None, :]).reshape(len(r), -1)
        y = be.spherical_harmonics(vec / r[:, None], L)
        atom = torch.zeros(len(pos), ece.n_feat, y.shape[-1]).index_add(0, src, f[:, :, None] * y[:, None, :])

        frames = edge_frames(vec / r[:, None], ece.convention)
        Ds = wigner_d_recursive(frames, L, be)
        D = torch.block_diag(*[torch.zeros(2 * l + 1, 2 * l + 1) for l in range(L + 1)]).expand(len(r), -1, -1).clone()
        for l, Dl in enumerate(Ds):
            D[:, l * l:(l + 1) ** 2, l * l:(l + 1) ** 2] = Dl
        rot_i = torch.einsum("eab,efb->efa", D, atom[src])
        rot_j = torch.einsum("eab,efb->efa", D, atom[dst])

        axis = torch.tensor([E3NN.axis])
        y_up, y_down = be.spherical_harmonics(axis, L)[0], be.spherical_harmonics(-axis, L)[0]
        f_rev = (rad[:, :, None] * ece.nbr_emb(species[src])[:, None, :]).reshape(len(r), -1)
        self_i = f[:, :, None] * y_up        # partner j sits on +axis from i
        self_j = f_rev[:, :, None] * y_down  # partner i sits on -axis from j
    assert torch.allclose(rot_i, a_near + self_i, atol=1e-11)
    assert torch.allclose(rot_j, a_far + self_j, atol=1e-11)
    mask = torch.ones(y.shape[-1], dtype=torch.bool)
    mask[MIndex.build(L).zero] = False
    assert self_i[:, :, mask].abs().max() == 0 and self_j[:, :, mask].abs().max() < 1e-12


def test_diatomic_and_isolated_bond():
    """No neighbour pairs at all (P = 0): features are finite, densities zero."""
    ece, head = build([1, 9])
    g = bond_graph([(0, 1)], 2)
    pos = torch.tensor([[0.0, 0.0, 0.0], [0.0, 0.0, 0.92]], requires_grad=True)
    ef = ece(pos, torch.tensor([0, 1]), g)
    assert ef.inv0e.abs().max() == 0 and ef.inv0o.abs().max() == 0
    e = head(ef)["total"].sum()
    (f,) = torch.autograd.grad(e, pos)
    assert torch.isfinite(f).all() and torch.allclose(f[0], -f[1])


def test_readout_bond_basis(mol):
    """bond_basis: edge value = sum_q c_q(x) b_q(r_ij); invariant, smooth, and r_ij enters only via b_q."""
    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, head = build(sl, bond_basis=3)
    ef = ece(pos, species, g)
    e0 = head(ef)["total"]
    R = -o3.rand_matrix()
    assert torch.allclose(head(ece(pos @ R.T, species, g))["total"], e0, atol=1e-10)
    coeff = head._mlp_values(ef).reshape(-1, 1, 3)
    assert torch.allclose(head.edge_values(ef), (coeff * ef.bond_radial[:, None, :3]).sum(-1), atol=1e-14)
    with pytest.raises(ValueError):
        EdgeScalarReadout.from_ece(ece, bond_basis=ece.n_max + 1)


# --------------------------------------------------------------------------- #
# Equivariant edge outputs
# --------------------------------------------------------------------------- #
IRREPS_ALL = "2x0e + 1x0o + 2x1o + 1x1e + 1x2e + 1x2o + 1x3o"


def _equiv_model(sl, symmetry, backend="e3nn", irreps=IRREPS_ALL):
    from bb.heads import EdgeReadout

    torch.manual_seed(1)
    ece = EdgeClusterExpansion(sl, n_max=4, l_max=3, channels=6, species_dim=3, backend=backend)
    return ece, EdgeReadout(ece, irreps, symmetry=symmetry, hidden=24)


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("symmetry", ["sym", "antisym"])
def test_edge_readout_equivariance(mol, symmetry, backend):
    from bb.testing import assert_equivariant

    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, head = _equiv_model(sl, symmetry, backend)
    fn = lambda p: head(ece(p, species, g))["bond"]  # noqa: E731
    out = fn(pos)
    for k, v in out.items():
        assert v.abs().max() > 1e-6, k          # nothing trivially zero, parity rule included
    for _ in range(3):
        assert_equivariant(fn, pos, atol=1e-10)


def test_edge_readout_gauge_and_orientation(mol):
    pos, species, bonds, sl = mol
    ece, head = _equiv_model(sl, "antisym")
    g = bond_graph(bonds, len(pos))
    y0 = head(ece(pos, species, g))["bond"]
    y1 = head(ece(pos, species, g, twist=torch.rand(g.n_edges) * 6.3))["bond"]
    for k in y0:
        assert torch.allclose(y0[k], y1[k], atol=1e-11), k
    y2 = head(ece(pos, species, bond_graph([b[::-1] for b in bonds], len(pos))))["bond"]
    for k in y0:
        assert torch.allclose(y2[k], -y0[k], atol=1e-11), k
    ece, head = _equiv_model(sl, "sym")
    s0 = head(ece(pos, species, g))["bond"]
    s2 = head(ece(pos, species, bond_graph([b[::-1] for b in bonds], len(pos))))["bond"]
    for k in s0:
        assert torch.allclose(s2[k], s0[k], atol=1e-11), k


def test_flow_to_charges_and_bond_to_atoms(mol):
    from bb.heads import bond_to_atoms, flow_to_charges

    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    ece, head = _equiv_model(sl, "antisym", irreps="1x0e")
    f = head(ece(pos, species, g))["bond"]["0e"][:, 0, 0]
    q = flow_to_charges(f, g)
    q = q.detach()
    assert abs(float(q.sum())) < 1e-12 and q.abs().max() > 1e-6
    v = torch.randn(g.n_bonds, 3, 2)
    assert torch.allclose(bond_to_atoms(v, g).sum(0), v.sum(0), atol=1e-12)


def test_edge_readout_rejects_high_l(mol):
    from bb.heads import EdgeReadout

    *_, sl = mol
    ece = EdgeClusterExpansion(sl, n_max=2, l_max=2, channels=2)
    with pytest.raises(ValueError):
        EdgeReadout(ece, "1x3o")


def test_morse_legendre_spans_powers():
    r = torch.linspace(0.9, 1.4, 50)
    si = torch.ones(50, dtype=torch.long)
    sj = torch.zeros(50, dtype=torch.long)
    P = MorseBasis([1, 6], n_basis=5)(r, si, sj)
    Lg = MorseBasis([1, 6], n_basis=5, polynomial="legendre")(r, si, sj)
    coef = torch.linalg.lstsq(Lg, P).solution
    assert torch.allclose(Lg @ coef, P, atol=1e-10)
    assert torch.linalg.cond(Lg) < 1e-2 * torch.linalg.cond(P)


def test_bond_graph_tensor_path_matches_list_path():
    # two molecules in one batch: a branched chain and a ring-free star
    bonds = [(0, 1), (1, 2), (2, 3), (1, 4), (2, 5), (6, 7), (6, 8), (6, 9), (6, 10)]
    g_list = bond_graph(bonds, 11)
    g_t = bond_graph(torch.tensor(bonds), 11)
    for name in ("edge_index", "rev", "bond_id", "bonds"):
        assert torch.equal(getattr(g_list, name), getattr(g_t, name)), name
    for name in ("near", "far"):
        a = {tuple(p) for p in getattr(g_list, name).T.tolist()}
        b = {tuple(p) for p in getattr(g_t, name).T.tolist()}
        assert a == b, name
    with pytest.raises(ValueError):
        bond_graph(torch.tensor([(0, 1), (1, 0)]), 2)
    empty = bond_graph(torch.zeros(0, 2, dtype=torch.long), 3)
    assert empty.near.shape == (2, 0) and empty.far.shape == (2, 0)


def test_ece_bond_weight_unit_is_identity_and_zero_drops_neighbour():
    pos = torch.tensor([[0.0, 0.0, 0.0], [1.1, 0.0, 0.0], [-0.4, 1.0, 0.1], [1.5, 1.0, -0.2]],
                       dtype=torch.float64)
    bonds = [(0, 1), (0, 2), (1, 3)]
    g = bond_graph(bonds, 4)
    ece = EdgeClusterExpansion([1, 6], n_max=3, l_max=2, channels=4).double()
    sp = torch.tensor([1, 1, 0, 0])
    f0 = ece(pos, sp, g)
    f1 = ece(pos, sp, g, bond_weight=torch.ones(3, dtype=torch.float64))
    assert torch.allclose(f0.inv0e, f1.inv0e)
    # dropping bond (1, 3) == the graph without it, for the features of bond (0, 1)
    fw = ece(pos, sp, g, bond_weight=torch.tensor([1.0, 1.0, 0.0], dtype=torch.float64))
    g2 = bond_graph([(0, 1), (0, 2)], 4)
    f2 = ece(pos, sp, g2)
    assert torch.allclose(fw.inv0e[[0, 3]], f2.inv0e[[0, 2]], atol=1e-12)


def test_edge_readout_extra_inputs_and_compression(mol):
    """Invariant per-edge extras and asinh compression keep the readout equivariant."""
    from bb.heads import EdgeReadout
    from bb.testing import assert_equivariant

    pos, species, bonds, sl = mol
    g = bond_graph(bonds, len(pos))
    torch.manual_seed(2)
    ece = EdgeClusterExpansion(sl, n_max=4, l_max=3, channels=6, species_dim=3)
    head = EdgeReadout(ece, "1x1o + 1x2e", hidden=24, extra_dim=2, compress=True)
    extra = torch.randn(g.n_edges, 2, dtype=pos.dtype)
    fn = lambda p: head(ece(p, species, g), extra)["edge"]  # noqa: E731
    assert all(v.abs().max() > 1e-6 for v in fn(pos).values())
    for _ in range(2):
        assert_equivariant(fn, pos, atol=1e-10)
    with pytest.raises(ValueError):
        head(ece(pos, species, g))
