# bb — Black Box

Equivariant features and neural-network building blocks for MLIPs and for networks that
predict the parameters of physical models. bb is the shared layer under `rsfff`,
`pauli_fierz_pinn` and `hbq_qed`. It owns everything that turns geometry, plus any extra
per-atom or per-system inputs you give it, into learned representations and equivariant
outputs.

bb does not train models. Losses, training loops, datasets and the physics live in each
project.

```python
import torch
from bb.features import SOAPFeaturizer
from bb.nn import EquivariantMessagePassing
from bb.heads import IrrepsReadout, pool

feat = SOAPFeaturizer(cutoff=5.0, n_max=6, l_max=3, neighbor_types=(1, 6, 7, 8),
                      selected_lambdas=(0, 1, 2), backend="e3nn")          # or "cue"
mp = EquivariantMessagePassing(irreps_in=feat.irreps_out, emb_dim=16, cutoff=5.0,
                               hidden_irreps="0e + 1o + 2e", avg_num_neighbors=18.0)
emb = torch.nn.Embedding(feat.n_species, 16)
head = IrrepsReadout(feat.irreps_out, "1x0e + 1x1o", scalar_dim=16)

x = feat(positions=pos, atomic_numbers=z, batch_idx=batch_idx)   # IrrepFeatures: 0e, 1o, 2e
s = emb(x.species_idx)
x = mp(x, pos, emb=s)                                             # residual, no-op at init
y = head(x, s)                                                    # y["0e"]: (N,1,1), y["1o"]: (N,3,1)
energy = pool(y["0e"][:, 0, 0], batch_idx)
```

## What is in it

| Package | Contents |
|---|---|
| `bb.graph` | `build_radius_graph`, which always passes an explicit neighbor cap and reports when an atom reaches it (pure-torch fallback when torch-cluster is missing); flat-batch helpers; `average_num_neighbors`. |
| `bb.o3` | `Irrep`, `Irreps`, and `IrrepFeatures`, the container every module passes around (one `(N, 2l+1, C)` block per irrep). Also the `e3nn` and `cue` backends, which give the same numbers, and Voigt/Cartesian helpers. |
| `bb.features` | The featurization pipeline as public stages: edge expansion → density (by species, by learned per-atom weights, or with a mask or soft per-edge weight) → compression → power spectrum / bispectrum / cross spectrum. Featurizers: `SOAPFeaturizer`, `StateSOAPFeaturizer`, `PartitionedFeaturizer` (internal vs. environment density, exact zero for an isolated group). |
| `bb.nn` | `mlp`; `zero_init_readout`, weight-decay exemption and `parameter_groups`; named parameter slots and `TwoSlotLinear`; FiLM `ConditionedTrunk`; `EquivariantMessagePassing`, which refines or creates any set of irreps. |
| `bb.inputs` | Couples equivariant inputs you supply (an electric field, a cavity polarization, multipoles, a spin pseudovector) into the features with Clebsch-Gordan products, tracking parity. |
| `bb.heads` | `IrrepsReadout`: any `Kx0e + Mx1o + …` output from the features, with no physical meaning attached. Transforms: `pool`, `constrain_sum`, `to_voigt`, `psd_symmetric`, `softplus_floor`, `bounded`, `first_moment`. |
| `bb.config` | Strict dataclass configs with `build(...)`. Old pf/hbq key names are accepted. |
| `bb.models` | `EnergyModel`, a small reference MLIP. |
| `bb.ensemble` | `Ensemble`: a committee evaluated as one `vmap`-ed forward, including forces. |
| `bb.testing` | `assert_equivariant`, which rotates and inverts the positions together with the equivariant inputs. |
| `bb.compat` | Helpers for loading checkpoints from before bb existed (`register_legacy_keys`, `upgrade_state_dict`, `remap_state_dict`, `load_state_dict_lenient`). |

## Inputs from elsewhere

Every module takes plain tensors. No module needs a project's batch class.

- **Invariant inputs.** Concatenate onto the scalars a readout or message-passing layer
  already reads (`scalar_dim` / `emb_dim`), or use them as a FiLM conditioning vector.
- **Equivariant inputs.** Couple them in with `bb.inputs.IrrepCoupling` and concatenate the
  result onto the features (`x = x.cat(coupling(x, field))`). An input in a project's own
  spherical convention must be converted to the backend basis first.

## Install

The distribution is named `bb-black-box` (import name `bb`); depend on it under that name.

```bash
pip install -e .                      # torch, e3nn, numpy
pip install -e '.[cue-cu12]'          # + cuequivariance with CUDA 12 ops (or cue-cu13, or cue)
FORCE_ONLY_CPU=1 pip install --no-build-isolation torch-cluster   # optional, faster neighbor list
```

## Tests

```bash
pytest                    # unit tests + golden parity
pytest -m "not golden"    # unit tests only
```

`tests/golden` checks bb against outputs captured from the source repos with
`tools/golden/capture.py`: the featurizers, message passing, heads and real checkpoints
from pauli_fierz_pinn and hbq_qed. Each case loads the original state dict into the bb
module and must reproduce the original outputs to 1e-10 in float64, on both backends.

See `docs/PLAN.md` for the design and `docs/porting.md` for moving each project onto bb.
