"""A reference MLIP: featurizer -> (message passing) -> per-atom energy -> sum.

Not a framework -- a worked example of how the pieces compose, and a usable baseline. Anything a
model needs beyond geometry enters as tensors: ``scalars`` (per-atom invariants, e.g. an
embedding of charge and spin, or a field magnitude) are appended to the readout and
message-passing inputs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

import torch
import torch.nn as nn

from ..config import Config, FeaturizerConfig, MessagePassingConfig, ReadoutConfig
from ..graph.batch import num_systems
from ..heads.transforms import pool
from ..o3.irreps import IrrepFeatures

__all__ = ["EnergyModel", "EnergyModelConfig"]


@dataclass
class EnergyModelConfig(Config):
    featurizer: FeaturizerConfig = field(default_factory=lambda: FeaturizerConfig(selected_lambdas=(0, 1, 2)))
    message_passing: MessagePassingConfig | None = None
    readout: ReadoutConfig = field(default_factory=lambda: ReadoutConfig("1x0e", species_bias=True))
    emb_dim: int = 16
    scalar_dim: int = 0


class EnergyModel(nn.Module):
    """``E = sum_i [ e_i + b(Z_i) + E0(Z_i) ]`` with ``e_i`` an invariant readout of the features.

    ``atomic_energies`` (``{Z: E0}``) are fixed per-species references, stored as a persistent
    buffer so a checkpoint is self-contained.
    """

    def __init__(
        self,
        featurizer: nn.Module,
        *,
        emb_dim: int = 16,
        scalar_dim: int = 0,
        message_passing: MessagePassingConfig | None = None,
        readout: ReadoutConfig | None = None,
        atomic_energies: Mapping[int, float] | None = None,
    ) -> None:
        super().__init__()
        self.featurizer = featurizer
        n_species = featurizer.n_species
        self.scalar_dim = int(scalar_dim)
        self.species_emb = nn.Embedding(n_species, emb_dim)
        irreps = featurizer.irreps_out
        self.mp = None
        if message_passing is not None:
            self.mp = message_passing.build(irreps, cutoff=featurizer.cutoff, emb_dim=emb_dim + self.scalar_dim,
                                            backend=featurizer.backend)
        readout = readout or ReadoutConfig("1x0e", species_bias=True)
        self.readout = readout.build(irreps, scalar_dim=emb_dim + self.scalar_dim, n_species=n_species)
        e0 = torch.zeros(n_species)
        for z, e in (atomic_energies or {}).items():
            idx = int(featurizer.species_index(torch.tensor([int(z)]))[0])
            if idx < 0:
                raise ValueError(f"atomic energy given for Z={z}, which the featurizer does not know")
            e0[idx] = float(e)
        self.register_buffer("atomic_energies", e0)

    @classmethod
    def from_config(cls, config: "EnergyModelConfig | dict", neighbor_types: Sequence[int],
                    atomic_energies: Mapping[int, float] | None = None) -> "EnergyModel":
        config = EnergyModelConfig.from_dict(config)
        return cls(
            config.featurizer.build(neighbor_types),
            emb_dim=config.emb_dim,
            scalar_dim=config.scalar_dim,
            message_passing=config.message_passing,
            readout=config.readout,
            atomic_energies=atomic_energies,
        )

    def forward(
        self,
        batch=None,
        *,
        positions: torch.Tensor | None = None,
        atomic_numbers: torch.Tensor | None = None,
        batch_idx: torch.Tensor | None = None,
        scalars: torch.Tensor | None = None,
        compute_forces: bool = False,
    ) -> dict[str, torch.Tensor]:
        if batch is not None:
            positions = batch.positions if positions is None else positions
            atomic_numbers = batch.atomic_numbers if atomic_numbers is None else atomic_numbers
            batch_idx = batch.batch_idx if batch_idx is None else batch_idx
        if batch_idx is None:
            batch_idx = torch.zeros(positions.shape[0], dtype=torch.long, device=positions.device)
        if compute_forces and not positions.requires_grad:
            positions = positions.detach().requires_grad_(True)

        feats: IrrepFeatures = self.featurizer(positions=positions, atomic_numbers=atomic_numbers, batch_idx=batch_idx)
        s = self.species_emb(feats.species_idx)
        if self.scalar_dim:
            if scalars is None:
                raise ValueError(f"this model expects per-atom scalars of width {self.scalar_dim}")
            s = torch.cat((s, scalars), dim=-1)
        if self.mp is not None:
            feats = self.mp(feats, positions, emb=s)
        atomic = self.readout(feats, s, species_idx=feats.species_idx)["0e"][:, 0, 0]
        atomic = atomic + self.atomic_energies[feats.species_idx]
        energy = pool(atomic, batch_idx, num_systems(batch_idx))
        out = {"energy": energy, "atomic_energies": atomic}
        if compute_forces:
            (grad,) = torch.autograd.grad(energy.sum(), positions, create_graph=self.training)
            out["forces"] = -grad
        return out
