"""Dataclass configs for bb's modules, with strict parsing and the pre-bb key aliases.

Every config is a plain dataclass with ``to_dict`` / ``from_dict`` and a ``build(...)`` that
returns the module, so a project's model config can embed bb's and stay a few lines::

    @dataclass
    class MyModelConfig(Config):
        featurizer: FeaturizerConfig = field(default_factory=FeaturizerConfig)
        message_passing: MessagePassingConfig | None = None
        energy: ReadoutConfig = field(default_factory=lambda: ReadoutConfig("1x0e"))

``from_dict`` rejects unknown keys (a typo should not silently become a default) and accepts the
old spellings from pauli_fierz_pinn / hbq_qed checkpoints -- ``cutoff_radius``, ``max_radial``,
``max_angular``, ``max_neighbors``, ``use_lambda1`` -- with a one-time warning, because configs
embedded in existing checkpoints will always carry them.
"""

from __future__ import annotations

import dataclasses
import typing
import warnings
from dataclasses import dataclass, field
from typing import Any, ClassVar, Sequence

__all__ = [
    "Config",
    "BispectrumConfig",
    "FeaturizerConfig",
    "MessagePassingConfig",
    "ReadoutConfig",
]

_WARNED: set[tuple[str, str]] = set()


def _is_config_type(tp) -> type | None:
    """The Config subclass inside ``tp`` (``X``, ``X | None``, ``Optional[X]``), or None."""
    if isinstance(tp, type) and issubclass(tp, Config):
        return tp
    for arg in typing.get_args(tp):
        found = _is_config_type(arg)
        if found is not None:
            return found
    return None


class Config:
    """Mixin: strict ``from_dict`` with aliases, recursive ``to_dict``."""

    #: ``{old_key: new_key}`` accepted by :meth:`from_dict`.
    ALIASES: ClassVar[dict[str, str]] = {}

    @classmethod
    def _legacy(cls, raw: dict) -> dict:
        """Hook for legacy keys that are not a simple rename."""
        return raw

    @classmethod
    def from_dict(cls, raw: "dict | Config | None", *, defaults: dict | None = None):
        """Build from a plain dict (YAML block, checkpoint-embedded config).

        ``defaults`` supplies values for fields given under neither their name nor an old alias
        -- how a project keeps its own historical defaults where they differ from bb's.
        """
        if raw is None:
            return None
        if isinstance(raw, cls):
            return raw
        if dataclasses.is_dataclass(raw):
            raw = dataclasses.asdict(raw)
        raw = cls._legacy(dict(raw))
        for old, new in cls.ALIASES.items():
            if old in raw:
                if new in raw and raw[new] != raw[old]:
                    raise ValueError(f"{cls.__name__}: both {old!r} and its new name {new!r} given")
                key = (cls.__name__, old)
                if key not in _WARNED:
                    _WARNED.add(key)
                    warnings.warn(
                        f"{cls.__name__}: config key {old!r} is the old name of {new!r}",
                        DeprecationWarning, stacklevel=2,
                    )
                raw[new] = raw.pop(old)
        for key, value in (defaults or {}).items():
            raw.setdefault(key, value)
        hints = typing.get_type_hints(cls)
        names = {f.name for f in dataclasses.fields(cls)}
        unknown = sorted(set(raw) - names)
        if unknown:
            raise ValueError(f"{cls.__name__}: unknown config keys {unknown}; known: {sorted(names)}")
        kwargs = {}
        for name, value in raw.items():
            sub = _is_config_type(hints.get(name))
            if sub is not None and value is not None and not isinstance(value, sub):
                value = sub.from_dict(value)
            elif isinstance(value, list) and typing.get_origin(hints.get(name)) in (tuple, typing.Union):
                value = tuple(value)
            kwargs[name] = value
        return cls(**kwargs)

    def to_dict(self) -> dict[str, Any]:
        out = {}
        for f in dataclasses.fields(self):
            value = getattr(self, f.name)
            if isinstance(value, Config):
                value = value.to_dict()
            elif isinstance(value, tuple):
                value = list(value)
            out[f.name] = value
        return out


@dataclass
class BispectrumConfig(Config):
    """Trainable nu=3 weighted bispectrum, concatenated onto the nu=2 power spectrum.

    Built through the equivariant backend: ``sym_contraction`` (the MACE block, orders
    1..``contraction_degree``) or ``descriptor`` (the pure nu=3 term, cue only). ``out_mul=None``
    keeps the density channel count (required by cue's ``sym_contraction``).
    """

    implementation: str = "sym_contraction"
    out_mul: int | None = None
    contraction_degree: int = 3
    degrees: tuple[int, ...] = (3,)
    per_species_weights: bool = False
    method: str = "auto"                     # "auto" -> fused kernel on CUDA, "naive" otherwise


@dataclass
class FeaturizerConfig(Config):
    """:class:`bb.features.SOAPFeaturizer`."""

    ALIASES: ClassVar[dict[str, str]] = {
        "cutoff_radius": "cutoff",
        "max_radial": "n_max",
        "max_angular": "l_max",
        "max_neighbors": "max_num_neighbors",
    }

    cutoff: float = 5.0
    n_max: int = 6
    l_max: int = 3
    selected_lambdas: tuple[int, ...] = (0, 1, 2)
    density_channels: int | None = None
    max_num_neighbors: int = 256
    # which neighbors the pure-torch neighbor list keeps if the cap binds: "nearest" | "index"
    neighbor_truncation: str = "nearest"
    backend: str = "e3nn"
    bispectrum: BispectrumConfig | None = None

    @classmethod
    def _legacy(cls, raw: dict) -> dict:
        # pf/hbq: `use_lambda1: bool` toggled the 1o block on top of the default (0, 2).
        if "use_lambda1" in raw:
            use = bool(raw.pop("use_lambda1"))
            if "selected_lambdas" not in raw:
                raw["selected_lambdas"] = (0, 1, 2) if use else (0, 2)
        return raw

    def build(self, neighbor_types: Sequence[int], *, backend=None):
        from ..features import SOAPFeaturizer

        return SOAPFeaturizer(
            cutoff=self.cutoff,
            n_max=self.n_max,
            l_max=self.l_max,
            neighbor_types=neighbor_types,
            selected_lambdas=self.selected_lambdas,
            backend=backend or self.backend,
            bispectrum=self.bispectrum,
            density_channels=self.density_channels,
            max_num_neighbors=self.max_num_neighbors,
            neighbor_truncation=self.neighbor_truncation,
        )


@dataclass
class MessagePassingConfig(Config):
    """:class:`bb.nn.EquivariantMessagePassing`.

    ``avg_num_neighbors`` is a model constant: leave it ``None`` in a config, measure it on the
    training split (:func:`bb.graph.average_num_neighbors`), and store it with the model.
    ``hidden_irreps=None`` refines every input irrep.
    """

    layers: int = 2
    channels: int = 32
    lmax: int = 2
    num_basis: int = 8
    radial_hidden: int = 64
    hidden_irreps: str | None = None
    avg_num_neighbors: float | None = None

    def build(self, irreps_in, *, cutoff: float, emb_dim: int = 0, backend="e3nn"):
        from ..nn import EquivariantMessagePassing

        return EquivariantMessagePassing(
            irreps_in=irreps_in,
            emb_dim=emb_dim,
            cutoff=cutoff,
            backend=backend,
            hidden_irreps=self.hidden_irreps,
            layers=self.layers,
            channels=self.channels,
            lmax=self.lmax,
            num_basis=self.num_basis,
            radial_hidden=self.radial_hidden,
            avg_num_neighbors=self.avg_num_neighbors,
        )


@dataclass
class ReadoutConfig(Config):
    """:class:`bb.heads.IrrepsReadout`; ``irreps_out`` like ``"1x0e"`` or ``"1x0e + 1x2e"``."""

    irreps_out: str = "1x0e"
    hidden: int = 64
    depth: int = 2
    reduce_channels: int = 32
    zero_init: bool = True
    exempt_decay: bool = True
    gate_layout: str = "blocked"
    species_bias: bool = False

    def build(self, irreps_in, *, scalar_dim: int = 0, n_species: int | None = None):
        from ..heads import IrrepsReadout

        return IrrepsReadout(
            irreps_in,
            self.irreps_out,
            scalar_dim=scalar_dim,
            hidden=self.hidden,
            depth=self.depth,
            reduce_channels=self.reduce_channels,
            zero_init=self.zero_init,
            exempt_decay=self.exempt_decay,
            gate_layout=self.gate_layout,
            species_bias=n_species if self.species_bias else None,
        )
