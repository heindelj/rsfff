"""Configs for bb's modules: strict dataclasses with ``build(...)`` and legacy key aliases."""

from .configs import BispectrumConfig, Config, FeaturizerConfig, MessagePassingConfig, ReadoutConfig

__all__ = ["BispectrumConfig", "Config", "FeaturizerConfig", "MessagePassingConfig", "ReadoutConfig"]
