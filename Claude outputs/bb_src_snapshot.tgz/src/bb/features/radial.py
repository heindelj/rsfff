"""Radial bases and cutoff envelopes."""

from __future__ import annotations

import math

import torch
import torch.nn as nn

__all__ = [
    "BesselBasis",
    "cosine_cutoff",
    "polynomial_envelope",
    "bessel_envelope_basis",
]


class BesselBasis(nn.Module):
    """Smooth Bessel radial basis (DimeNet-style), orthonormal on ``[0, r_cut]``.

    ``R_n(r) = sqrt(2/r_c) sin(n pi r / r_c) / r``. ``freqs`` is a *persistent* buffer, so it is
    part of every checkpoint that contains a featurizer; its key path
    (``...density.radial.freqs``) must not change.
    """

    def __init__(self, n_max: int, cutoff: float):
        super().__init__()
        self.n_max = n_max
        self.cutoff = cutoff
        freqs = torch.arange(1, n_max + 1, dtype=torch.float32) * math.pi
        self.register_buffer("freqs", freqs)
        self.norm = math.sqrt(2.0 / cutoff)

    def forward(self, r: torch.Tensor) -> torch.Tensor:
        # r: (E,)  ->  (E, n_max)
        r_safe = r.clamp(min=1e-8).unsqueeze(-1)
        return self.norm * torch.sin(self.freqs * r_safe / self.cutoff) / r_safe


def cosine_cutoff(r: torch.Tensor, cutoff: float) -> torch.Tensor:
    """Smooth cosine cutoff that goes to 0 at ``r = cutoff`` with zero derivative."""
    return 0.5 * (torch.cos(math.pi * r / cutoff) + 1.0) * (r < cutoff).to(r.dtype)


def polynomial_envelope(u: torch.Tensor, p: float = 6.0) -> torch.Tensor:
    """DimeNet polynomial envelope on ``u = r / r_c`` in ``[0, 1]``.

    Vanishes together with its first two derivatives at ``u = 1``, which keeps forces continuous
    when a neighbor enters or leaves the graph.
    """
    return (
        1.0
        - (p + 1.0) * (p + 2.0) / 2.0 * u.pow(p)
        + p * (p + 2.0) * u.pow(p + 1.0)
        - p * (p + 1.0) / 2.0 * u.pow(p + 2.0)
    )


def bessel_envelope_basis(r: torch.Tensor, cutoff: float, num_basis: int, p: float = 6.0) -> torch.Tensor:
    """Bessel ``j0`` radial basis times :func:`polynomial_envelope`: ``(E,) -> (E, B)``.

    ``sin(n pi u)/u`` (via ``sinc``, finite at ``u = 0``), scaled by ``sqrt(2/r_c)``. This is the
    edge embedding message passing feeds its radial MLP.
    """
    u = (r / cutoff).clamp(min=0.0, max=1.0).unsqueeze(-1)          # (E, 1)
    n = torch.arange(1, num_basis + 1, dtype=r.dtype, device=r.device)  # (B,)
    # sin(n pi u) / u = n * pi * sinc(n * u)   (torch.sinc(x) = sin(pi x)/(pi x))
    radial = n * math.pi * torch.sinc(n * u)                        # (E, B)
    return radial * polynomial_envelope(u, p) * math.sqrt(2.0 / cutoff)
