"""The atomic neighbor density ``A[i, c, n, lm]`` -- the start of every featurizer.

The density is built in two stages so that several decorations of one geometry share one
basis construction:

    RY = edge_expansion(positions, edge_index)        # (E, n_max, (l_max+1)^2), geometry only
    A  = scatter_species(RY, edge_index, species)     # (N, n_species, n_max, sph)
       | scatter_weighted(RY, edge_index, weights)    # (N, K, n_max, sph), learned channels

``scatter_species`` also takes an ``edge_mask`` (drop edges) or an ``edge_weight`` (scale them),
which is how fragment-confined, environment-only and soft-partitioned densities come out of one
neighbor search (see :mod:`bb.features.featurizers`).

Edge convention: ``edge_index[0]`` is the center ``i`` (the atom whose density this is), and
``edge_index[1]`` the neighbor ``j``; the bond vector is ``r_j - r_i``. A symmetric graph (what
:func:`bb.graph.build_radius_graph` returns) gives the same density for either row order.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from ..o3.backend import EquivariantBackend, resolve_backend
from .radial import BesselBasis, cosine_cutoff

__all__ = ["DensityExpansion"]


class DensityExpansion(nn.Module):
    """``A[i, Z, n, lm] = sum_{j ~ i, Z_j = Z} R_n(r_ij) Y_lm(r_hat_ij) f_cut(r_ij)``.

    Output shape ``(N, n_species, n_max, (l_max + 1)**2)``. Channels carry the natural-parity
    irreps ``0e + 1o + 2e + ...`` along the last axis.
    """

    def __init__(self, n_max: int, l_max: int, cutoff: float, n_species: int,
                 backend: "EquivariantBackend | str" = "e3nn"):
        super().__init__()
        self.n_max = n_max
        self.l_max = l_max
        self.cutoff = cutoff
        self.n_species = n_species
        self.sph_dim = (l_max + 1) ** 2
        self.backend = resolve_backend(backend)
        self.radial = BesselBasis(n_max, cutoff)

    def edge_expansion(
        self,
        positions: torch.Tensor,     # (N, 3)
        edge_index: torch.Tensor,    # (2, E)  rows are [center, neighbor]
    ) -> torch.Tensor:
        """Per-edge radial x angular expansion ``RY``: ``(E, n_max, sph_dim)``.

        The geometry-only part of the density, independent of how neighbors are weighted.
        """
        i, j = edge_index[0], edge_index[1]
        r_vec = positions[j] - positions[i]
        r = r_vec.norm(dim=-1)
        R = self.radial(r) * cosine_cutoff(r, self.cutoff).unsqueeze(-1)   # (E, n_max)
        Y = self.backend.spherical_harmonics(r_vec, self.l_max, normalize=True)  # (E, sph_dim)
        return R.unsqueeze(-1) * Y.unsqueeze(-2)                           # (E, n_max, sph_dim)

    def scatter_weighted(
        self,
        RY: torch.Tensor,            # (E, n_max, sph_dim) from edge_expansion
        edge_index: torch.Tensor,    # (2, E)
        atom_weights: torch.Tensor,  # (N, Kw) per-atom channel weights
        num_atoms: int,
    ) -> torch.Tensor:
        """Weighted density ``A[i,k,n,lm] = sum_{j~i} w_k(j) RY[ij,n,lm]``: ``(N, Kw, n_max, sph)``.

        Generalizes the species one-hot scatter: with ``atom_weights = one_hot(species_idx)`` it
        reproduces :meth:`scatter_species`, and with learned weights (e.g. from an embedding of
        element + charge + spin, :class:`bb.features.AtomWeightNet`) each neighbor enters
        through a learned identity rather than its bare element. The weights are invariant
        scalars, so equivariance is untouched.
        """
        i, j = edge_index[0], edge_index[1]
        k_w = atom_weights.shape[1]
        contrib = atom_weights[j][:, :, None, None] * RY[:, None]  # (E, Kw, n_max, sph)
        A = contrib.new_zeros(num_atoms, k_w, self.n_max, self.sph_dim)
        return A.index_add_(0, i, contrib)

    def scatter_species(
        self,
        RY: torch.Tensor,            # (E, n_max, sph_dim) from edge_expansion
        edge_index: torch.Tensor,    # (2, E)
        species_idx: torch.Tensor,   # (N,) ints in [0, n_species)
        num_atoms: int,
        edge_mask: torch.Tensor | None = None,   # (E,) bool, which edges contribute
        edge_weight: torch.Tensor | None = None,  # (E,) float, how much each edge contributes
    ) -> torch.Tensor:
        """Species-resolved density from a prebuilt ``RY``: ``(N, n_species, n_max, sph)``.

        ``edge_mask`` drops edges from the sum *without* rebuilding the geometry, so a
        group-confined and a full descriptor can share one neighbor search and one set of
        spherical harmonics -- and are then guaranteed to see identical geometry, so their
        difference is attributable to the environment and nothing else.

        ``edge_weight`` is the **soft** form of the same idea. The density is linear in the edge
        sum, so ``A(s) + A(1 - s) = A(1)`` exactly for any ``s``: a soft partition moves only
        where the boundary is drawn, never the total, and the power spectra of ``A(s)`` and
        ``A(1-s)`` are genuine power spectra (a convex combination of two *finished* spectra is
        not -- the spectrum is quadratic). At ``s in {0, 1}`` it reproduces ``edge_mask``
        bitwise on CPU.

        The two are alternatives, not composable -- pass one or neither.
        """
        if edge_mask is not None and edge_weight is not None:
            raise ValueError(
                "scatter_species got both edge_mask and edge_weight; they are the hard and soft "
                "forms of one partition. Pass the boolean mask for a definite partition, the "
                "float weight for a soft one, and neither for the full edge set"
            )
        i, j = edge_index[0], edge_index[1]
        if edge_mask is not None:
            i, j, RY = i[edge_mask], j[edge_mask], RY[edge_mask]
        elif edge_weight is not None:
            RY = RY * edge_weight.to(RY.dtype).reshape(-1, 1, 1)
        flat_idx = i * self.n_species + species_idx[j]
        A_flat = RY.new_zeros(num_atoms * self.n_species, self.n_max, self.sph_dim)
        A_flat.index_add_(0, flat_idx, RY)
        return A_flat.view(num_atoms, self.n_species, self.n_max, self.sph_dim)

    def forward(
        self,
        positions: torch.Tensor,     # (N, 3)
        species_idx: torch.Tensor,   # (N,) ints in [0, n_species)
        edge_index: torch.Tensor,    # (2, E)  rows are [center, neighbor]
        num_atoms: int,
    ) -> torch.Tensor:
        RY = self.edge_expansion(positions, edge_index)                    # (E, n_max, sph_dim)
        return self.scatter_species(RY, edge_index, species_idx, num_atoms)
