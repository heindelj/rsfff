"""O(3) primitives: irreps bookkeeping, the e3nn / cuequivariance backends, Cartesian helpers."""

from .backend import CueBackend, E3nnBackend, EquivariantBackend, get_backend, resolve_backend
from .cartesian import (
    irrep2_to_traceless_matrix,
    irrep6_to_voigt,
    irreps_to_voigt,
    matrix_to_voigt,
    min_eig_sym3x3,
    voigt_to_irrep6,
    voigt_to_irreps,
    voigt_to_matrix,
)
from .irreps import Irrep, IrrepFeatures, Irreps, natural_irrep, parse_irreps, split_by_l

__all__ = [
    "CueBackend", "E3nnBackend", "EquivariantBackend", "get_backend", "resolve_backend",
    "irrep2_to_traceless_matrix", "irrep6_to_voigt", "irreps_to_voigt", "matrix_to_voigt",
    "min_eig_sym3x3", "voigt_to_irrep6", "voigt_to_irreps", "voigt_to_matrix",
    "Irrep", "IrrepFeatures", "Irreps", "natural_irrep", "parse_irreps", "split_by_l",
]
