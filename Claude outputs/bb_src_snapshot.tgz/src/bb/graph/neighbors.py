"""The one place a neighbor list is built.

``torch_cluster.radius_graph`` takes ``max_num_neighbors=32`` by default and, on hitting it,
**silently drops** the excess edges: no error, no warning, just a descriptor (or a pair energy)
computed from a truncated environment. 32 is far below what condensed-phase work needs -- a 5 A
feature cutoff in bulk-like water already sits near 40 neighbors -- so every call goes through
:func:`build_radius_graph`, which

1. always passes ``max_num_neighbors`` explicitly (default :data:`DEFAULT_MAX_NUM_NEIGHBORS`),
   so the library default can never leak back in, and
2. checks afterwards whether any atom came out *at* the cap, which is the only observable
   signature of truncation.

The check costs one ``bincount`` plus one host sync per build. That sync is already paid:
``radius_graph`` itself calls ``.item()`` internally.

Reaching the cap is reported three ways, in increasing order of insistence:

- :data:`CAP_EVENTS` counts hits per context, for a training loop to log or assert on
  (:func:`reset_cap_events` clears it);
- a ``UserWarning``, emitted once per ``(context, cap)`` so a hot loop cannot spam it;
- :class:`NeighborCapExceeded`, raised instead of warning when strict mode is on
  (``BB_STRICT_NEIGHBORS=1``, or :func:`set_strict`).

The checking itself can be turned off with ``BB_NEIGHBOR_CAP_CHECK=0`` or :func:`set_cap_check`,
which is only worth doing in a profiling run. (The pre-bb names ``RSFFF_STRICT_NEIGHBORS`` and
``RSFFF_NEIGHBOR_CAP_CHECK`` are still read when the ``BB_`` ones are unset.)

``torch_cluster`` is optional. When it is not installed -- or its compiled op is broken (a wheel
built against a different torch raises "Not compiled with CUDA support" even on CPU tensors) --
:func:`radius_graph_torch`, the same graph in plain torch, is used instead and :data:`BACKEND`
says so. It is exact and O(N^2) per graph, which is the right trade for molecular clusters and
the wrong one for a large periodic box.

Edge convention: edges are directed and returned exactly as ``radius_graph`` returns them, both
``(i, j)`` and ``(j, i)``. With the default ``flow="source_to_target"`` row 1 is the query atom
(whose degree the cap bounds) and row 0 its neighbor. The graph is symmetric, so consumers that
treat row 0 as the center (the density expansion, message passing) see the same pair set.

Periodic boundary conditions are part of the signature (``cell``, ``pbc``) but not yet
implemented; passing a periodic cell raises rather than silently building a non-periodic graph.
"""

from __future__ import annotations

import os
import warnings

import torch

__all__ = [
    "DEFAULT_MAX_NUM_NEIGHBORS",
    "BACKEND",
    "config_max_num_neighbors",
    "NeighborCapExceeded",
    "CAP_EVENTS",
    "build_radius_graph",
    "radius_graph",
    "radius_graph_torch",
    "reset_cap_events",
    "set_cap_check",
    "set_strict",
]


def radius_graph_torch(
    x: torch.Tensor,
    r: float,
    batch: torch.Tensor | None = None,
    loop: bool = False,
    max_num_neighbors: int = 32,
    flow: str = "source_to_target",
    chunk: int = 1024,
    truncation: str = "nearest",
    **_ignored,
) -> torch.Tensor:
    """``torch_cluster.radius_graph`` in plain torch, for when the compiled one is absent.

    ``truncation`` decides which neighbors survive when an atom has more than
    ``max_num_neighbors``: ``"nearest"`` (default; deterministic and the defensible half to
    keep) or ``"index"`` (the first ones by atom index, the order torch_cluster's CPU kernel
    scans in -- for reproducing a model that was trained on a truncated graph).

    ``torch_cluster`` ships only a source distribution whose ``setup.py`` imports torch, so it
    cannot be pip-installed without ``--no-build-isolation`` and a compiler, which is a real
    obstacle on a new cluster. Nothing about this codebase actually needs a compiled kernel for
    the systems it runs on: a water cluster is tens of atoms, and the whole distance matrix is
    smaller than one feature tensor.

    Same contract as the compiled one. ``batch`` must be non-decreasing (each graph's atoms
    contiguous), which is what the rest of this codebase builds anyway; edges are directed and
    returned as ``(source, target)`` rows, so row 1 is the query atom -- the row
    :func:`_check_cap` counts.

    Two differences, both deliberate:

    **It is O(N^2) per graph**, in chunks of ``chunk`` query atoms, so the peak is
    ``chunk x N`` distances rather than ``N^2``. That is the right complexity for clusters and
    the wrong one for a large periodic box; the compiled kernel's cell list wins well before
    ten thousand atoms in one graph.

    **Truncation keeps the nearest neighbors**, where ``torch_cluster`` documents its picks as
    random. Either way the environment is wrong -- which is why hitting the cap is reported
    rather than tolerated -- but the nearest ones are the defensible half to keep, and they
    make the result deterministic. This also drops the self-pair *before* capping, so an atom
    comes back with at most ``max_num_neighbors`` neighbors; the compiled one asks its kernel
    for one extra so it can remove the self-pair afterwards, and an atom can come back with
    ``max_num_neighbors + 1``.
    """
    if flow not in ("source_to_target", "target_to_source"):
        raise ValueError(f"unknown flow {flow!r}")
    if truncation not in ("nearest", "index"):
        raise ValueError(f"truncation must be 'nearest' or 'index', got {truncation!r}")
    n_atoms = x.shape[0]
    if n_atoms == 0:
        return x.new_empty((2, 0), dtype=torch.long)
    if batch is None:
        batch = torch.zeros(n_atoms, dtype=torch.long, device=x.device)
    if bool((batch[1:] < batch[:-1]).any()):
        raise ValueError("batch must be non-decreasing: every graph's atoms contiguous")

    counts = torch.bincount(batch)
    cap = int(max_num_neighbors) if max_num_neighbors is not None else None

    # Padded per-frame blocks: (F, n_max, n_max) distances in one shot. A training batch is
    # 128 frames of 18-63 atoms; the earlier chunked block (1024 query rows x every frame
    # those rows touch) computed ~17x more distances than needed and spent them in
    # ``torch.cdist``'s generic p-norm kernel -- 38 ms of a 117 ms forward at w21 on an A100
    # (benchmarks/profile, after M4). Padding wastes only n_max^2 / n_g^2 per frame, the
    # arithmetic is three elementwise kernels, and there is no host sync unless a row can
    # actually exceed the cap. Falls back to the chunked path when the padded block would be
    # large (one big frame), where the chunking is what keeps the peak memory bounded.
    n_max = int(counts.max())
    if counts.numel() * n_max * n_max * 3 * x.element_size() <= _PADDED_BLOCK_BYTES:
        return _radius_graph_padded(x, r, batch, counts, n_max, loop, cap, flow, truncation)

    # Chunks run over the *concatenated* atom list, not per graph: a training batch is 128
    # frames of 18-63 atoms, and a Python loop over frames cost a flat ~64 ms per call on an
    # A100 (benchmarks/profile, M0 of the torchff port) regardless of how small the frames
    # were. Each chunk's columns are restricted to the frames its query rows touch, so the
    # distance block stays ~chunk x (a few frames) and the work is still ~sum_g n_g^2 rather
    # than N_total^2; the frame membership is enforced by a mask on the block.
    bounds = torch.cat([counts.new_zeros(1), counts.cumsum(0)]).tolist()
    batch_list = batch.tolist()
    sources: list[torch.Tensor] = []
    targets: list[torch.Tensor] = []
    chunk = max(int(chunk), 1)

    for begin in range(0, n_atoms, chunk):
        end = min(begin + chunk, n_atoms)
        col_lo = bounds[batch_list[begin]]
        col_hi = bounds[batch_list[end - 1] + 1]
        # exact distances: cdist's matrix-multiply shortcut loses digits near zero, and an
        # edge sitting on the cutoff should not depend on that
        distance = torch.cdist(x[begin:end], x[col_lo:col_hi],
                               compute_mode="donot_use_mm_for_euclid_dist")
        near = distance < r  # strict, as the compiled kernel is: a pair sitting exactly
                             # on the cutoff is out, not in
        near &= batch[begin:end, None] == batch[None, col_lo:col_hi]
        rows = torch.arange(end - begin, device=x.device)
        if not loop:
            near[rows, rows + (begin - col_lo)] = False
        if cap is not None and int(near.sum(dim=1).max()) > cap:
            near &= _keep(near, distance, cap, truncation)
        query, neighbor = near.nonzero(as_tuple=True)
        targets.append(query + begin)
        sources.append(neighbor + col_lo)

    source = torch.cat(sources) if sources else x.new_empty(0, dtype=torch.long)
    target = torch.cat(targets) if targets else x.new_empty(0, dtype=torch.long)
    if flow == "target_to_source":
        source, target = target, source
    return torch.stack([source, target], dim=0)


#: Above this many bytes of padded (F, n_max, n_max, 3) difference block, the chunked path
#: is used instead (512 MB: a single 4,700-atom frame in float64).
_PADDED_BLOCK_BYTES = 512 * 1024 ** 2


def _keep(near: torch.Tensor, distance: torch.Tensor, cap: int, truncation: str) -> torch.Tensor:
    """Mask of the ``cap`` neighbors each row keeps (along the last axis)."""
    if truncation == "index":
        return near.long().cumsum(dim=-1) <= cap
    k = min(cap, near.shape[-1])
    chosen = distance.masked_fill(~near, float("inf")).topk(k, dim=-1, largest=False).indices
    keep = torch.zeros_like(near)
    keep.scatter_(-1, chosen, True)
    return keep


def _radius_graph_padded(x, r, batch, counts, n_max, loop, cap, flow, truncation="nearest"):
    """All frames at once on a padded ``(F, n_max, n_max)`` block; same contract and the same
    edge order (by query atom, then neighbor) as the chunked path."""
    device = x.device
    n_atoms = x.shape[0]
    n_frames = counts.numel()
    offsets = torch.cat([counts.new_zeros(1), counts.cumsum(0)[:-1]])
    local = torch.arange(n_max, device=device)
    valid = local[None, :] < counts[:, None]                          # (F, n_max)
    idx = (offsets[:, None] + local[None, :]).clamp_(max=max(n_atoms - 1, 0))
    xp = x[idx]                                                        # (F, n_max, 3)
    # exact distances (no matrix-multiply shortcut): an edge sitting on the cutoff must not
    # depend on cancellation, and the chunked path / compiled kernel agree with this form
    diff = xp[:, :, None, :] - xp[:, None, :, :]
    distance = (diff * diff).sum(-1).sqrt_()                           # (F, n_max, n_max)
    near = (distance < r) & valid[:, :, None] & valid[:, None, :]
    if not loop:
        near[:, local, local] = False
    if cap is not None and n_max - 1 > cap and int(near.sum(dim=-1).max()) > cap:
        near &= _keep(near, distance, cap, truncation)
    frame, query, neighbor = near.nonzero(as_tuple=True)
    target = idx[frame, query]
    source = idx[frame, neighbor]
    if flow == "target_to_source":
        source, target = target, source
    return torch.stack([source, target], dim=0)


try:
    from torch_cluster import radius_graph as _tc_radius_graph

    #: Which implementation :func:`build_radius_graph` calls: ``"torch_cluster"`` or ``"torch"``.
    BACKEND = "torch_cluster"
except ImportError:  # pragma: no cover -- exercised by not having it installed
    _tc_radius_graph = None
    BACKEND = "torch"

_TC_BROKEN = False


#: Cap handed to every ``radius_graph`` call unless a caller overrides it. Chosen well above the
#: ~40-60 neighbors a condensed-phase feature cutoff produces, so hitting it means something is
#: wrong (a too-large cutoff, a collapsed geometry) rather than merely dense.
DEFAULT_MAX_NUM_NEIGHBORS = 256


def _env_flag(names: tuple[str, ...], default: bool) -> bool:
    for name in names:
        raw = os.environ.get(name)
        if raw is not None:
            return raw.strip().lower() not in ("0", "", "false", "no", "off")
    return default


_STRICT = _env_flag(("BB_STRICT_NEIGHBORS", "RSFFF_STRICT_NEIGHBORS"), False)
_CHECK = _env_flag(("BB_NEIGHBOR_CAP_CHECK", "RSFFF_NEIGHBOR_CAP_CHECK"), True)

#: ``context -> number of builds that hit the cap`` since the last :func:`reset_cap_events`.
#: Counts builds, not atoms; the warning carries the atom count.
CAP_EVENTS: dict[str, int] = {}

_WARNED: set[tuple[str, int]] = set()


class NeighborCapExceeded(RuntimeError):
    """A neighbor list was truncated by ``max_num_neighbors``."""


def set_strict(strict: bool) -> None:
    """Raise :class:`NeighborCapExceeded` (instead of warning) when the cap is reached."""
    global _STRICT
    _STRICT = bool(strict)


def set_cap_check(enabled: bool) -> None:
    """Enable/disable the post-build cap check (it costs one bincount + one host sync)."""
    global _CHECK
    _CHECK = bool(enabled)


def reset_cap_events() -> None:
    """Clear :data:`CAP_EVENTS` and the once-per-context warning memory."""
    CAP_EVENTS.clear()
    _WARNED.clear()


_WARNED_FALLBACK = False


def radius_graph(
    x: torch.Tensor,
    r: float,
    batch: torch.Tensor | None = None,
    loop: bool = False,
    max_num_neighbors: int = DEFAULT_MAX_NUM_NEIGHBORS,
    flow: str = "source_to_target",
    truncation: str = "nearest",
) -> torch.Tensor:
    """``torch_cluster.radius_graph`` when it is installed and working, else
    :func:`radius_graph_torch` (whose ``truncation`` applies only to that fallback). No cap
    check -- use :func:`build_radius_graph` for that."""
    global _TC_BROKEN, _WARNED_FALLBACK
    if _tc_radius_graph is None or _TC_BROKEN:
        if _tc_radius_graph is None and not _WARNED_FALLBACK:
            _WARNED_FALLBACK = True
            warnings.warn(
                "torch_cluster is not installed; using bb.graph.radius_graph_torch, which is "
                "exact but O(N^2) per graph. Fine for clusters, slow for a large periodic box. "
                "Install the compiled one with: FORCE_ONLY_CPU=1 pip install "
                "--no-build-isolation torch-cluster",
                stacklevel=3,
            )
        return radius_graph_torch(
            x, r=r, batch=batch, loop=loop, max_num_neighbors=max_num_neighbors, flow=flow,
            truncation=truncation,
        )
    if x.device.type == "mps":
        # torch_cluster ships CPU and CUDA kernels but no MPS one.
        return _tc_radius_graph(
            x.cpu(), r=r, batch=None if batch is None else batch.cpu(), loop=loop,
            max_num_neighbors=max_num_neighbors, flow=flow,
        ).to(x.device)
    if x.device.type == "cuda" and not _compiled_has_cuda():
        return radius_graph_torch(
            x, r=r, batch=batch, loop=loop, max_num_neighbors=max_num_neighbors, flow=flow,
            truncation=truncation,
        )
    try:
        return _tc_radius_graph(
            x, r=r, batch=batch, loop=loop, max_num_neighbors=max_num_neighbors, flow=flow
        )
    except RuntimeError as exc:
        # A torch_cluster wheel built against a mismatched torch raises from its compiled op.
        # Warn once and use the pure-torch graph for the rest of the session.
        _TC_BROKEN = True
        warnings.warn(
            f"torch_cluster.radius_graph failed ({exc}); falling back to the pure-torch "
            "neighbor graph. Reinstall a torch_cluster matching your torch build to restore "
            "the fast path.",
            RuntimeWarning,
            stacklevel=3,
        )
        return radius_graph_torch(
            x, r=r, batch=batch, loop=loop, max_num_neighbors=max_num_neighbors, flow=flow,
            truncation=truncation,
        )


def _check_pbc(cell, pbc) -> None:
    periodic = False
    if pbc is not None:
        periodic = bool(torch.as_tensor(pbc).any())
    elif cell is not None:
        periodic = bool(torch.as_tensor(cell).abs().sum() > 0)
    if periodic:
        raise NotImplementedError(
            "periodic neighbor lists are not implemented yet: build_radius_graph accepts "
            "`cell`/`pbc` so callers can be written against the final signature, but a "
            "periodic cell would currently produce a silently non-periodic graph"
        )


def build_radius_graph(
    positions: torch.Tensor,               # (N, 3)
    r: float,
    batch: torch.Tensor | None = None,     # (N,) long, grouping (frame or fragment)
    *,
    context: str,
    loop: bool = False,
    max_num_neighbors: int = DEFAULT_MAX_NUM_NEIGHBORS,
    cell: torch.Tensor | None = None,      # (B, 3, 3), reserved for PBC
    pbc: torch.Tensor | None = None,       # (B, 3) bool, reserved for PBC
    truncation: str = "nearest",
) -> torch.Tensor:
    """Radius graph with an explicit cap and truncation detection.

    ``context`` names the call site in the warning and in :data:`CAP_EVENTS`; it is required so
    a report always says *which* list was truncated. ``batch`` groups atoms (a frame, or a
    fragment): no edge crosses a group boundary, and each group's atoms must be contiguous.

    The returned edges are directed (both ``(i, j)`` and ``(j, i)``) exactly as
    ``radius_graph`` returns them; de-duplication to ``i < j`` is the caller's business.
    """
    if cell is not None or pbc is not None:
        _check_pbc(cell, pbc)
    if batch is None:
        batch = torch.zeros(positions.shape[0], dtype=torch.long, device=positions.device)
    cap = int(max_num_neighbors)
    edge = radius_graph(positions, r=r, batch=batch, loop=loop, max_num_neighbors=cap,
                        truncation=truncation)
    if _CHECK:
        _check_cap(edge, positions.shape[0], r, cap, context)
    return edge


_CUDA_OK: bool | None = None


def _compiled_has_cuda() -> bool:
    """Whether ``torch_cluster.radius_graph`` can take CUDA tensors, probed once.

    A torch_cluster built with ``FORCE_ONLY_CPU=1`` (right for CPU nodes) makes every CUDA call
    raise "Not compiled with CUDA support". Rather than make the GPU path depend on how
    torch_cluster was compiled, a CPU-only build falls back to :func:`radius_graph_torch` -- the
    same graph, on the device -- with one warning.
    """
    global _CUDA_OK
    if _CUDA_OK is None:
        if _tc_radius_graph is None:
            _CUDA_OK = True
        else:
            try:
                x = torch.zeros(2, 3, device="cuda")
                _tc_radius_graph(x, r=1.0, batch=torch.zeros(2, dtype=torch.long, device="cuda"))
                _CUDA_OK = True
            except RuntimeError:
                _CUDA_OK = False
                warnings.warn(
                    "torch_cluster was built without CUDA kernels (FORCE_ONLY_CPU=1?); "
                    "using bb.graph.radius_graph_torch for CUDA tensors.",
                    stacklevel=3,
                )
    return _CUDA_OK


def _check_cap(edge: torch.Tensor, n_atoms: int, r: float, cap: int, context: str) -> None:
    """Flag atoms sitting *at* the cap -- the only visible trace of a truncated list.

    The cap applies per *query* atom, and with ``flow="source_to_target"`` the query is row 1 of
    the returned edges (row 0 is the neighbor, whose count is unbounded). Counting the wrong row
    would both miss truncation and invent it, so the row choice here is load-bearing.

    An atom with exactly ``cap`` neighbors may be a genuine boundary case rather than a
    truncated one, so this over-reports by at most the handful of atoms that land on the
    boundary. That is the right side to err on.
    """
    if edge.numel() == 0:
        return
    degree = torch.bincount(edge[1], minlength=n_atoms)
    n_at_cap = int((degree >= cap).sum())
    if n_at_cap == 0:
        return

    CAP_EVENTS[context] = CAP_EVENTS.get(context, 0) + 1
    message = (
        f"{context}: neighbor list reached max_num_neighbors={cap} for {n_at_cap} of "
        f"{n_atoms} atoms at cutoff {r}. Those atoms are missing neighbors and their "
        f"features/pair energies are wrong (and which neighbors survive depends on the kernel, "
        f"so results differ across devices). Raise max_num_neighbors (or shrink the cutoff)."
    )
    if _STRICT:
        raise NeighborCapExceeded(message)
    key = (context, cap)
    if key not in _WARNED:
        _WARNED.add(key)
        warnings.warn(message, stacklevel=3)


def config_max_num_neighbors(features_cfg) -> int:
    """``max_num_neighbors`` from a features config, dataclass or plain dict.

    Also reads the pf/hbq spelling ``max_neighbors``. Defaulted rather than required so a config
    built by older code keeps working -- the point is only that the *library* default of 32
    never reaches a call.
    """
    keys = ("max_num_neighbors", "max_neighbors")
    for key in keys:
        if isinstance(features_cfg, dict):
            value = features_cfg.get(key)
        else:
            value = getattr(features_cfg, key, None)
        if value is not None:
            return int(value)
    return DEFAULT_MAX_NUM_NEIGHBORS
