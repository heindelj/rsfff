"""The ion CT force field with its two learned quantities (ion ct ff plan, R4/R5).

Everything physical is fixed (``IonTable``, ``ChannelTable``): permanent shaped densities, free-ion alpha and C,
induced-density shapes, frontier densities, intrinsic gaps and the pair couplings W_T(R). The network emits

    c_alpha,i, c_C,i   confinement of the free-ion polarizabilities (exactly 1 for an isolated ion)
    Delta^ov_ij >= 0   the whole overlap gap of channel i -> j, partner included (the fully learned form)
    A_ij >= 0          (pseudo=True) strength of the Pauli pseudo-potential of ion j acting on ion i's response: a
                       short-ranged, chargeless drive (kernels.pseudo_drive_basis) added to the induction drive. It
                       lowers E_pol without touching the response to a uniform field, which the confinement alone sets

and the model does the rest: mutual induction with the confined polarizabilities (E_pol), the frontier potentials
from permanent + induced moments, the gaps Delta = g_T + s dphi + Delta^ov, the WKB coupling response and the
per-donor arrowhead (E_CT). No CT feedback into the electrostatics.

Training on fixed geometries (EDA energies) only needs the network to change, so every geometry-dependent tensor is
precomputed once per frame (:func:`precompute`) and frames are evaluated as a padded batch (:func:`collate`,
:meth:`IonCTModel.forward`). Units: atomic (energies Hartree).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import torch
import torch.nn as nn

from . import ct as CT
from . import kernels as K
from .params import IonTable

__all__ = ["FrameCache", "precompute", "collate", "IonCTModel", "CHANNEL_TYPES", "PSEUDO_TYPES"]

CHANNEL_TYPES = ("Cl>Na", "Na>Cl", "Cl>Cl", "Na>Na")
#: Pauli pseudo-potential drive types, "i<j": the response of i to the pseudo-potential of j
PSEUDO_TYPES = ("Cl<Na", "Na<Cl", "Cl<Cl", "Na<Na")
#: scale of the pseudo-potential strength per type, so the network's softplus output is O(1): A = A0 softplus(z).
#: Roughly the strength at which the pseudo drive equals the permanent drive at contact (Na+ is compact, so its
#: pseudo-potential reaches the Cl- response density weakly)
PSEUDO_A0 = {"Cl<Na": 40.0, "Na<Cl": 5.0, "Cl<Cl": 5.0, "Na<Na": 5.0}
PSEUDO_CUTOFF = 6.0


@dataclass
class FrameCache:
    species: torch.Tensor        # (N,)
    pos: torch.Tensor            # (N, 3) A
    L: torch.Tensor              # (N, 8) induction drive
    A_off: torch.Tensor          # (8N, 8N)
    VD: torch.Tensor             # (N, N) donor-frontier potentials, permanent part
    KD: torch.Tensor             # (N, N, 8) induced kernel
    VA: torch.Tensor
    KA: torch.Tensor
    ch_index: torch.Tensor       # (2, C)
    ch_type: torch.Tensor        # (C,) index into CHANNEL_TYPES
    ch_r: torch.Tensor           # (C,) A
    ch_g: torch.Tensor
    ch_lnW: torch.Tensor
    ch_dphi_pair: torch.Tensor
    feats: torch.Tensor          # (N, F) environment invariants (zero for an isolated ion)
    ps_index: torch.Tensor = None   # (2, P) directed pairs (i <- j) of the Pauli pseudo-potential drive
    ps_type: torch.Tensor = None    # (P,) index into PSEUDO_TYPES
    ps_r: torch.Tensor = None       # (P,) A
    ps_basis: torch.Tensor = None   # (P, 8) drive on i per unit pseudo-potential strength on j
    labels: dict = field(default_factory=dict)   # 'pol', 'ct' (Hartree), masks
    meta: dict = field(default_factory=dict)


@torch.no_grad()
def precompute(symbols, pos_ang, tab: IonTable, chan: CT.ChannelTable, featurizer, labels=None, meta=None) -> FrameCache:
    Zmap = {"Na": 11, "Cl": 17}
    pos = torch.as_tensor(pos_ang, dtype=torch.float64)
    Z = torch.tensor([Zmap[s] for s in symbols])
    s = tab.species_index(Z)
    b = torch.zeros(len(symbols), dtype=torch.long)
    L, A_off = K.induction_operator(pos, s, b, tab)
    VD, KD = K.frontier_operator(pos, s, b, tab, "donor")
    VA, KA = K.frontier_operator(pos, s, b, tab, "acceptor")
    geom = CT.channel_geometry(pos, s, b, tab, chan)
    ch_type = torch.tensor([CHANNEL_TYPES.index(n) for n in geom["names"]], dtype=torch.long)
    feats = featurizer(positions=pos, atomic_numbers=Z, batch_idx=b).inv_feats.to(torch.float64)
    ps_index, ps_r, ps_basis = K.pseudo_drive_basis(pos, s, b, tab, PSEUDO_CUTOFF)
    ps_type = pseudo_types(s, ps_index, tab)
    return FrameCache(s, pos, L, A_off, VD, KD, VA, KA, geom["index"], ch_type, geom["r"], geom["g"], geom["lnW"],
                      geom["dphi_pair"], feats, ps_index, ps_type, ps_r, ps_basis, dict(labels or {}), dict(meta or {}))


def pseudo_types(species, idx, tab: IonTable):
    sym = tab.symbols
    return torch.tensor([PSEUDO_TYPES.index(f"{sym[species[i]]}<{sym[species[j]]}") for i, j in idx.T.tolist()],
                        dtype=torch.long)


def collate(frames: list[FrameCache]) -> dict:
    """Pad the per-frame matrices to the largest frame; flatten atoms and channels with offsets."""
    B = len(frames)
    nmax = max(f.species.shape[0] for f in frames)
    dt = frames[0].L.dtype
    L = torch.zeros(B, nmax, 8, dtype=dt)
    A = torch.zeros(B, 8 * nmax, 8 * nmax, dtype=dt)
    VD = torch.zeros(B, nmax, nmax, dtype=dt)
    VA = torch.zeros(B, nmax, nmax, dtype=dt)
    KD = torch.zeros(B, nmax, nmax, 8, dtype=dt)
    KA = torch.zeros(B, nmax, nmax, 8, dtype=dt)
    mask = torch.zeros(B, nmax, dtype=torch.bool)
    species, feats, frame_of, idx, ty, r, g, lnW, dpp, ch_frame = [], [], [], [], [], [], [], [], [], []
    pos, ps_idx, ps_ty, ps_r, ps_basis = [], [], [], [], []
    off = 0
    for k, f in enumerate(frames):
        n = f.species.shape[0]
        L[k, :n] = f.L
        A[k, :8 * n, :8 * n] = f.A_off
        VD[k, :n, :n], VA[k, :n, :n], KD[k, :n, :n], KA[k, :n, :n] = f.VD, f.VA, f.KD, f.KA
        mask[k, :n] = True
        species.append(f.species)
        feats.append(f.feats)
        frame_of.append(torch.full((n,), k, dtype=torch.long))
        idx.append(f.ch_index + off)
        ty.append(f.ch_type)
        r.append(f.ch_r)
        g.append(f.ch_g)
        lnW.append(f.ch_lnW)
        dpp.append(f.ch_dphi_pair)
        ch_frame.append(torch.full((f.ch_r.shape[0],), k, dtype=torch.long))
        pos.append(f.pos)
        if f.ps_index is not None:
            ps_idx.append(f.ps_index + off)
            ps_ty.append(f.ps_type)
            ps_r.append(f.ps_r)
            ps_basis.append(f.ps_basis)
        off += n
    lab = {key: torch.tensor([f.labels.get(key, float("nan")) for f in frames], dtype=dt)
           for key in ("pol", "ct")}
    lab["ct_mask"] = torch.tensor([bool(f.labels.get("ct_mask", True)) for f in frames])
    nT = len(CHANNEL_TYPES)
    lab["chan"] = torch.tensor([f.labels.get("chan") or [float("nan")] * nT for f in frames], dtype=dt)
    lab["n"] = torch.tensor([f.species.shape[0] for f in frames], dtype=dt)
    return {"B": B, "nmax": nmax, "L": L, "A_off": A, "VD": VD, "VA": VA, "KD": KD, "KA": KA, "mask": mask,
            "species": torch.cat(species), "feats": torch.cat(feats), "frame": torch.cat(frame_of),
            "ch_index": torch.cat(idx, 1), "ch_type": torch.cat(ty), "ch_r": torch.cat(r), "ch_g": torch.cat(g),
            "ch_lnW": torch.cat(lnW), "ch_dphi_pair": torch.cat(dpp), "ch_frame": torch.cat(ch_frame), "labels": lab,
            "pos": torch.cat(pos),
            "ps_index": torch.cat(ps_idx, 1) if ps_idx else torch.zeros(2, 0, dtype=torch.long),
            "ps_type": torch.cat(ps_ty) if ps_ty else torch.zeros(0, dtype=torch.long),
            "ps_r": torch.cat(ps_r) if ps_r else torch.zeros(0, dtype=dt),
            "ps_basis": torch.cat(ps_basis) if ps_basis else torch.zeros(0, 8, dtype=dt)}


def _mlp(i, h, o, depth):
    layers, d = [], i
    for _ in range(depth):
        layers += [nn.Linear(d, h), nn.SiLU()]
        d = h
    layers.append(nn.Linear(d, o))
    return nn.Sequential(*layers)


class IonCTModel(nn.Module):
    """Confinement and overlap-gap heads on per-ion environment invariants, plus the fixed physics."""

    def __init__(self, tab: IonTable, chan: CT.ChannelTable, n_feat: int, *, hidden=64, depth=2, emb=8, n_rbf=16,
                 r_rbf=(1.5, 8.0), c_range=(0.05, 1.25), ov_init=0.15, wkb="smooth+floor", feat_scale=None,
                 confine=None, pseudo=False, ps_init=0.02, joint=False, joint_tol=1e-9, joint_max_iter=30):
        super().__init__()
        self.tab, self.chan, self.wkb = tab, chan, wkb
        self.joint, self.joint_tol, self.joint_max_iter = joint, joint_tol, joint_max_iter
        S = len(tab.symbols)
        self.register_buffer("feat_scale", torch.ones(n_feat) if feat_scale is None else feat_scale.clone())
        self.emb = nn.Embedding(S, emb)
        self.atom = _mlp(n_feat + emb, hidden, hidden, depth)
        self.conf = _mlp(hidden, hidden, 2, 1)
        nn.init.zeros_(self.conf[-1].weight)
        nn.init.zeros_(self.conf[-1].bias)
        self.log_c_lo, self.log_c_hi = math.log(c_range[0]), math.log(c_range[1])
        # species whose polarizabilities the network may confine (default all); the others stay free-ion
        confine = tab.symbols if confine is None else tuple(confine)
        self.register_buffer("confine_mask", torch.tensor([float(x in confine) for x in tab.symbols], dtype=torch.float64))
        self.register_buffer("rbf_mu", torch.linspace(r_rbf[0], r_rbf[1], n_rbf))
        self.rbf_w = (r_rbf[1] - r_rbf[0]) / (n_rbf - 1)
        self.gap = _mlp(2 * hidden + n_rbf + len(CHANNEL_TYPES), hidden, 1, depth)
        nn.init.zeros_(self.gap[-1].weight)
        nn.init.constant_(self.gap[-1].bias, math.log(math.expm1(ov_init)))
        # Pauli pseudo-potential strengths A_ij >= 0 (directed pairs within PSEUDO_CUTOFF)
        self.pseudo = pseudo
        if pseudo:
            self.ps = _mlp(2 * hidden + n_rbf + len(PSEUDO_TYPES), hidden, 1, depth)
            nn.init.zeros_(self.ps[-1].weight)
            nn.init.constant_(self.ps[-1].bias, math.log(math.expm1(ps_init)))
            self.register_buffer("ps_A0", torch.tensor([PSEUDO_A0[t] for t in PSEUDO_TYPES], dtype=torch.float64))
        self.double()

    # -- network outputs --
    def latents(self, feats, species):
        e = self.emb(species)
        h = self.atom(torch.cat([feats / self.feat_scale, e], -1))
        h0 = self.atom(torch.cat([torch.zeros_like(feats), e], -1))
        return h, h0

    def confinement(self, h, h0, species=None):
        """(N, 2) scales on the free-ion alpha and C, in c_range, exactly 1 for an isolated ion (u = 0); the map
        u -> log c is smooth with unit slope at 0 and saturates at log c_min / log c_max."""
        u = self.conf(h) - self.conf(h0)
        if species is not None:
            u = u * self.confine_mask[species][:, None]
        lo, hi = self.log_c_lo, self.log_c_hi
        return torch.where(u > 0, hi * torch.tanh(u / hi), lo * torch.tanh(u / lo)).exp()

    def overlap_gap(self, h, idx, r, ty):
        i, j = idx
        rbf = torch.exp(-((r[:, None] - self.rbf_mu) / self.rbf_w) ** 2)
        onehot = nn.functional.one_hot(ty, len(CHANNEL_TYPES)).to(h.dtype)
        z = torch.cat([h[i], h[j], rbf, onehot], -1)
        x = ((r - (self.chan.cutoff - 1.0)) / 1.0).clamp(0, 1)
        cut = 1 - x ** 3 * (10 - 15 * x + 6 * x * x)
        return nn.functional.softplus(self.gap(z)[:, 0]) * cut

    def pseudo_strength(self, h, idx, r, ty):
        """A_ij >= 0 of each directed pair (i <- j), smoothly zero at PSEUDO_CUTOFF."""
        i, j = idx
        rbf = torch.exp(-((r[:, None] - self.rbf_mu) / self.rbf_w) ** 2)
        onehot = nn.functional.one_hot(ty, len(PSEUDO_TYPES)).to(h.dtype)
        z = torch.cat([h[i], h[j], rbf, onehot], -1)
        x = ((r - (PSEUDO_CUTOFF - 1.0)) / 1.0).clamp(0, 1)
        cut = 1 - x ** 3 * (10 - 15 * x + 6 * x * x)
        return self.ps_A0[ty] * nn.functional.softplus(self.ps(z)[:, 0]) * cut

    def pseudo_drive(self, h, idx, r, ty, basis, n):
        """(n, 8): sum_j A_ij basis_ij on every ion, and A (P,)."""
        A = self.pseudo_strength(h, idx, r, ty)
        return h.new_zeros(n, 8).index_add(0, idx[0], A[:, None] * basis), A

    # -- the model --
    def forward(self, bt: dict, quadrupoles=True, field=None) -> dict:
        """``field`` (B, 3) a uniform field per frame (au), applied with the network outputs of the field-free
        geometry: it shifts the drive (dipole slots) and every frontier potential by -F . x."""
        sp = bt["species"]
        h, h0 = self.latents(bt["feats"], sp)
        c = self.confinement(h, h0, sp)
        B, nmax, mask = bt["B"], bt["nmax"], bt["mask"]
        n = sp.shape[0]
        alpha = torch.ones(B, nmax, dtype=h.dtype).masked_scatter(mask, self.tab.alpha[sp] * c[:, 0])
        Cq = torch.ones(B, nmax, dtype=h.dtype).masked_scatter(mask, self.tab.C[sp] * c[:, 1])
        Lflat = h.new_zeros(n, 8)
        A_ps = h.new_zeros(0)
        if self.pseudo and bt["ps_index"].shape[1]:
            Lps, A_ps = self.pseudo_drive(h, bt["ps_index"], bt["ps_r"], bt["ps_type"], bt["ps_basis"], n)
            Lflat = Lflat + Lps
        phi_ext = h.new_zeros(n)
        if field is not None:
            Fa = field[bt["frame"]]
            Lflat = Lflat - torch.cat([Fa, h.new_zeros(n, 5)], 1)
            phi_ext = -(Fa * bt["pos"] / K.BOHR_ANG).sum(-1)
        L = bt["L"] + h.new_zeros(B, nmax, 8).masked_scatter(mask[..., None].expand(B, nmax, 8), Lflat)
        x0 = K.solve_induction(L, bt["A_off"], alpha, Cq, quadrupoles)           # (B, nmax, 8)
        e_pol = 0.5 * (L * x0).sum((1, 2))
        dov = self.overlap_gap(h, bt["ch_index"], bt["ch_r"], bt["ch_type"])
        if not bt["ch_index"].shape[1]:
            z = h.new_zeros(B)
            return {"e_pol": e_pol, "e_ct": z, "e_ct_post": z, "e_type": h.new_zeros(B, len(CHANNEL_TYPES)), "c": c,
                    "dov": dov, "A_ps": A_ps, "W": dov, "Delta": dov, "delta": dov, "p": dov, "dq": h.new_zeros(n),
                    "x": x0, "x_pol": x0, "joint_iters": 0}
        ct0 = self._ct(x0, bt, sp, mask, phi_ext, dov)
        out = {"e_pol": e_pol, "c": c, "dov": dov, "A_ps": A_ps, "x_pol": x0, "e_ct_post": ct0["e_ct"]}
        if not self.joint:
            return {**out, **ct0, "x": x0, "joint_iters": 0}
        # joint pol + CT: x* = argmin 1/2 x^T A x + L.x + E_CT(x). E_CT depends on x through the frontier potentials
        # (gaps, WKB): its gradient is the field of the CT populations at the induced sites. Fixed point
        # x <- -A^-1 (L + dE_CT/dx) on detached copies; the energy at x* is then differentiated only explicitly
        # (envelope theorem: x* is stationary), so parameter gradients and forces need no implicit term.
        A = K.induction_matrix(bt["A_off"], alpha, Cq).detach()
        lu = torch.linalg.lu_factor(A)
        Ld, dovd = L.detach(), dov.detach()
        x, it = x0.detach(), 0
        for it in range(1, self.joint_max_iter + 1):
            with torch.enable_grad():
                xg = x.clone().requires_grad_(True)
                g = torch.autograd.grad(self._ct(xg, bt, sp, mask, phi_ext.detach(), dovd)["e_ct"].sum(), xg)[0]
            xn = -torch.linalg.lu_solve(*lu, (Ld + g).reshape(B, -1, 1)).reshape(B, nmax, 8)
            dx = (xn - x).abs().max().item()
            x = xn.detach()
            if dx < self.joint_tol:
                break
        Ax = torch.bmm(K.induction_matrix(bt["A_off"], alpha, Cq), x.reshape(B, -1, 1)).reshape(B, nmax, 8)
        e_quad = (0.5 * Ax + L).mul(x).sum((1, 2))
        ct = self._ct(x, bt, sp, mask, phi_ext, dov)
        return {**out, **ct, "e_ct": e_quad + ct["e_ct"] - e_pol, "e_ct_chan": ct["e_ct"], "x": x, "joint_iters": it}

    def _ct(self, x, bt, sp, mask, phi_ext, dov):
        """CT channels on the induced moments x (B, nmax, 8): per-frame E_CT (arrowhead roots) and diagnostics."""
        B, n = bt["B"], sp.shape[0]
        phiD = (bt["VD"].sum(-1) + torch.einsum("bijk,bjk->bi", bt["KD"], x))[mask] + phi_ext
        phiA = (bt["VA"].sum(-1) + torch.einsum("bijk,bjk->bi", bt["KA"], x))[mask] + phi_ext
        geom = {"index": bt["ch_index"], "r": bt["ch_r"], "g": bt["ch_g"], "lnW": bt["ch_lnW"],
                "dphi_pair": bt["ch_dphi_pair"], "dov_pair": torch.zeros_like(bt["ch_r"])}
        W, Delta, delta = CT.channel_gaps(geom, phiD, phiA, self.tab.I_donor[sp], self.chan.s, ov_add=dov,
                                          pair_overlap=False, wkb=self.wkb)
        eps, p, dq = CT.arrowhead(W, Delta, bt["ch_index"], n)
        e_ct = x.new_zeros(B).index_add(0, bt["frame"], eps)
        nT = len(CHANNEL_TYPES)
        e_type = x.new_zeros(B * nT).index_add(0, bt["ch_frame"] * nT + bt["ch_type"], -W / Delta).reshape(B, nT)
        return {"e_ct": e_ct, "e_type": e_type, "W": W, "Delta": Delta, "delta": delta, "p": p, "dq": dq}
