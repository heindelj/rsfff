"""rsfff.ff.ionct.model: the cached, batched forward equals the direct kernels; isolated ions stay free."""
import json
import warnings
from pathlib import Path

import pytest
import torch

from rsfff.ff.ionct import IonTable
from rsfff.ff.ionct import ct as CT
from rsfff.ff.ionct import kernels as K
from rsfff.ff.ionct.model import IonCTModel, collate, precompute

PARAMS = Path(__file__).resolve().parents[1] / "params" / "ions_wb97mv_tzvpd.json"
HAS = PARAMS.exists() and "channels" in json.load(open(PARAMS))
pytestmark = pytest.mark.skipif(not HAS, reason="params with a 'channels' section not built")
DT = torch.float64


@pytest.fixture(scope="module")
def setup():
    warnings.filterwarnings("ignore")
    from bb.features import SOAPFeaturizer
    tab, chan = IonTable.load(PARAMS), CT.ChannelTable.load(PARAMS)
    feat = SOAPFeaturizer(cutoff=6.0, n_max=6, l_max=3, neighbor_types=(11, 17), selected_lambdas=(0,)).double()
    return tab, chan, feat


FRAMES = [
    (["Na", "Cl"], [[0, 0, 0], [0, 0, 2.5]]),
    (["Cl", "Na", "Cl"], [[0, 0, 0], [2.7, 0.2, 0], [4.9, 1.8, 0.3]]),
    (["Na", "Cl", "Na", "Cl"], [[0, 0, 0], [2.6, 0, 0], [2.7, 2.6, 0.1], [0.1, 2.7, -0.2]]),
    (["Cl"], [[0, 0, 0]]),
]


def test_cached_forward_matches_the_direct_model(setup):
    tab, chan, feat = setup
    caches = [precompute(s, X, tab, chan, feat) for s, X in FRAMES]
    model = IonCTModel(tab, chan, caches[0].feats.shape[1])
    with torch.no_grad():
        for p in model.conf.parameters():            # a nontrivial confinement
            p.normal_(0, 0.05)
        out = model(collate(caches))
    off = 0
    for q, (sym, X) in enumerate(FRAMES):
        n = len(sym)
        Xt = torch.tensor(X, dtype=DT)
        sp = tab.species_index(torch.tensor([{"Na": 11, "Cl": 17}[a] for a in sym]))
        b = torch.zeros(n, dtype=torch.long)
        c = out["c"][off:off + n]
        ind = K.induction(Xt, sp, b, tab, alpha_scale=c[:, 0], c_scale=c[:, 1])
        assert out["e_pol"][q].item() == pytest.approx(ind.energy.item(), rel=1e-10, abs=1e-14)
        if n > 1:
            m = torch.as_tensor([int(f) == q for f in collate(caches)["ch_frame"]])
            res = CT.ct_energy(Xt, sp, b, tab, chan, x_ind=ind.x, ov_add=out["dov"][m], pair_overlap=False,
                               wkb=model.wkb)
            assert out["e_ct"][q].item() == pytest.approx(res.energy.item(), rel=1e-10)
        off += n


def test_isolated_ion_is_the_free_ion(setup):
    tab, chan, feat = setup
    caches = [precompute(["Cl"], [[0, 0, 0]], tab, chan, feat)]
    model = IonCTModel(tab, chan, caches[0].feats.shape[1])
    with torch.no_grad():
        for p in model.parameters():
            p.normal_(0, 0.3)
        out = model(collate(caches))
    assert torch.allclose(out["c"], torch.ones_like(out["c"]), atol=1e-14)
    assert out["e_ct"].item() == 0.0 and out["e_pol"].item() == 0.0


@pytest.mark.parametrize("with_field", [False, True])
def test_pseudo_and_field_forward_match_the_direct_kernels(setup, with_field):
    """The cached batch with the Pauli pseudo-potential drive and a uniform field equals the direct kernels."""
    from rsfff.ff.ionct.model import PSEUDO_CUTOFF, pseudo_types
    tab, chan, feat = setup
    caches = [precompute(s, X, tab, chan, feat) for s, X in FRAMES]
    model = IonCTModel(tab, chan, caches[0].feats.shape[1], pseudo=True, wkb="smooth")
    torch.manual_seed(1)
    with torch.no_grad():
        for p in list(model.conf.parameters()) + list(model.ps.parameters()):
            p.normal_(0, 0.05)
        bt = collate(caches)
        Fb = torch.tensor([[0.0, 0.0, 0.003], [0.002, -0.001, 0.0], [0.0, 0.004, 0.0], [0.001, 0.0, 0.0]], dtype=DT)
        out = model(bt, field=Fb if with_field else None)
    assert (out["A_ps"] > 0).all()
    off = 0
    for q, (sym, X) in enumerate(FRAMES):
        n = len(sym)
        Xt = torch.tensor(X, dtype=DT)
        sp = tab.species_index(torch.tensor([{"Na": 11, "Cl": 17}[a] for a in sym]))
        b = torch.zeros(n, dtype=torch.long)
        F = Fb[q:q + 1] if with_field else None
        with torch.no_grad():
            h, h0 = model.latents(caches[q].feats, sp)
            idx, r, basis = K.pseudo_drive_basis(Xt, sp, b, tab, PSEUDO_CUTOFF)
            d = model.pseudo_drive(h, idx, r, pseudo_types(sp, idx, tab), basis, n)[0] if idx.shape[1] else None
            c = out["c"][off:off + n]
            ind = K.induction(Xt, sp, b, tab, field=F, alpha_scale=c[:, 0], c_scale=c[:, 1], drive_add=d)
        assert out["e_pol"][q].item() == pytest.approx(ind.energy.item(), rel=1e-10, abs=1e-14)
        if n > 1:
            m = torch.as_tensor([int(f) == q for f in bt["ch_frame"]])
            res = CT.ct_energy(Xt, sp, b, tab, chan, x_ind=ind.x, field=F, ov_add=out["dov"][m], pair_overlap=False,
                               wkb=model.wkb)
            assert out["e_ct"][q].item() == pytest.approx(res.energy.item(), rel=1e-10)
        off += n


def test_pseudo_drive_leaves_the_field_response_unchanged(setup):
    """The pseudo-potential is a constant drive: it lowers |E_pol| of a Na-Cl pair but not d2E/dF2."""
    tab, chan, _ = setup
    X = torch.tensor([[0, 0, 0], [0, 0, 2.8]], dtype=DT)
    sp = tab.species_index(torch.tensor([11, 17]))
    b = torch.zeros(2, dtype=torch.long)
    idx, r, basis = K.pseudo_drive_basis(X, sp, b, tab)
    d = torch.zeros(2, 8, dtype=DT).index_add(0, idx[0], 30.0 * basis)
    e = lambda Fz, dd: K.induction(X, sp, b, tab, field=torch.tensor([[0, 0, Fz]], dtype=DT), drive_add=dd).energy.item()
    assert abs(e(0, d)) < abs(e(0, None))
    h = 2e-3
    a0 = -(e(h, None) + e(-h, None) - 2 * e(0, None)) / h ** 2
    a1 = -(e(h, d) + e(-h, d) - 2 * e(0, d)) / h ** 2
    assert a1 == pytest.approx(a0, rel=1e-6)
